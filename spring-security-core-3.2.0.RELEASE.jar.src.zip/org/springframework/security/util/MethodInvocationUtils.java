/*     */ package org.springframework.security.util;
/*     */ 
/*     */ import java.lang.reflect.Method;
/*     */ import org.aopalliance.intercept.MethodInvocation;
/*     */ import org.springframework.aop.framework.Advised;
/*     */ import org.springframework.aop.support.AopUtils;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class MethodInvocationUtils
/*     */ {
/*     */   public static MethodInvocation create(Object object, String methodName, Object... args) {
/*  48 */     Assert.notNull(object, "Object required");
/*     */     
/*  50 */     Class<?>[] classArgs = null;
/*     */     
/*  52 */     if (args != null) {
/*  53 */       classArgs = new Class[args.length];
/*     */       
/*  55 */       for (int i = 0; i < args.length; i++) {
/*  56 */         classArgs[i] = args[i].getClass();
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/*  61 */     Class<?> target = AopUtils.getTargetClass(object);
/*  62 */     if (object instanceof Advised) {
/*  63 */       Advised a = (Advised)object;
/*  64 */       if (!a.isProxyTargetClass()) {
/*  65 */         Class<?>[] possibleInterfaces = a.getProxiedInterfaces();
/*  66 */         for (Class<?> possibleInterface : possibleInterfaces) {
/*     */           try {
/*  68 */             possibleInterface.getMethod(methodName, classArgs);
/*     */             
/*  70 */             target = possibleInterface;
/*     */             break;
/*  72 */           } catch (Exception ignored) {}
/*     */         } 
/*     */       } 
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/*  79 */     return createFromClass(object, target, methodName, classArgs, args);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static MethodInvocation createFromClass(Class<?> clazz, String methodName) {
/*  95 */     MethodInvocation mi = createFromClass(null, clazz, methodName, null, null);
/*     */     
/*  97 */     if (mi == null) {
/*  98 */       for (Method m : clazz.getDeclaredMethods()) {
/*  99 */         if (m.getName().equals(methodName)) {
/* 100 */           if (mi != null) {
/* 101 */             throw new IllegalArgumentException("The class " + clazz + " has more than one method named" + " '" + methodName + "'");
/*     */           }
/*     */           
/* 104 */           mi = new SimpleMethodInvocation(null, m, new Object[0]);
/*     */         } 
/*     */       } 
/*     */     }
/*     */     
/* 109 */     return mi;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static MethodInvocation createFromClass(Object targetObject, Class<?> clazz, String methodName, Class<?>[] classArgs, Object[] args) {
/*     */     Method method;
/* 125 */     Assert.notNull(clazz, "Class required");
/* 126 */     Assert.hasText(methodName, "MethodName required");
/*     */ 
/*     */ 
/*     */     
/*     */     try {
/* 131 */       method = clazz.getMethod(methodName, classArgs);
/* 132 */     } catch (NoSuchMethodException e) {
/* 133 */       return null;
/*     */     } 
/*     */     
/* 136 */     return new SimpleMethodInvocation(targetObject, method, args);
/*     */   }
/*     */ }


/* Location:              C:\Users\Gcorp\Downloads\spring-security-core-3.2.0.RELEASE.jar!\org\springframework\securit\\util\MethodInvocationUtils.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */