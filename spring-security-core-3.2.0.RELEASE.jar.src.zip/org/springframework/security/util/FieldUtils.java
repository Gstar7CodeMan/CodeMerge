/*     */ package org.springframework.security.util;
/*     */ 
/*     */ import java.lang.reflect.Field;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ReflectionUtils;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class FieldUtils
/*     */ {
/*     */   public static Field getField(Class<?> clazz, String fieldName) throws IllegalStateException {
/*  44 */     Assert.notNull(clazz, "Class required");
/*  45 */     Assert.hasText(fieldName, "Field name required");
/*     */     
/*     */     try {
/*  48 */       return clazz.getDeclaredField(fieldName);
/*  49 */     } catch (NoSuchFieldException nsf) {
/*     */       
/*  51 */       if (clazz.getSuperclass() != null) {
/*  52 */         return getField(clazz.getSuperclass(), fieldName);
/*     */       }
/*     */       
/*  55 */       throw new IllegalStateException("Could not locate field '" + fieldName + "' on class " + clazz);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Object getFieldValue(Object bean, String fieldName) throws IllegalAccessException {
/*  66 */     Assert.notNull(bean, "Bean cannot be null");
/*  67 */     Assert.hasText(fieldName, "Field name required");
/*  68 */     String[] nestedFields = StringUtils.tokenizeToStringArray(fieldName, ".");
/*  69 */     Class<?> componentClass = bean.getClass();
/*  70 */     Object value = bean;
/*     */     
/*  72 */     for (String nestedField : nestedFields) {
/*  73 */       Field field = getField(componentClass, nestedField);
/*  74 */       field.setAccessible(true);
/*  75 */       value = field.get(value);
/*  76 */       if (value != null) {
/*  77 */         componentClass = value.getClass();
/*     */       }
/*     */     } 
/*     */     
/*  81 */     return value;
/*     */   }
/*     */ 
/*     */   
/*     */   public static Object getProtectedFieldValue(String protectedField, Object object) {
/*  86 */     Field field = getField(object.getClass(), protectedField);
/*     */     
/*     */     try {
/*  89 */       field.setAccessible(true);
/*     */       
/*  91 */       return field.get(object);
/*  92 */     } catch (Exception ex) {
/*  93 */       ReflectionUtils.handleReflectionException(ex);
/*     */       
/*  95 */       return null;
/*     */     } 
/*     */   }
/*     */   
/*     */   public static void setProtectedFieldValue(String protectedField, Object object, Object newValue) {
/* 100 */     Field field = getField(object.getClass(), protectedField);
/*     */     
/*     */     try {
/* 103 */       field.setAccessible(true);
/* 104 */       field.set(object, newValue);
/* 105 */     } catch (Exception ex) {
/* 106 */       ReflectionUtils.handleReflectionException(ex);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\Gcorp\Downloads\spring-security-core-3.2.0.RELEASE.jar!\org\springframework\securit\\util\FieldUtils.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */