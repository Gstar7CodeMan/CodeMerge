/*    */ package org.springframework.security.util;
/*    */ 
/*    */ import java.lang.reflect.AccessibleObject;
/*    */ import java.lang.reflect.Method;
/*    */ import org.aopalliance.intercept.MethodInvocation;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SimpleMethodInvocation
/*    */   implements MethodInvocation
/*    */ {
/*    */   private Method method;
/*    */   private Object[] arguments;
/*    */   private Object targetObject;
/*    */   
/*    */   public SimpleMethodInvocation(Object targetObject, Method method, Object... arguments) {
/* 39 */     this.targetObject = targetObject;
/* 40 */     this.method = method;
/* 41 */     this.arguments = (arguments == null) ? new Object[0] : arguments;
/*    */   }
/*    */ 
/*    */   
/*    */   public SimpleMethodInvocation() {}
/*    */ 
/*    */   
/*    */   public Object[] getArguments() {
/* 49 */     return this.arguments;
/*    */   }
/*    */   
/*    */   public Method getMethod() {
/* 53 */     return this.method;
/*    */   }
/*    */   
/*    */   public AccessibleObject getStaticPart() {
/* 57 */     throw new UnsupportedOperationException("mock method not implemented");
/*    */   }
/*    */   
/*    */   public Object getThis() {
/* 61 */     return this.targetObject;
/*    */   }
/*    */   
/*    */   public Object proceed() throws Throwable {
/* 65 */     throw new UnsupportedOperationException("mock method not implemented");
/*    */   }
/*    */ }


/* Location:              C:\Users\Gcorp\Downloads\spring-security-core-3.2.0.RELEASE.jar!\org\springframework\securit\\util\SimpleMethodInvocation.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */