/*    */ package org.springframework.security.util;
/*    */ 
/*    */ import java.io.ByteArrayInputStream;
/*    */ import java.io.IOException;
/*    */ import java.io.InputStream;
/*    */ import java.util.Arrays;
/*    */ import org.springframework.core.io.AbstractResource;
/*    */ import org.springframework.util.Assert;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class InMemoryResource
/*    */   extends AbstractResource
/*    */ {
/*    */   private final byte[] source;
/*    */   private final String description;
/*    */   
/*    */   public InMemoryResource(String source) {
/* 42 */     this(source.getBytes());
/*    */   }
/*    */   
/*    */   public InMemoryResource(byte[] source) {
/* 46 */     this(source, null);
/*    */   }
/*    */   
/*    */   public InMemoryResource(byte[] source, String description) {
/* 50 */     Assert.notNull(source);
/* 51 */     this.source = source;
/* 52 */     this.description = description;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public String getDescription() {
/* 58 */     return this.description;
/*    */   }
/*    */   
/*    */   public InputStream getInputStream() throws IOException {
/* 62 */     return new ByteArrayInputStream(this.source);
/*    */   }
/*    */   
/*    */   public int hashCode() {
/* 66 */     return 1;
/*    */   }
/*    */   
/*    */   public boolean equals(Object res) {
/* 70 */     if (!(res instanceof InMemoryResource)) {
/* 71 */       return false;
/*    */     }
/*    */     
/* 74 */     return Arrays.equals(this.source, ((InMemoryResource)res).source);
/*    */   }
/*    */ }


/* Location:              C:\Users\Gcorp\Downloads\spring-security-core-3.2.0.RELEASE.jar!\org\springframework\securit\\util\InMemoryResource.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */