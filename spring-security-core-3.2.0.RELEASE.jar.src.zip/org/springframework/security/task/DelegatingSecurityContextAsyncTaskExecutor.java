/*    */ package org.springframework.security.task;
/*    */ 
/*    */ import java.util.concurrent.Callable;
/*    */ import java.util.concurrent.Future;
/*    */ import org.springframework.core.task.AsyncTaskExecutor;
/*    */ import org.springframework.core.task.TaskExecutor;
/*    */ import org.springframework.security.core.context.SecurityContext;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DelegatingSecurityContextAsyncTaskExecutor
/*    */   extends DelegatingSecurityContextTaskExecutor
/*    */   implements AsyncTaskExecutor
/*    */ {
/*    */   public DelegatingSecurityContextAsyncTaskExecutor(AsyncTaskExecutor delegateAsyncTaskExecutor, SecurityContext securityContext) {
/* 42 */     super((TaskExecutor)delegateAsyncTaskExecutor, securityContext);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public DelegatingSecurityContextAsyncTaskExecutor(AsyncTaskExecutor delegateAsyncTaskExecutor) {
/* 51 */     this(delegateAsyncTaskExecutor, (SecurityContext)null);
/*    */   }
/*    */   
/*    */   public final void execute(Runnable task, long startTimeout) {
/* 55 */     task = wrap(task);
/* 56 */     getDelegate().execute(task, startTimeout);
/*    */   }
/*    */   
/*    */   public final Future<?> submit(Runnable task) {
/* 60 */     task = wrap(task);
/* 61 */     return getDelegate().submit(task);
/*    */   }
/*    */   
/*    */   public final <T> Future<T> submit(Callable<T> task) {
/* 65 */     task = wrap(task);
/* 66 */     return getDelegate().submit(task);
/*    */   }
/*    */   
/*    */   private AsyncTaskExecutor getDelegate() {
/* 70 */     return (AsyncTaskExecutor)getDelegateExecutor();
/*    */   }
/*    */ }


/* Location:              C:\Users\Gcorp\Downloads\spring-security-core-3.2.0.RELEASE.jar!\org\springframework\security\task\DelegatingSecurityContextAsyncTaskExecutor.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */