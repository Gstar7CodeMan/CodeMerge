/*    */ package org.springframework.security.task;
/*    */ 
/*    */ import java.util.concurrent.Executor;
/*    */ import org.springframework.core.task.TaskExecutor;
/*    */ import org.springframework.security.concurrent.DelegatingSecurityContextExecutor;
/*    */ import org.springframework.security.core.context.SecurityContext;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DelegatingSecurityContextTaskExecutor
/*    */   extends DelegatingSecurityContextExecutor
/*    */   implements TaskExecutor
/*    */ {
/*    */   public DelegatingSecurityContextTaskExecutor(TaskExecutor delegateTaskExecutor, SecurityContext securityContext) {
/* 35 */     super((Executor)delegateTaskExecutor, securityContext);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public DelegatingSecurityContextTaskExecutor(TaskExecutor delegate) {
/* 45 */     this(delegate, null);
/*    */   }
/*    */ }


/* Location:              C:\Users\Gcorp\Downloads\spring-security-core-3.2.0.RELEASE.jar!\org\springframework\security\task\DelegatingSecurityContextTaskExecutor.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */