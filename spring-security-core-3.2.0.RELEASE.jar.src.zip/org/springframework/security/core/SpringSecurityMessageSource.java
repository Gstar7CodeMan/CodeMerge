/*    */ package org.springframework.security.core;
/*    */ 
/*    */ import org.springframework.context.MessageSource;
/*    */ import org.springframework.context.support.MessageSourceAccessor;
/*    */ import org.springframework.context.support.ResourceBundleMessageSource;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SpringSecurityMessageSource
/*    */   extends ResourceBundleMessageSource
/*    */ {
/*    */   public SpringSecurityMessageSource() {
/* 35 */     setBasename("org.springframework.security.messages");
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public static MessageSourceAccessor getAccessor() {
/* 41 */     return new MessageSourceAccessor((MessageSource)new SpringSecurityMessageSource());
/*    */   }
/*    */ }


/* Location:              C:\Users\Gcorp\Downloads\spring-security-core-3.2.0.RELEASE.jar!\org\springframework\security\core\SpringSecurityMessageSource.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */