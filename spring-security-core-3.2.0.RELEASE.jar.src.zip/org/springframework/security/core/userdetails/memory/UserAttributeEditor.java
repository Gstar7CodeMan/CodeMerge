/*    */ package org.springframework.security.core.userdetails.memory;
/*    */ 
/*    */ import java.beans.PropertyEditorSupport;
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ import org.springframework.util.StringUtils;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class UserAttributeEditor
/*    */   extends PropertyEditorSupport
/*    */ {
/*    */   public void setAsText(String s) throws IllegalArgumentException {
/* 33 */     if (StringUtils.hasText(s)) {
/* 34 */       String[] tokens = StringUtils.commaDelimitedListToStringArray(s);
/* 35 */       UserAttribute userAttrib = new UserAttribute();
/*    */       
/* 37 */       List<String> authoritiesAsStrings = new ArrayList<String>();
/*    */       
/* 39 */       for (int i = 0; i < tokens.length; i++) {
/* 40 */         String currentToken = tokens[i].trim();
/*    */         
/* 42 */         if (i == 0) {
/* 43 */           userAttrib.setPassword(currentToken);
/*    */         }
/* 45 */         else if (currentToken.toLowerCase().equals("enabled")) {
/* 46 */           userAttrib.setEnabled(true);
/* 47 */         } else if (currentToken.toLowerCase().equals("disabled")) {
/* 48 */           userAttrib.setEnabled(false);
/*    */         } else {
/* 50 */           authoritiesAsStrings.add(currentToken);
/*    */         } 
/*    */       } 
/*    */       
/* 54 */       userAttrib.setAuthoritiesAsString(authoritiesAsStrings);
/*    */       
/* 56 */       if (userAttrib.isValid()) {
/* 57 */         setValue(userAttrib);
/*    */       } else {
/* 59 */         setValue(null);
/*    */       } 
/*    */     } else {
/* 62 */       setValue(null);
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\Gcorp\Downloads\spring-security-core-3.2.0.RELEASE.jar!\org\springframework\security\cor\\userdetails\memory\UserAttributeEditor.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */