/*    */ package org.springframework.security.core.userdetails.memory;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ import java.util.Vector;
/*    */ import org.springframework.security.core.GrantedAuthority;
/*    */ import org.springframework.security.core.authority.SimpleGrantedAuthority;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class UserAttribute
/*    */ {
/* 34 */   private List<GrantedAuthority> authorities = new Vector<GrantedAuthority>();
/*    */   
/*    */   private String password;
/*    */   
/*    */   private boolean enabled = true;
/*    */   
/*    */   public void addAuthority(GrantedAuthority newAuthority) {
/* 41 */     this.authorities.add(newAuthority);
/*    */   }
/*    */   
/*    */   public List<GrantedAuthority> getAuthorities() {
/* 45 */     return this.authorities;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void setAuthorities(List<GrantedAuthority> authorities) {
/* 55 */     this.authorities = authorities;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void setAuthoritiesAsString(List<String> authoritiesAsStrings) {
/* 66 */     setAuthorities(new ArrayList<GrantedAuthority>(authoritiesAsStrings.size()));
/* 67 */     for (String authority : authoritiesAsStrings) {
/* 68 */       addAuthority((GrantedAuthority)new SimpleGrantedAuthority(authority));
/*    */     }
/*    */   }
/*    */   
/*    */   public String getPassword() {
/* 73 */     return this.password;
/*    */   }
/*    */   
/*    */   public boolean isEnabled() {
/* 77 */     return this.enabled;
/*    */   }
/*    */   
/*    */   public boolean isValid() {
/* 81 */     if (this.password != null && this.authorities.size() > 0) {
/* 82 */       return true;
/*    */     }
/* 84 */     return false;
/*    */   }
/*    */ 
/*    */   
/*    */   public void setEnabled(boolean enabled) {
/* 89 */     this.enabled = enabled;
/*    */   }
/*    */   
/*    */   public void setPassword(String password) {
/* 93 */     this.password = password;
/*    */   }
/*    */ }


/* Location:              C:\Users\Gcorp\Downloads\spring-security-core-3.2.0.RELEASE.jar!\org\springframework\security\cor\\userdetails\memory\UserAttribute.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */