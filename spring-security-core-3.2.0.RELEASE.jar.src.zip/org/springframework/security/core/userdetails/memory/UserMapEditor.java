/*    */ package org.springframework.security.core.userdetails.memory;
/*    */ 
/*    */ import java.beans.PropertyEditorSupport;
/*    */ import java.util.Properties;
/*    */ import org.springframework.beans.propertyeditors.PropertiesEditor;
/*    */ import org.springframework.security.core.userdetails.User;
/*    */ import org.springframework.security.core.userdetails.UserDetails;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Deprecated
/*    */ public class UserMapEditor
/*    */   extends PropertyEditorSupport
/*    */ {
/*    */   public static UserMap addUsersFromProperties(UserMap userMap, Properties props) {
/* 50 */     UserAttributeEditor configAttribEd = new UserAttributeEditor();
/*    */     
/* 52 */     for (Object o : props.keySet()) {
/* 53 */       String username = (String)o;
/* 54 */       String value = props.getProperty(username);
/*    */ 
/*    */       
/* 57 */       configAttribEd.setAsText(value);
/*    */       
/* 59 */       UserAttribute attr = (UserAttribute)configAttribEd.getValue();
/*    */ 
/*    */       
/* 62 */       if (attr != null) {
/* 63 */         User user = new User(username, attr.getPassword(), attr.isEnabled(), true, true, true, attr.getAuthorities());
/*    */         
/* 65 */         userMap.addUser((UserDetails)user);
/*    */       } 
/*    */     } 
/*    */     
/* 69 */     return userMap;
/*    */   }
/*    */   
/*    */   public void setAsText(String s) throws IllegalArgumentException {
/* 73 */     UserMap userMap = new UserMap();
/*    */     
/* 75 */     if (s != null && !"".equals(s)) {
/*    */ 
/*    */ 
/*    */       
/* 79 */       PropertiesEditor propertiesEditor = new PropertiesEditor();
/* 80 */       propertiesEditor.setAsText(s);
/*    */       
/* 82 */       Properties props = (Properties)propertiesEditor.getValue();
/* 83 */       addUsersFromProperties(userMap, props);
/*    */     } 
/*    */     
/* 86 */     setValue(userMap);
/*    */   }
/*    */ }


/* Location:              C:\Users\Gcorp\Downloads\spring-security-core-3.2.0.RELEASE.jar!\org\springframework\security\cor\\userdetails\memory\UserMapEditor.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */