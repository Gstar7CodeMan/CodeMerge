/*     */ package org.springframework.security.core.userdetails.memory;
/*     */ 
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.security.core.userdetails.UserDetails;
/*     */ import org.springframework.security.core.userdetails.UsernameNotFoundException;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Deprecated
/*     */ public class UserMap
/*     */ {
/*  41 */   private static final Log logger = LogFactory.getLog(UserMap.class);
/*     */ 
/*     */ 
/*     */   
/*  45 */   private final Map<String, UserDetails> userMap = new HashMap<String, UserDetails>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addUser(UserDetails user) throws IllegalArgumentException {
/*  57 */     Assert.notNull(user, "Must be a valid User");
/*     */     
/*  59 */     logger.info("Adding user [" + user + "]");
/*  60 */     this.userMap.put(user.getUsername().toLowerCase(), user);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public UserDetails getUser(String username) throws UsernameNotFoundException {
/*  73 */     UserDetails result = this.userMap.get(username.toLowerCase());
/*     */     
/*  75 */     if (result == null) {
/*  76 */       throw new UsernameNotFoundException("Could not find user: " + username, username);
/*     */     }
/*     */     
/*  79 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getUserCount() {
/*  88 */     return this.userMap.size();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setUsers(Map<String, UserDetails> users) {
/*  98 */     this.userMap.clear();
/*  99 */     for (Map.Entry<String, UserDetails> entry : users.entrySet())
/* 100 */       this.userMap.put(((String)entry.getKey()).toLowerCase(), entry.getValue()); 
/*     */   }
/*     */ }


/* Location:              C:\Users\Gcorp\Downloads\spring-security-core-3.2.0.RELEASE.jar!\org\springframework\security\cor\\userdetails\memory\UserMap.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */