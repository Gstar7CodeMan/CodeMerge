/*    */ package org.springframework.security.core.userdetails.memory;
/*    */ 
/*    */ import java.util.Properties;
/*    */ import org.springframework.beans.factory.InitializingBean;
/*    */ import org.springframework.security.core.userdetails.UserDetails;
/*    */ import org.springframework.security.core.userdetails.UserDetailsService;
/*    */ import org.springframework.security.core.userdetails.UsernameNotFoundException;
/*    */ import org.springframework.util.Assert;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Deprecated
/*    */ public class InMemoryDaoImpl
/*    */   implements UserDetailsService, InitializingBean
/*    */ {
/*    */   private UserMap userMap;
/*    */   
/*    */   public void afterPropertiesSet() throws Exception {
/* 44 */     Assert.notNull(this.userMap, "A list of users, passwords, enabled/disabled status and their granted authorities must be set");
/*    */   }
/*    */ 
/*    */   
/*    */   public UserMap getUserMap() {
/* 49 */     return this.userMap;
/*    */   }
/*    */   
/*    */   public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
/* 53 */     return this.userMap.getUser(username);
/*    */   }
/*    */   
/*    */   public void setUserMap(UserMap userMap) {
/* 57 */     this.userMap = userMap;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void setUserProperties(Properties props) {
/* 67 */     UserMap userMap = new UserMap();
/* 68 */     this.userMap = UserMapEditor.addUsersFromProperties(userMap, props);
/*    */   }
/*    */ }


/* Location:              C:\Users\Gcorp\Downloads\spring-security-core-3.2.0.RELEASE.jar!\org\springframework\security\cor\\userdetails\memory\InMemoryDaoImpl.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */