/*    */ package org.springframework.security.core.userdetails;
/*    */ 
/*    */ import org.springframework.beans.factory.InitializingBean;
/*    */ import org.springframework.security.core.Authentication;
/*    */ import org.springframework.util.Assert;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class UserDetailsByNameServiceWrapper<T extends Authentication>
/*    */   implements AuthenticationUserDetailsService<T>, InitializingBean
/*    */ {
/* 17 */   private UserDetailsService userDetailsService = null;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public UserDetailsByNameServiceWrapper() {}
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public UserDetailsByNameServiceWrapper(UserDetailsService userDetailsService) {
/* 33 */     Assert.notNull(userDetailsService, "userDetailsService cannot be null.");
/* 34 */     this.userDetailsService = userDetailsService;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void afterPropertiesSet() throws Exception {
/* 43 */     Assert.notNull(this.userDetailsService, "UserDetailsService must be set");
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public UserDetails loadUserDetails(T authentication) throws UsernameNotFoundException {
/* 51 */     return this.userDetailsService.loadUserByUsername(authentication.getName());
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void setUserDetailsService(UserDetailsService aUserDetailsService) {
/* 61 */     this.userDetailsService = aUserDetailsService;
/*    */   }
/*    */ }


/* Location:              C:\Users\Gcorp\Downloads\spring-security-core-3.2.0.RELEASE.jar!\org\springframework\security\cor\\userdetails\UserDetailsByNameServiceWrapper.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */