/*     */ package org.springframework.security.core.userdetails;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.Comparator;
/*     */ import java.util.Set;
/*     */ import java.util.SortedSet;
/*     */ import java.util.TreeSet;
/*     */ import org.springframework.security.core.CredentialsContainer;
/*     */ import org.springframework.security.core.GrantedAuthority;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class User
/*     */   implements UserDetails, CredentialsContainer
/*     */ {
/*     */   private static final long serialVersionUID = 320L;
/*     */   private String password;
/*     */   private final String username;
/*     */   private final Set<GrantedAuthority> authorities;
/*     */   private final boolean accountNonExpired;
/*     */   private final boolean accountNonLocked;
/*     */   private final boolean credentialsNonExpired;
/*     */   private final boolean enabled;
/*     */   
/*     */   public User(String username, String password, Collection<? extends GrantedAuthority> authorities) {
/*  69 */     this(username, password, true, true, true, true, authorities);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public User(String username, String password, boolean enabled, boolean accountNonExpired, boolean credentialsNonExpired, boolean accountNonLocked, Collection<? extends GrantedAuthority> authorities) {
/*  98 */     if (username == null || "".equals(username) || password == null) {
/*  99 */       throw new IllegalArgumentException("Cannot pass null or empty values to constructor");
/*     */     }
/*     */     
/* 102 */     this.username = username;
/* 103 */     this.password = password;
/* 104 */     this.enabled = enabled;
/* 105 */     this.accountNonExpired = accountNonExpired;
/* 106 */     this.credentialsNonExpired = credentialsNonExpired;
/* 107 */     this.accountNonLocked = accountNonLocked;
/* 108 */     this.authorities = Collections.unmodifiableSet(sortAuthorities(authorities));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Collection<GrantedAuthority> getAuthorities() {
/* 114 */     return this.authorities;
/*     */   }
/*     */   
/*     */   public String getPassword() {
/* 118 */     return this.password;
/*     */   }
/*     */   
/*     */   public String getUsername() {
/* 122 */     return this.username;
/*     */   }
/*     */   
/*     */   public boolean isEnabled() {
/* 126 */     return this.enabled;
/*     */   }
/*     */   
/*     */   public boolean isAccountNonExpired() {
/* 130 */     return this.accountNonExpired;
/*     */   }
/*     */   
/*     */   public boolean isAccountNonLocked() {
/* 134 */     return this.accountNonLocked;
/*     */   }
/*     */   
/*     */   public boolean isCredentialsNonExpired() {
/* 138 */     return this.credentialsNonExpired;
/*     */   }
/*     */   
/*     */   public void eraseCredentials() {
/* 142 */     this.password = null;
/*     */   }
/*     */   
/*     */   private static SortedSet<GrantedAuthority> sortAuthorities(Collection<? extends GrantedAuthority> authorities) {
/* 146 */     Assert.notNull(authorities, "Cannot pass a null GrantedAuthority collection");
/*     */     
/* 148 */     SortedSet<GrantedAuthority> sortedAuthorities = new TreeSet<GrantedAuthority>(new AuthorityComparator());
/*     */ 
/*     */     
/* 151 */     for (GrantedAuthority grantedAuthority : authorities) {
/* 152 */       Assert.notNull(grantedAuthority, "GrantedAuthority list cannot contain any null elements");
/* 153 */       sortedAuthorities.add(grantedAuthority);
/*     */     } 
/*     */     
/* 156 */     return sortedAuthorities;
/*     */   }
/*     */   
/*     */   private static class AuthorityComparator implements Comparator<GrantedAuthority>, Serializable {
/*     */     private static final long serialVersionUID = 320L;
/*     */     
/*     */     private AuthorityComparator() {}
/*     */     
/*     */     public int compare(GrantedAuthority g1, GrantedAuthority g2) {
/* 165 */       if (g2.getAuthority() == null) {
/* 166 */         return -1;
/*     */       }
/*     */       
/* 169 */       if (g1.getAuthority() == null) {
/* 170 */         return 1;
/*     */       }
/*     */       
/* 173 */       return g1.getAuthority().compareTo(g2.getAuthority());
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object rhs) {
/* 186 */     if (rhs instanceof User) {
/* 187 */       return this.username.equals(((User)rhs).username);
/*     */     }
/* 189 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 197 */     return this.username.hashCode();
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 202 */     StringBuilder sb = new StringBuilder();
/* 203 */     sb.append(super.toString()).append(": ");
/* 204 */     sb.append("Username: ").append(this.username).append("; ");
/* 205 */     sb.append("Password: [PROTECTED]; ");
/* 206 */     sb.append("Enabled: ").append(this.enabled).append("; ");
/* 207 */     sb.append("AccountNonExpired: ").append(this.accountNonExpired).append("; ");
/* 208 */     sb.append("credentialsNonExpired: ").append(this.credentialsNonExpired).append("; ");
/* 209 */     sb.append("AccountNonLocked: ").append(this.accountNonLocked).append("; ");
/*     */     
/* 211 */     if (!this.authorities.isEmpty()) {
/* 212 */       sb.append("Granted Authorities: ");
/*     */       
/* 214 */       boolean first = true;
/* 215 */       for (GrantedAuthority auth : this.authorities) {
/* 216 */         if (!first) {
/* 217 */           sb.append(",");
/*     */         }
/* 219 */         first = false;
/*     */         
/* 221 */         sb.append(auth);
/*     */       } 
/*     */     } else {
/* 224 */       sb.append("Not granted any authorities");
/*     */     } 
/*     */     
/* 227 */     return sb.toString();
/*     */   }
/*     */ }


/* Location:              C:\Users\Gcorp\Downloads\spring-security-core-3.2.0.RELEASE.jar!\org\springframework\security\cor\\userdetails\User.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */