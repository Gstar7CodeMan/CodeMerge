/*     */ package org.springframework.security.core.userdetails.jdbc;
/*     */ 
/*     */ import java.sql.ResultSet;
/*     */ import java.sql.SQLException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashSet;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ import org.springframework.context.ApplicationContextException;
/*     */ import org.springframework.context.support.MessageSourceAccessor;
/*     */ import org.springframework.jdbc.core.RowMapper;
/*     */ import org.springframework.jdbc.core.support.JdbcDaoSupport;
/*     */ import org.springframework.security.core.GrantedAuthority;
/*     */ import org.springframework.security.core.SpringSecurityMessageSource;
/*     */ import org.springframework.security.core.authority.AuthorityUtils;
/*     */ import org.springframework.security.core.authority.SimpleGrantedAuthority;
/*     */ import org.springframework.security.core.userdetails.User;
/*     */ import org.springframework.security.core.userdetails.UserDetails;
/*     */ import org.springframework.security.core.userdetails.UserDetailsService;
/*     */ import org.springframework.security.core.userdetails.UsernameNotFoundException;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class JdbcDaoImpl
/*     */   extends JdbcDaoSupport
/*     */   implements UserDetailsService
/*     */ {
/*     */   public static final String DEF_USERS_BY_USERNAME_QUERY = "select username,password,enabled from users where username = ?";
/*     */   public static final String DEF_AUTHORITIES_BY_USERNAME_QUERY = "select username,authority from authorities where username = ?";
/*     */   public static final String DEF_GROUP_AUTHORITIES_BY_USERNAME_QUERY = "select g.id, g.group_name, ga.authority from groups g, group_members gm, group_authorities ga where gm.username = ? and g.id = ga.group_id and g.id = gm.group_id";
/* 113 */   protected final MessageSourceAccessor messages = SpringSecurityMessageSource.getAccessor();
/*     */   
/*     */   private String authoritiesByUsernameQuery;
/*     */   private String groupAuthoritiesByUsernameQuery;
/*     */   private String usersByUsernameQuery;
/* 118 */   private String rolePrefix = "";
/*     */   
/*     */   private boolean usernameBasedPrimaryKey = true;
/*     */   
/*     */   private boolean enableAuthorities = true;
/*     */   private boolean enableGroups;
/*     */   
/*     */   public JdbcDaoImpl() {
/* 126 */     this.usersByUsernameQuery = "select username,password,enabled from users where username = ?";
/* 127 */     this.authoritiesByUsernameQuery = "select username,authority from authorities where username = ?";
/* 128 */     this.groupAuthoritiesByUsernameQuery = "select g.id, g.group_name, ga.authority from groups g, group_members gm, group_authorities ga where gm.username = ? and g.id = ga.group_id and g.id = gm.group_id";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void addCustomAuthorities(String username, List<GrantedAuthority> authorities) {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getUsersByUsernameQuery() {
/* 143 */     return this.usersByUsernameQuery;
/*     */   }
/*     */   
/*     */   protected void initDao() throws ApplicationContextException {
/* 147 */     Assert.isTrue((this.enableAuthorities || this.enableGroups), "Use of either authorities or groups must be enabled");
/*     */   }
/*     */   
/*     */   public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
/* 151 */     List<UserDetails> users = loadUsersByUsername(username);
/*     */     
/* 153 */     if (users.size() == 0) {
/* 154 */       this.logger.debug("Query returned no results for user '" + username + "'");
/*     */       
/* 156 */       throw new UsernameNotFoundException(this.messages.getMessage("JdbcDaoImpl.notFound", new Object[] { username }, "Username {0} not found"), username);
/*     */     } 
/*     */ 
/*     */     
/* 160 */     UserDetails user = users.get(0);
/*     */     
/* 162 */     Set<GrantedAuthority> dbAuthsSet = new HashSet<GrantedAuthority>();
/*     */     
/* 164 */     if (this.enableAuthorities) {
/* 165 */       dbAuthsSet.addAll(loadUserAuthorities(user.getUsername()));
/*     */     }
/*     */     
/* 168 */     if (this.enableGroups) {
/* 169 */       dbAuthsSet.addAll(loadGroupAuthorities(user.getUsername()));
/*     */     }
/*     */     
/* 172 */     List<GrantedAuthority> dbAuths = new ArrayList<GrantedAuthority>(dbAuthsSet);
/*     */     
/* 174 */     addCustomAuthorities(user.getUsername(), dbAuths);
/*     */     
/* 176 */     if (dbAuths.size() == 0) {
/* 177 */       this.logger.debug("User '" + username + "' has no authorities and will be treated as 'not found'");
/*     */       
/* 179 */       throw new UsernameNotFoundException(this.messages.getMessage("JdbcDaoImpl.noAuthority", new Object[] { username }, "User {0} has no GrantedAuthority"), username);
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 184 */     return createUserDetails(username, user, dbAuths);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected List<UserDetails> loadUsersByUsername(String username) {
/* 192 */     return getJdbcTemplate().query(this.usersByUsernameQuery, (Object[])new String[] { username }, new RowMapper<UserDetails>() {
/*     */           public UserDetails mapRow(ResultSet rs, int rowNum) throws SQLException {
/* 194 */             String username = rs.getString(1);
/* 195 */             String password = rs.getString(2);
/* 196 */             boolean enabled = rs.getBoolean(3);
/* 197 */             return (UserDetails)new User(username, password, enabled, true, true, true, AuthorityUtils.NO_AUTHORITIES);
/*     */           }
/*     */         });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected List<GrantedAuthority> loadUserAuthorities(String username) {
/* 209 */     return getJdbcTemplate().query(this.authoritiesByUsernameQuery, (Object[])new String[] { username }, new RowMapper<GrantedAuthority>() {
/*     */           public GrantedAuthority mapRow(ResultSet rs, int rowNum) throws SQLException {
/* 211 */             String roleName = JdbcDaoImpl.this.rolePrefix + rs.getString(2);
/*     */             
/* 213 */             return (GrantedAuthority)new SimpleGrantedAuthority(roleName);
/*     */           }
/*     */         });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected List<GrantedAuthority> loadGroupAuthorities(String username) {
/* 224 */     return getJdbcTemplate().query(this.groupAuthoritiesByUsernameQuery, (Object[])new String[] { username }, new RowMapper<GrantedAuthority>() {
/*     */           public GrantedAuthority mapRow(ResultSet rs, int rowNum) throws SQLException {
/* 226 */             String roleName = JdbcDaoImpl.this.getRolePrefix() + rs.getString(3);
/*     */             
/* 228 */             return (GrantedAuthority)new SimpleGrantedAuthority(roleName);
/*     */           }
/*     */         });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected UserDetails createUserDetails(String username, UserDetails userFromUserQuery, List<GrantedAuthority> combinedAuthorities) {
/* 244 */     String returnUsername = userFromUserQuery.getUsername();
/*     */     
/* 246 */     if (!this.usernameBasedPrimaryKey) {
/* 247 */       returnUsername = username;
/*     */     }
/*     */     
/* 250 */     return (UserDetails)new User(returnUsername, userFromUserQuery.getPassword(), userFromUserQuery.isEnabled(), true, true, true, combinedAuthorities);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setAuthoritiesByUsernameQuery(String queryString) {
/* 263 */     this.authoritiesByUsernameQuery = queryString;
/*     */   }
/*     */   
/*     */   protected String getAuthoritiesByUsernameQuery() {
/* 267 */     return this.authoritiesByUsernameQuery;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setGroupAuthoritiesByUsernameQuery(String queryString) {
/* 279 */     this.groupAuthoritiesByUsernameQuery = queryString;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setRolePrefix(String rolePrefix) {
/* 291 */     this.rolePrefix = rolePrefix;
/*     */   }
/*     */   
/*     */   protected String getRolePrefix() {
/* 295 */     return this.rolePrefix;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setUsernameBasedPrimaryKey(boolean usernameBasedPrimaryKey) {
/* 309 */     this.usernameBasedPrimaryKey = usernameBasedPrimaryKey;
/*     */   }
/*     */   
/*     */   protected boolean isUsernameBasedPrimaryKey() {
/* 313 */     return this.usernameBasedPrimaryKey;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setUsersByUsernameQuery(String usersByUsernameQueryString) {
/* 329 */     this.usersByUsernameQuery = usersByUsernameQueryString;
/*     */   }
/*     */   
/*     */   protected boolean getEnableAuthorities() {
/* 333 */     return this.enableAuthorities;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setEnableAuthorities(boolean enableAuthorities) {
/* 340 */     this.enableAuthorities = enableAuthorities;
/*     */   }
/*     */   
/*     */   protected boolean getEnableGroups() {
/* 344 */     return this.enableGroups;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setEnableGroups(boolean enableGroups) {
/* 352 */     this.enableGroups = enableGroups;
/*     */   }
/*     */ }


/* Location:              C:\Users\Gcorp\Downloads\spring-security-core-3.2.0.RELEASE.jar!\org\springframework\security\cor\\userdetails\jdbc\JdbcDaoImpl.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */