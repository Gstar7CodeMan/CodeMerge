package org.springframework.security.core.userdetails;

import java.io.Serializable;
import java.util.Collection;
import org.springframework.security.core.GrantedAuthority;

public interface UserDetails extends Serializable {
  Collection<? extends GrantedAuthority> getAuthorities();
  
  String getPassword();
  
  String getUsername();
  
  boolean isAccountNonExpired();
  
  boolean isAccountNonLocked();
  
  boolean isCredentialsNonExpired();
  
  boolean isEnabled();
}


/* Location:              C:\Users\Gcorp\Downloads\spring-security-core-3.2.0.RELEASE.jar!\org\springframework\security\cor\\userdetails\UserDetails.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */