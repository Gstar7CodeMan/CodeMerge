/*    */ package org.springframework.security.core.userdetails.cache;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ import net.sf.ehcache.Ehcache;
/*    */ import net.sf.ehcache.Element;
/*    */ import org.apache.commons.logging.Log;
/*    */ import org.apache.commons.logging.LogFactory;
/*    */ import org.springframework.beans.factory.InitializingBean;
/*    */ import org.springframework.security.core.userdetails.UserCache;
/*    */ import org.springframework.security.core.userdetails.UserDetails;
/*    */ import org.springframework.util.Assert;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class EhCacheBasedUserCache
/*    */   implements UserCache, InitializingBean
/*    */ {
/* 38 */   private static final Log logger = LogFactory.getLog(EhCacheBasedUserCache.class);
/*    */ 
/*    */ 
/*    */   
/*    */   private Ehcache cache;
/*    */ 
/*    */ 
/*    */   
/*    */   public void afterPropertiesSet() throws Exception {
/* 47 */     Assert.notNull(this.cache, "cache mandatory");
/*    */   }
/*    */   
/*    */   public Ehcache getCache() {
/* 51 */     return this.cache;
/*    */   }
/*    */   
/*    */   public UserDetails getUserFromCache(String username) {
/* 55 */     Element element = this.cache.get(username);
/*    */     
/* 57 */     if (logger.isDebugEnabled()) {
/* 58 */       logger.debug("Cache hit: " + ((element != null) ? 1 : 0) + "; username: " + username);
/*    */     }
/*    */     
/* 61 */     if (element == null) {
/* 62 */       return null;
/*    */     }
/* 64 */     return (UserDetails)element.getValue();
/*    */   }
/*    */ 
/*    */   
/*    */   public void putUserInCache(UserDetails user) {
/* 69 */     Element element = new Element(user.getUsername(), (Serializable)user);
/*    */     
/* 71 */     if (logger.isDebugEnabled()) {
/* 72 */       logger.debug("Cache put: " + element.getKey());
/*    */     }
/*    */     
/* 75 */     this.cache.put(element);
/*    */   }
/*    */   
/*    */   public void removeUserFromCache(UserDetails user) {
/* 79 */     if (logger.isDebugEnabled()) {
/* 80 */       logger.debug("Cache remove: " + user.getUsername());
/*    */     }
/*    */     
/* 83 */     removeUserFromCache(user.getUsername());
/*    */   }
/*    */   
/*    */   public void removeUserFromCache(String username) {
/* 87 */     this.cache.remove(username);
/*    */   }
/*    */   
/*    */   public void setCache(Ehcache cache) {
/* 91 */     this.cache = cache;
/*    */   }
/*    */ }


/* Location:              C:\Users\Gcorp\Downloads\spring-security-core-3.2.0.RELEASE.jar!\org\springframework\security\cor\\userdetails\cache\EhCacheBasedUserCache.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */