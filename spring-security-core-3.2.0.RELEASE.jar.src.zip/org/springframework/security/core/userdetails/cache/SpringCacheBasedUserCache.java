/*    */ package org.springframework.security.core.userdetails.cache;
/*    */ 
/*    */ import org.apache.commons.logging.Log;
/*    */ import org.apache.commons.logging.LogFactory;
/*    */ import org.springframework.cache.Cache;
/*    */ import org.springframework.security.core.userdetails.UserCache;
/*    */ import org.springframework.security.core.userdetails.UserDetails;
/*    */ import org.springframework.util.Assert;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SpringCacheBasedUserCache
/*    */   implements UserCache
/*    */ {
/* 21 */   private static final Log logger = LogFactory.getLog(SpringCacheBasedUserCache.class);
/*    */ 
/*    */ 
/*    */   
/*    */   private final Cache cache;
/*    */ 
/*    */ 
/*    */   
/*    */   public SpringCacheBasedUserCache(Cache cache) throws Exception {
/* 30 */     Assert.notNull(cache, "cache mandatory");
/* 31 */     this.cache = cache;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public UserDetails getUserFromCache(String username) {
/* 37 */     Cache.ValueWrapper element = (username != null) ? this.cache.get(username) : null;
/*    */     
/* 39 */     if (logger.isDebugEnabled()) {
/* 40 */       logger.debug("Cache hit: " + ((element != null) ? 1 : 0) + "; username: " + username);
/*    */     }
/*    */     
/* 43 */     if (element == null) {
/* 44 */       return null;
/*    */     }
/* 46 */     return (UserDetails)element.get();
/*    */   }
/*    */ 
/*    */   
/*    */   public void putUserInCache(UserDetails user) {
/* 51 */     if (logger.isDebugEnabled()) {
/* 52 */       logger.debug("Cache put: " + user.getUsername());
/*    */     }
/* 54 */     this.cache.put(user.getUsername(), user);
/*    */   }
/*    */   
/*    */   public void removeUserFromCache(UserDetails user) {
/* 58 */     if (logger.isDebugEnabled()) {
/* 59 */       logger.debug("Cache remove: " + user.getUsername());
/*    */     }
/*    */     
/* 62 */     removeUserFromCache(user.getUsername());
/*    */   }
/*    */   
/*    */   public void removeUserFromCache(String username) {
/* 66 */     this.cache.evict(username);
/*    */   }
/*    */ }


/* Location:              C:\Users\Gcorp\Downloads\spring-security-core-3.2.0.RELEASE.jar!\org\springframework\security\cor\\userdetails\cache\SpringCacheBasedUserCache.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */