package org.springframework.security.core.session;

@Deprecated
public interface SessionIdentifierAware {
  String getSessionId();
}


/* Location:              C:\Users\Gcorp\Downloads\spring-security-core-3.2.0.RELEASE.jar!\org\springframework\security\core\session\SessionIdentifierAware.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */