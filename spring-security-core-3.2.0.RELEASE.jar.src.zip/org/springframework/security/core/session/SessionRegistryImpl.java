/*     */ package org.springframework.security.core.session;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.Date;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ import java.util.concurrent.ConcurrentMap;
/*     */ import java.util.concurrent.CopyOnWriteArraySet;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.context.ApplicationEvent;
/*     */ import org.springframework.context.ApplicationListener;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SessionRegistryImpl
/*     */   implements SessionRegistry, ApplicationListener<SessionDestroyedEvent>
/*     */ {
/*  44 */   protected final Log logger = LogFactory.getLog(SessionRegistryImpl.class);
/*     */ 
/*     */   
/*  47 */   private final ConcurrentMap<Object, Set<String>> principals = new ConcurrentHashMap<Object, Set<String>>();
/*     */   
/*  49 */   private final Map<String, SessionInformation> sessionIds = new ConcurrentHashMap<String, SessionInformation>();
/*     */ 
/*     */ 
/*     */   
/*     */   public List<Object> getAllPrincipals() {
/*  54 */     return new ArrayList(this.principals.keySet());
/*     */   }
/*     */   
/*     */   public List<SessionInformation> getAllSessions(Object principal, boolean includeExpiredSessions) {
/*  58 */     Set<String> sessionsUsedByPrincipal = this.principals.get(principal);
/*     */     
/*  60 */     if (sessionsUsedByPrincipal == null) {
/*  61 */       return Collections.emptyList();
/*     */     }
/*     */     
/*  64 */     List<SessionInformation> list = new ArrayList<SessionInformation>(sessionsUsedByPrincipal.size());
/*     */     
/*  66 */     for (String sessionId : sessionsUsedByPrincipal) {
/*  67 */       SessionInformation sessionInformation = getSessionInformation(sessionId);
/*     */       
/*  69 */       if (sessionInformation == null) {
/*     */         continue;
/*     */       }
/*     */       
/*  73 */       if (includeExpiredSessions || !sessionInformation.isExpired()) {
/*  74 */         list.add(sessionInformation);
/*     */       }
/*     */     } 
/*     */     
/*  78 */     return list;
/*     */   }
/*     */   
/*     */   public SessionInformation getSessionInformation(String sessionId) {
/*  82 */     Assert.hasText(sessionId, "SessionId required as per interface contract");
/*     */     
/*  84 */     return this.sessionIds.get(sessionId);
/*     */   }
/*     */   
/*     */   public void onApplicationEvent(SessionDestroyedEvent event) {
/*  88 */     String sessionId = event.getId();
/*  89 */     removeSessionInformation(sessionId);
/*     */   }
/*     */   
/*     */   public void refreshLastRequest(String sessionId) {
/*  93 */     Assert.hasText(sessionId, "SessionId required as per interface contract");
/*     */     
/*  95 */     SessionInformation info = getSessionInformation(sessionId);
/*     */     
/*  97 */     if (info != null) {
/*  98 */       info.refreshLastRequest();
/*     */     }
/*     */   }
/*     */   
/*     */   public void registerNewSession(String sessionId, Object principal) {
/* 103 */     Assert.hasText(sessionId, "SessionId required as per interface contract");
/* 104 */     Assert.notNull(principal, "Principal required as per interface contract");
/*     */     
/* 106 */     if (this.logger.isDebugEnabled()) {
/* 107 */       this.logger.debug("Registering session " + sessionId + ", for principal " + principal);
/*     */     }
/*     */     
/* 110 */     if (getSessionInformation(sessionId) != null) {
/* 111 */       removeSessionInformation(sessionId);
/*     */     }
/*     */     
/* 114 */     this.sessionIds.put(sessionId, new SessionInformation(principal, sessionId, new Date()));
/*     */     
/* 116 */     Set<String> sessionsUsedByPrincipal = this.principals.get(principal);
/*     */     
/* 118 */     if (sessionsUsedByPrincipal == null) {
/* 119 */       sessionsUsedByPrincipal = new CopyOnWriteArraySet<String>();
/* 120 */       Set<String> prevSessionsUsedByPrincipal = this.principals.putIfAbsent(principal, sessionsUsedByPrincipal);
/*     */       
/* 122 */       if (prevSessionsUsedByPrincipal != null) {
/* 123 */         sessionsUsedByPrincipal = prevSessionsUsedByPrincipal;
/*     */       }
/*     */     } 
/*     */     
/* 127 */     sessionsUsedByPrincipal.add(sessionId);
/*     */     
/* 129 */     if (this.logger.isTraceEnabled()) {
/* 130 */       this.logger.trace("Sessions used by '" + principal + "' : " + sessionsUsedByPrincipal);
/*     */     }
/*     */   }
/*     */   
/*     */   public void removeSessionInformation(String sessionId) {
/* 135 */     Assert.hasText(sessionId, "SessionId required as per interface contract");
/*     */     
/* 137 */     SessionInformation info = getSessionInformation(sessionId);
/*     */     
/* 139 */     if (info == null) {
/*     */       return;
/*     */     }
/*     */     
/* 143 */     if (this.logger.isTraceEnabled()) {
/* 144 */       this.logger.debug("Removing session " + sessionId + " from set of registered sessions");
/*     */     }
/*     */     
/* 147 */     this.sessionIds.remove(sessionId);
/*     */     
/* 149 */     Set<String> sessionsUsedByPrincipal = this.principals.get(info.getPrincipal());
/*     */     
/* 151 */     if (sessionsUsedByPrincipal == null) {
/*     */       return;
/*     */     }
/*     */     
/* 155 */     if (this.logger.isDebugEnabled()) {
/* 156 */       this.logger.debug("Removing session " + sessionId + " from principal's set of registered sessions");
/*     */     }
/*     */     
/* 159 */     sessionsUsedByPrincipal.remove(sessionId);
/*     */     
/* 161 */     if (sessionsUsedByPrincipal.isEmpty()) {
/*     */       
/* 163 */       if (this.logger.isDebugEnabled()) {
/* 164 */         this.logger.debug("Removing principal " + info.getPrincipal() + " from registry");
/*     */       }
/* 166 */       this.principals.remove(info.getPrincipal());
/*     */     } 
/*     */     
/* 169 */     if (this.logger.isTraceEnabled())
/* 170 */       this.logger.trace("Sessions used by '" + info.getPrincipal() + "' : " + sessionsUsedByPrincipal); 
/*     */   }
/*     */ }


/* Location:              C:\Users\Gcorp\Downloads\spring-security-core-3.2.0.RELEASE.jar!\org\springframework\security\core\session\SessionRegistryImpl.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */