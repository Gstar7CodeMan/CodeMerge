/*    */ package org.springframework.security.core.session;
/*    */ 
/*    */ import org.springframework.context.ApplicationEvent;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class SessionCreationEvent
/*    */   extends ApplicationEvent
/*    */ {
/*    */   public SessionCreationEvent(Object source) {
/* 15 */     super(source);
/*    */   }
/*    */ }


/* Location:              C:\Users\Gcorp\Downloads\spring-security-core-3.2.0.RELEASE.jar!\org\springframework\security\core\session\SessionCreationEvent.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */