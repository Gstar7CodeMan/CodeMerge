/*    */ package org.springframework.security.core.session;
/*    */ 
/*    */ import java.util.List;
/*    */ import org.springframework.context.ApplicationEvent;
/*    */ import org.springframework.security.core.context.SecurityContext;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class SessionDestroyedEvent
/*    */   extends ApplicationEvent
/*    */ {
/*    */   public SessionDestroyedEvent(Object source) {
/* 18 */     super(source);
/*    */   }
/*    */   
/*    */   public abstract List<SecurityContext> getSecurityContexts();
/*    */   
/*    */   public abstract String getId();
/*    */ }


/* Location:              C:\Users\Gcorp\Downloads\spring-security-core-3.2.0.RELEASE.jar!\org\springframework\security\core\session\SessionDestroyedEvent.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */