/*    */ package org.springframework.security.core.session;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ import java.util.Date;
/*    */ import org.springframework.util.Assert;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SessionInformation
/*    */   implements Serializable
/*    */ {
/*    */   private static final long serialVersionUID = 320L;
/*    */   private Date lastRequest;
/*    */   private final Object principal;
/*    */   private final String sessionId;
/*    */   private boolean expired = false;
/*    */   
/*    */   public SessionInformation(Object principal, String sessionId, Date lastRequest) {
/* 52 */     Assert.notNull(principal, "Principal required");
/* 53 */     Assert.hasText(sessionId, "SessionId required");
/* 54 */     Assert.notNull(lastRequest, "LastRequest required");
/* 55 */     this.principal = principal;
/* 56 */     this.sessionId = sessionId;
/* 57 */     this.lastRequest = lastRequest;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void expireNow() {
/* 63 */     this.expired = true;
/*    */   }
/*    */   
/*    */   public Date getLastRequest() {
/* 67 */     return this.lastRequest;
/*    */   }
/*    */   
/*    */   public Object getPrincipal() {
/* 71 */     return this.principal;
/*    */   }
/*    */   
/*    */   public String getSessionId() {
/* 75 */     return this.sessionId;
/*    */   }
/*    */   
/*    */   public boolean isExpired() {
/* 79 */     return this.expired;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void refreshLastRequest() {
/* 86 */     this.lastRequest = new Date();
/*    */   }
/*    */ }


/* Location:              C:\Users\Gcorp\Downloads\spring-security-core-3.2.0.RELEASE.jar!\org\springframework\security\core\session\SessionInformation.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */