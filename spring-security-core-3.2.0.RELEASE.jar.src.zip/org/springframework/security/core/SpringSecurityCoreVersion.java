/*    */ package org.springframework.security.core;
/*    */ 
/*    */ import org.apache.commons.logging.Log;
/*    */ import org.apache.commons.logging.LogFactory;
/*    */ import org.springframework.core.SpringVersion;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SpringSecurityCoreVersion
/*    */ {
/* 14 */   private static final String DISABLE_CHECKS = SpringSecurityCoreVersion.class.getName().concat(".DISABLE_CHECKS");
/*    */   
/* 16 */   private static final Log logger = LogFactory.getLog(SpringSecurityCoreVersion.class);
/*    */ 
/*    */ 
/*    */   
/*    */   public static final long SERIAL_VERSION_UID = 320L;
/*    */ 
/*    */ 
/*    */   
/*    */   static final String MIN_SPRING_VERSION = "3.2.6.RELEASE";
/*    */ 
/*    */ 
/*    */   
/*    */   static {
/* 29 */     performVersionChecks();
/*    */   }
/*    */   
/*    */   public static String getVersion() {
/* 33 */     Package pkg = SpringSecurityCoreVersion.class.getPackage();
/* 34 */     return (pkg != null) ? pkg.getImplementationVersion() : null;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   private static void performVersionChecks() {
/* 42 */     String springVersion = SpringVersion.getVersion();
/* 43 */     String version = getVersion();
/*    */     
/* 45 */     if (disableChecks(springVersion, version)) {
/*    */       return;
/*    */     }
/*    */     
/* 49 */     logger.info("You are running with Spring Security Core " + version);
/* 50 */     if (springVersion.compareTo("3.2.6.RELEASE") < 0) {
/* 51 */       logger.warn("**** You are advised to use Spring 3.2.6.RELEASE or later with this version. You are running: " + springVersion);
/*    */     }
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   private static boolean disableChecks(String springVersion, String springSecurityVersion) {
/* 65 */     if (springVersion == null || springVersion.equals(springSecurityVersion)) {
/* 66 */       return true;
/*    */     }
/* 68 */     return Boolean.getBoolean(DISABLE_CHECKS);
/*    */   }
/*    */ }


/* Location:              C:\Users\Gcorp\Downloads\spring-security-core-3.2.0.RELEASE.jar!\org\springframework\security\core\SpringSecurityCoreVersion.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */