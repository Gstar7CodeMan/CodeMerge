/*     */ package org.springframework.security.core.parameters;
/*     */ 
/*     */ import java.util.Collections;
/*     */ import java.util.HashSet;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.core.LocalVariableTableParameterNameDiscoverer;
/*     */ import org.springframework.core.ParameterNameDiscoverer;
/*     */ import org.springframework.core.PrioritizedParameterNameDiscoverer;
/*     */ import org.springframework.security.access.method.P;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ClassUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DefaultSecurityParameterNameDiscoverer
/*     */   extends PrioritizedParameterNameDiscoverer
/*     */ {
/*  57 */   private final Log logger = LogFactory.getLog(getClass());
/*     */   
/*     */   private static final String DEFAULT_PARAMETER_NAME_DISCOVERER_CLASSNAME = "org.springframework.core.DefaultParameterNameDiscoverer";
/*     */   
/*  61 */   private static final boolean DEFAULT_PARAM_DISCOVERER_PRESENT = ClassUtils.isPresent("org.springframework.core.DefaultParameterNameDiscoverer", DefaultSecurityParameterNameDiscoverer.class.getClassLoader());
/*     */   
/*     */   private static final String DATA_PARAM_CLASSNAME = "org.springframework.data.repository.query.Param";
/*     */   
/*  65 */   private static final boolean DATA_PARAM_PRESENT = ClassUtils.isPresent("org.springframework.data.repository.query.Param", DefaultSecurityParameterNameDiscoverer.class.getClassLoader());
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DefaultSecurityParameterNameDiscoverer() {
/*  73 */     this(Collections.emptyList());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DefaultSecurityParameterNameDiscoverer(List<? extends ParameterNameDiscoverer> parameterNameDiscovers) {
/*  82 */     Assert.notNull(parameterNameDiscovers, "parameterNameDiscovers cannot be null");
/*  83 */     for (ParameterNameDiscoverer discover : parameterNameDiscovers) {
/*  84 */       addDiscoverer(discover);
/*     */     }
/*     */     
/*  87 */     Set<String> annotationClassesToUse = new HashSet<String>(2);
/*  88 */     annotationClassesToUse.add(P.class.getName());
/*  89 */     if (DATA_PARAM_PRESENT) {
/*  90 */       annotationClassesToUse.add("org.springframework.data.repository.query.Param");
/*     */     }
/*     */     
/*  93 */     addDiscoverer(new AnnotationParameterNameDiscoverer(annotationClassesToUse));
/*     */     
/*  95 */     if (DEFAULT_PARAM_DISCOVERER_PRESENT) {
/*     */       try {
/*  97 */         Class<? extends ParameterNameDiscoverer> paramNameDiscoverClass = ClassUtils.forName("org.springframework.core.DefaultParameterNameDiscoverer", getClass().getClassLoader());
/*     */ 
/*     */         
/* 100 */         addDiscoverer(paramNameDiscoverClass.newInstance());
/* 101 */       } catch (Exception e) {
/* 102 */         this.logger.warn("Could not use org.springframework.core.DefaultParameterNameDiscoverer. Falling back to LocalVariableTableParameterNameDiscoverer.", e);
/*     */ 
/*     */ 
/*     */         
/* 106 */         addDiscoverer((ParameterNameDiscoverer)new LocalVariableTableParameterNameDiscoverer());
/*     */       } 
/*     */     } else {
/* 109 */       addDiscoverer((ParameterNameDiscoverer)new LocalVariableTableParameterNameDiscoverer());
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\Gcorp\Downloads\spring-security-core-3.2.0.RELEASE.jar!\org\springframework\security\core\parameters\DefaultSecurityParameterNameDiscoverer.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */