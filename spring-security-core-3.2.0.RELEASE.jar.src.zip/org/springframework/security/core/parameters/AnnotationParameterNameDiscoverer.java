/*     */ package org.springframework.security.core.parameters;
/*     */ 
/*     */ import java.lang.annotation.Annotation;
/*     */ import java.lang.reflect.AccessibleObject;
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.Arrays;
/*     */ import java.util.HashSet;
/*     */ import java.util.Set;
/*     */ import org.springframework.core.BridgeMethodResolver;
/*     */ import org.springframework.core.ParameterNameDiscoverer;
/*     */ import org.springframework.core.annotation.AnnotationUtils;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ReflectionUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class AnnotationParameterNameDiscoverer
/*     */   implements ParameterNameDiscoverer
/*     */ {
/*     */   private final Set<String> annotationClassesToUse;
/*     */   
/*     */   public AnnotationParameterNameDiscoverer(String... annotationClassToUse) {
/*  97 */     this(new HashSet<String>(Arrays.asList(annotationClassToUse)));
/*     */   }
/*     */   
/*     */   public AnnotationParameterNameDiscoverer(Set<String> annotationClassesToUse) {
/* 101 */     Assert.notEmpty(annotationClassesToUse, "annotationClassesToUse cannot be null or empty");
/*     */     
/* 103 */     this.annotationClassesToUse = annotationClassesToUse;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String[] getParameterNames(Method method) {
/* 114 */     Method originalMethod = BridgeMethodResolver.findBridgedMethod(method);
/* 115 */     String[] paramNames = lookupParameterNames(METHOD_METHODPARAM_FACTORY, originalMethod);
/* 116 */     if (paramNames != null) {
/* 117 */       return paramNames;
/*     */     }
/* 119 */     Class<?> declaringClass = method.getDeclaringClass();
/* 120 */     Class<?>[] interfaces = declaringClass.getInterfaces();
/* 121 */     for (Class<?> intrfc : interfaces) {
/* 122 */       Method intrfcMethod = ReflectionUtils.findMethod(intrfc, method.getName(), method.getParameterTypes());
/* 123 */       if (intrfcMethod != null) {
/* 124 */         return lookupParameterNames(METHOD_METHODPARAM_FACTORY, intrfcMethod);
/*     */       }
/*     */     } 
/* 127 */     return paramNames;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String[] getParameterNames(Constructor<?> constructor) {
/* 138 */     return lookupParameterNames(CONSTRUCTOR_METHODPARAM_FACTORY, constructor);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private <T extends AccessibleObject> String[] lookupParameterNames(ParameterNameFactory<T> parameterNameFactory, T t) {
/* 151 */     int parameterCount = parameterNameFactory.getParamCount(t);
/* 152 */     String[] paramNames = new String[parameterCount];
/* 153 */     boolean found = false;
/* 154 */     for (int i = 0; i < parameterCount; i++) {
/* 155 */       Annotation[] annotations = parameterNameFactory.findAnnotationsAt(t, i);
/* 156 */       String parameterName = findParameterName(annotations);
/* 157 */       if (parameterName != null) {
/* 158 */         found = true;
/* 159 */         paramNames[i] = parameterName;
/*     */       } 
/*     */     } 
/* 162 */     return found ? paramNames : null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String findParameterName(Annotation[] parameterAnnotations) {
/* 175 */     for (Annotation paramAnnotation : parameterAnnotations) {
/* 176 */       if (this.annotationClassesToUse.contains(paramAnnotation.annotationType().getName()))
/*     */       {
/* 178 */         return (String)AnnotationUtils.getValue(paramAnnotation, "value");
/*     */       }
/*     */     } 
/*     */     
/* 182 */     return null;
/*     */   }
/*     */   
/* 185 */   private static final ParameterNameFactory<Constructor<?>> CONSTRUCTOR_METHODPARAM_FACTORY = new ParameterNameFactory<Constructor<?>>() {
/*     */       public int getParamCount(Constructor<?> constructor) {
/* 187 */         return (constructor.getParameterTypes()).length;
/*     */       }
/*     */       
/*     */       public Annotation[] findAnnotationsAt(Constructor<?> constructor, int index) {
/* 191 */         return constructor.getParameterAnnotations()[index];
/*     */       }
/*     */     };
/*     */   
/* 195 */   private static final ParameterNameFactory<Method> METHOD_METHODPARAM_FACTORY = new ParameterNameFactory<Method>() {
/*     */       public int getParamCount(Method method) {
/* 197 */         return (method.getParameterTypes()).length;
/*     */       }
/*     */       
/*     */       public Annotation[] findAnnotationsAt(Method method, int index) {
/* 201 */         return method.getParameterAnnotations()[index];
/*     */       }
/*     */     };
/*     */   
/*     */   private static interface ParameterNameFactory<T extends AccessibleObject> {
/*     */     int getParamCount(T param1T);
/*     */     
/*     */     Annotation[] findAnnotationsAt(T param1T, int param1Int);
/*     */   }
/*     */ }


/* Location:              C:\Users\Gcorp\Downloads\spring-security-core-3.2.0.RELEASE.jar!\org\springframework\security\core\parameters\AnnotationParameterNameDiscoverer.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */