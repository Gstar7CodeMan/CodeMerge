/*     */ package org.springframework.security.core.token;
/*     */ 
/*     */ import java.security.SecureRandom;
/*     */ import java.util.Date;
/*     */ import org.springframework.beans.factory.InitializingBean;
/*     */ import org.springframework.security.crypto.codec.Base64;
/*     */ import org.springframework.security.crypto.codec.Hex;
/*     */ import org.springframework.security.crypto.codec.Utf8;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class KeyBasedPersistenceTokenService
/*     */   implements TokenService, InitializingBean
/*     */ {
/*  56 */   private int pseudoRandomNumberBits = 256;
/*     */   private String serverSecret;
/*     */   private Integer serverInteger;
/*     */   private SecureRandom secureRandom;
/*     */   
/*     */   public Token allocateToken(String extendedInformation) {
/*  62 */     Assert.notNull(extendedInformation, "Must provided non-null extendedInformation (but it can be empty)");
/*  63 */     long creationTime = (new Date()).getTime();
/*  64 */     String serverSecret = computeServerSecretApplicableAt(creationTime);
/*  65 */     String pseudoRandomNumber = generatePseudoRandomNumber();
/*  66 */     String content = Long.toString(creationTime) + ":" + pseudoRandomNumber + ":" + extendedInformation;
/*     */ 
/*     */     
/*  69 */     String sha512Hex = Sha512DigestUtils.shaHex(content + ":" + serverSecret);
/*  70 */     String keyPayload = content + ":" + sha512Hex;
/*  71 */     String key = Utf8.decode(Base64.encode(Utf8.encode(keyPayload)));
/*     */     
/*  73 */     return new DefaultToken(key, creationTime, extendedInformation);
/*     */   }
/*     */   public Token verifyToken(String key) {
/*     */     long creationTime;
/*  77 */     if (key == null || "".equals(key)) {
/*  78 */       return null;
/*     */     }
/*  80 */     String[] tokens = StringUtils.delimitedListToStringArray(Utf8.decode(Base64.decode(Utf8.encode(key))), ":");
/*  81 */     Assert.isTrue((tokens.length >= 4), "Expected 4 or more tokens but found " + tokens.length);
/*     */ 
/*     */     
/*     */     try {
/*  85 */       creationTime = Long.decode(tokens[0]).longValue();
/*  86 */     } catch (NumberFormatException nfe) {
/*  87 */       throw new IllegalArgumentException("Expected number but found " + tokens[0]);
/*     */     } 
/*     */     
/*  90 */     String serverSecret = computeServerSecretApplicableAt(creationTime);
/*  91 */     String pseudoRandomNumber = tokens[1];
/*     */ 
/*     */     
/*  94 */     StringBuilder extendedInfo = new StringBuilder();
/*  95 */     for (int i = 2; i < tokens.length - 1; i++) {
/*  96 */       if (i > 2) {
/*  97 */         extendedInfo.append(":");
/*     */       }
/*  99 */       extendedInfo.append(tokens[i]);
/*     */     } 
/*     */     
/* 102 */     String sha1Hex = tokens[tokens.length - 1];
/*     */ 
/*     */     
/* 105 */     String content = Long.toString(creationTime) + ":" + pseudoRandomNumber + ":" + extendedInfo.toString();
/* 106 */     String expectedSha512Hex = Sha512DigestUtils.shaHex(content + ":" + serverSecret);
/* 107 */     Assert.isTrue(expectedSha512Hex.equals(sha1Hex), "Key verification failure");
/*     */     
/* 109 */     return new DefaultToken(key, creationTime, extendedInfo.toString());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String generatePseudoRandomNumber() {
/* 116 */     byte[] randomizedBits = new byte[this.pseudoRandomNumberBits];
/* 117 */     this.secureRandom.nextBytes(randomizedBits);
/* 118 */     return new String(Hex.encode(randomizedBits));
/*     */   }
/*     */   
/*     */   private String computeServerSecretApplicableAt(long time) {
/* 122 */     return this.serverSecret + ":" + (new Long(time % this.serverInteger.intValue())).intValue();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setServerSecret(String serverSecret) {
/* 129 */     this.serverSecret = serverSecret;
/*     */   }
/*     */   
/*     */   public void setSecureRandom(SecureRandom secureRandom) {
/* 133 */     this.secureRandom = secureRandom;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setPseudoRandomNumberBits(int pseudoRandomNumberBits) {
/* 140 */     Assert.isTrue((pseudoRandomNumberBits >= 0), "Must have a positive pseudo random number bit size");
/* 141 */     this.pseudoRandomNumberBits = pseudoRandomNumberBits;
/*     */   }
/*     */   
/*     */   public void setServerInteger(Integer serverInteger) {
/* 145 */     this.serverInteger = serverInteger;
/*     */   }
/*     */   
/*     */   public void afterPropertiesSet() throws Exception {
/* 149 */     Assert.hasText(this.serverSecret, "Server secret required");
/* 150 */     Assert.notNull(this.serverInteger, "Server integer required");
/* 151 */     Assert.notNull(this.secureRandom, "SecureRandom instance required");
/*     */   }
/*     */ }


/* Location:              C:\Users\Gcorp\Downloads\spring-security-core-3.2.0.RELEASE.jar!\org\springframework\security\core\token\KeyBasedPersistenceTokenService.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */