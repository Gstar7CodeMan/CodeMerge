/*    */ package org.springframework.security.core.token;
/*    */ 
/*    */ import java.util.Date;
/*    */ import org.springframework.util.Assert;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DefaultToken
/*    */   implements Token
/*    */ {
/*    */   private final String key;
/*    */   private final long keyCreationTime;
/*    */   private final String extendedInformation;
/*    */   
/*    */   public DefaultToken(String key, long keyCreationTime, String extendedInformation) {
/* 19 */     Assert.hasText(key, "Key required");
/* 20 */     Assert.notNull(extendedInformation, "Extended information cannot be null");
/* 21 */     this.key = key;
/* 22 */     this.keyCreationTime = keyCreationTime;
/* 23 */     this.extendedInformation = extendedInformation;
/*    */   }
/*    */   
/*    */   public String getKey() {
/* 27 */     return this.key;
/*    */   }
/*    */   
/*    */   public long getKeyCreationTime() {
/* 31 */     return this.keyCreationTime;
/*    */   }
/*    */   
/*    */   public String getExtendedInformation() {
/* 35 */     return this.extendedInformation;
/*    */   }
/*    */   
/*    */   public boolean equals(Object obj) {
/* 39 */     if (obj != null && obj instanceof DefaultToken) {
/* 40 */       DefaultToken rhs = (DefaultToken)obj;
/* 41 */       return (this.key.equals(rhs.key) && this.keyCreationTime == rhs.keyCreationTime && this.extendedInformation.equals(rhs.extendedInformation));
/*    */     } 
/* 43 */     return false;
/*    */   }
/*    */   
/*    */   public int hashCode() {
/* 47 */     int code = 979;
/* 48 */     code *= this.key.hashCode();
/* 49 */     code *= (new Long(this.keyCreationTime)).hashCode();
/* 50 */     code *= this.extendedInformation.hashCode();
/* 51 */     return code;
/*    */   }
/*    */   
/*    */   public String toString() {
/* 55 */     return "DefaultToken[key=" + this.key + "; creation=" + new Date(this.keyCreationTime) + "; extended=" + this.extendedInformation + "]";
/*    */   }
/*    */ }


/* Location:              C:\Users\Gcorp\Downloads\spring-security-core-3.2.0.RELEASE.jar!\org\springframework\security\core\token\DefaultToken.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */