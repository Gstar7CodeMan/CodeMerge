/*    */ package org.springframework.security.core.token;
/*    */ 
/*    */ import java.security.MessageDigest;
/*    */ import java.security.NoSuchAlgorithmException;
/*    */ import org.springframework.security.crypto.codec.Hex;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class Sha512DigestUtils
/*    */ {
/*    */   private static MessageDigest getSha512Digest() {
/*    */     try {
/* 29 */       return MessageDigest.getInstance("SHA-512");
/* 30 */     } catch (NoSuchAlgorithmException e) {
/* 31 */       throw new RuntimeException(e.getMessage());
/*    */     } 
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static byte[] sha(byte[] data) {
/* 43 */     return getSha512Digest().digest(data);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static byte[] sha(String data) {
/* 54 */     return sha(data.getBytes());
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static String shaHex(byte[] data) {
/* 64 */     return new String(Hex.encode(sha(data)));
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static String shaHex(String data) {
/* 74 */     return new String(Hex.encode(sha(data)));
/*    */   }
/*    */ }


/* Location:              C:\Users\Gcorp\Downloads\spring-security-core-3.2.0.RELEASE.jar!\org\springframework\security\core\token\Sha512DigestUtils.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */