package org.springframework.security.core.token;

public interface TokenService {
  Token allocateToken(String paramString);
  
  Token verifyToken(String paramString);
}


/* Location:              C:\Users\Gcorp\Downloads\spring-security-core-3.2.0.RELEASE.jar!\org\springframework\security\core\token\TokenService.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */