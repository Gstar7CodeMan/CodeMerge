/*    */ package org.springframework.security.core.token;
/*    */ 
/*    */ import java.security.SecureRandom;
/*    */ import org.springframework.beans.factory.FactoryBean;
/*    */ import org.springframework.core.io.Resource;
/*    */ import org.springframework.util.Assert;
/*    */ import org.springframework.util.FileCopyUtils;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SecureRandomFactoryBean
/*    */   implements FactoryBean<SecureRandom>
/*    */ {
/* 19 */   private String algorithm = "SHA1PRNG";
/*    */   private Resource seed;
/*    */   
/*    */   public SecureRandom getObject() throws Exception {
/* 23 */     SecureRandom rnd = SecureRandom.getInstance(this.algorithm);
/*    */     
/* 25 */     if (this.seed != null) {
/*    */       
/* 27 */       byte[] seedBytes = FileCopyUtils.copyToByteArray(this.seed.getInputStream());
/* 28 */       rnd.setSeed(seedBytes);
/*    */     } else {
/*    */       
/* 31 */       rnd.nextBytes(new byte[1]);
/*    */     } 
/*    */     
/* 34 */     return rnd;
/*    */   }
/*    */   
/*    */   public Class<SecureRandom> getObjectType() {
/* 38 */     return SecureRandom.class;
/*    */   }
/*    */   
/*    */   public boolean isSingleton() {
/* 42 */     return false;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void setAlgorithm(String algorithm) {
/* 51 */     Assert.hasText(algorithm, "Algorithm required");
/* 52 */     this.algorithm = algorithm;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void setSeed(Resource seed) {
/* 65 */     this.seed = seed;
/*    */   }
/*    */ }


/* Location:              C:\Users\Gcorp\Downloads\spring-security-core-3.2.0.RELEASE.jar!\org\springframework\security\core\token\SecureRandomFactoryBean.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */