package org.springframework.security.core.token;

public interface Token {
  String getKey();
  
  long getKeyCreationTime();
  
  String getExtendedInformation();
}


/* Location:              C:\Users\Gcorp\Downloads\spring-security-core-3.2.0.RELEASE.jar!\org\springframework\security\core\token\Token.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */