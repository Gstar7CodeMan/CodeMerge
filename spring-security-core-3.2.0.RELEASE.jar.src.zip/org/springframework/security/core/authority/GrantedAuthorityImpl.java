/*    */ package org.springframework.security.core.authority;
/*    */ 
/*    */ import org.springframework.security.core.GrantedAuthority;
/*    */ import org.springframework.util.Assert;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Deprecated
/*    */ public class GrantedAuthorityImpl
/*    */   implements GrantedAuthority
/*    */ {
/*    */   private static final long serialVersionUID = 320L;
/*    */   private final String role;
/*    */   
/*    */   public GrantedAuthorityImpl(String role) {
/* 45 */     Assert.hasText(role, "A granted authority textual representation is required");
/* 46 */     this.role = role;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean equals(Object obj) {
/* 52 */     if (obj instanceof String) {
/* 53 */       return obj.equals(this.role);
/*    */     }
/*    */     
/* 56 */     if (obj instanceof GrantedAuthority) {
/* 57 */       GrantedAuthority attr = (GrantedAuthority)obj;
/*    */       
/* 59 */       return this.role.equals(attr.getAuthority());
/*    */     } 
/*    */     
/* 62 */     return false;
/*    */   }
/*    */   
/*    */   public String getAuthority() {
/* 66 */     return this.role;
/*    */   }
/*    */   
/*    */   public int hashCode() {
/* 70 */     return this.role.hashCode();
/*    */   }
/*    */   
/*    */   public String toString() {
/* 74 */     return this.role;
/*    */   }
/*    */ }


/* Location:              C:\Users\Gcorp\Downloads\spring-security-core-3.2.0.RELEASE.jar!\org\springframework\security\core\authority\GrantedAuthorityImpl.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */