/*    */ package org.springframework.security.core.authority.mapping;
/*    */ 
/*    */ import java.util.Collection;
/*    */ import java.util.HashSet;
/*    */ import java.util.Set;
/*    */ import org.springframework.beans.factory.InitializingBean;
/*    */ import org.springframework.security.core.GrantedAuthority;
/*    */ import org.springframework.security.core.authority.SimpleGrantedAuthority;
/*    */ import org.springframework.util.Assert;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class SimpleAuthorityMapper
/*    */   implements GrantedAuthoritiesMapper, InitializingBean
/*    */ {
/*    */   private GrantedAuthority defaultAuthority;
/* 19 */   private String prefix = "ROLE_";
/*    */   private boolean convertToUpperCase = false;
/*    */   private boolean convertToLowerCase = false;
/*    */   
/*    */   public void afterPropertiesSet() throws Exception {
/* 24 */     Assert.isTrue((!this.convertToUpperCase || !this.convertToLowerCase), "Either convertToUpperCase or convertToLowerCase can be set to true, but not both");
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Set<GrantedAuthority> mapAuthorities(Collection<? extends GrantedAuthority> authorities) {
/* 38 */     HashSet<GrantedAuthority> mapped = new HashSet<GrantedAuthority>(authorities.size());
/* 39 */     for (GrantedAuthority authority : authorities) {
/* 40 */       mapped.add(mapAuthority(authority.getAuthority()));
/*    */     }
/*    */     
/* 43 */     if (this.defaultAuthority != null) {
/* 44 */       mapped.add(this.defaultAuthority);
/*    */     }
/*    */     
/* 47 */     return mapped;
/*    */   }
/*    */   
/*    */   private GrantedAuthority mapAuthority(String name) {
/* 51 */     if (this.convertToUpperCase) {
/* 52 */       name = name.toUpperCase();
/* 53 */     } else if (this.convertToLowerCase) {
/* 54 */       name = name.toLowerCase();
/*    */     } 
/*    */     
/* 57 */     if (this.prefix.length() > 0 && !name.startsWith(this.prefix)) {
/* 58 */       name = this.prefix + name;
/*    */     }
/*    */     
/* 61 */     return (GrantedAuthority)new SimpleGrantedAuthority(name);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void setPrefix(String prefix) {
/* 70 */     Assert.notNull(prefix, "prefix cannot be null");
/* 71 */     this.prefix = prefix;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void setConvertToUpperCase(boolean convertToUpperCase) {
/* 80 */     this.convertToUpperCase = convertToUpperCase;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void setConvertToLowerCase(boolean convertToLowerCase) {
/* 89 */     this.convertToLowerCase = convertToLowerCase;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void setDefaultAuthority(String authority) {
/* 98 */     Assert.hasText(authority, "The authority name cannot be set to an empty value");
/* 99 */     this.defaultAuthority = (GrantedAuthority)new SimpleGrantedAuthority(authority);
/*    */   }
/*    */ }


/* Location:              C:\Users\Gcorp\Downloads\spring-security-core-3.2.0.RELEASE.jar!\org\springframework\security\core\authority\mapping\SimpleAuthorityMapper.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */