/*     */ package org.springframework.security.core.authority.mapping;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import java.util.StringTokenizer;
/*     */ import org.springframework.beans.factory.InitializingBean;
/*     */ import org.springframework.security.core.GrantedAuthority;
/*     */ import org.springframework.security.core.authority.SimpleGrantedAuthority;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ 
/*     */ public class MapBasedAttributes2GrantedAuthoritiesMapper
/*     */   implements Attributes2GrantedAuthoritiesMapper, MappableAttributesRetriever, InitializingBean
/*     */ {
/*  21 */   private Map<String, Collection<GrantedAuthority>> attributes2grantedAuthoritiesMap = null;
/*  22 */   private String stringSeparator = ",";
/*  23 */   private Set<String> mappableAttributes = null;
/*     */ 
/*     */   
/*     */   public void afterPropertiesSet() throws Exception {
/*  27 */     Assert.notNull(this.attributes2grantedAuthoritiesMap, "attributes2grantedAuthoritiesMap must be set");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<GrantedAuthority> getGrantedAuthorities(Collection<String> attributes) {
/*  34 */     ArrayList<GrantedAuthority> gaList = new ArrayList<GrantedAuthority>();
/*  35 */     for (String attribute : attributes) {
/*  36 */       Collection<GrantedAuthority> c = this.attributes2grantedAuthoritiesMap.get(attribute);
/*  37 */       if (c != null) gaList.addAll(c); 
/*     */     } 
/*  39 */     gaList.trimToSize();
/*     */     
/*  41 */     return gaList;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Map<String, Collection<GrantedAuthority>> getAttributes2grantedAuthoritiesMap() {
/*  48 */     return this.attributes2grantedAuthoritiesMap;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void setAttributes2grantedAuthoritiesMap(Map<?, ?> attributes2grantedAuthoritiesMap) {
/*  54 */     Assert.notEmpty(attributes2grantedAuthoritiesMap, "A non-empty attributes2grantedAuthoritiesMap must be supplied");
/*  55 */     this.attributes2grantedAuthoritiesMap = preProcessMap(attributes2grantedAuthoritiesMap);
/*     */     
/*  57 */     this.mappableAttributes = Collections.unmodifiableSet(this.attributes2grantedAuthoritiesMap.keySet());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Map<String, Collection<GrantedAuthority>> preProcessMap(Map<?, ?> orgMap) {
/*  67 */     Map<String, Collection<GrantedAuthority>> result = new HashMap<String, Collection<GrantedAuthority>>(orgMap.size());
/*     */ 
/*     */     
/*  70 */     for (Map.Entry<?, ?> entry : orgMap.entrySet()) {
/*  71 */       Assert.isInstanceOf(String.class, entry.getKey(), "attributes2grantedAuthoritiesMap contains non-String objects as keys");
/*     */       
/*  73 */       result.put((String)entry.getKey(), getGrantedAuthorityCollection(entry.getValue()));
/*     */     } 
/*  75 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Collection<GrantedAuthority> getGrantedAuthorityCollection(Object value) {
/*  86 */     Collection<GrantedAuthority> result = new ArrayList<GrantedAuthority>();
/*  87 */     addGrantedAuthorityCollection(result, value);
/*  88 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void addGrantedAuthorityCollection(Collection<GrantedAuthority> result, Object value) {
/* 100 */     if (value == null) {
/*     */       return;
/*     */     }
/* 103 */     if (value instanceof Collection) {
/* 104 */       addGrantedAuthorityCollection(result, (Collection)value);
/* 105 */     } else if (value instanceof Object[]) {
/* 106 */       addGrantedAuthorityCollection(result, (Object[])value);
/* 107 */     } else if (value instanceof String) {
/* 108 */       addGrantedAuthorityCollection(result, (String)value);
/* 109 */     } else if (value instanceof GrantedAuthority) {
/* 110 */       result.add((GrantedAuthority)value);
/*     */     } else {
/* 112 */       throw new IllegalArgumentException("Invalid object type: " + value.getClass().getName());
/*     */     } 
/*     */   }
/*     */   
/*     */   private void addGrantedAuthorityCollection(Collection<GrantedAuthority> result, Collection<?> value) {
/* 117 */     for (Object elt : value) {
/* 118 */       addGrantedAuthorityCollection(result, elt);
/*     */     }
/*     */   }
/*     */   
/*     */   private void addGrantedAuthorityCollection(Collection<GrantedAuthority> result, Object[] value) {
/* 123 */     for (Object aValue : value) {
/* 124 */       addGrantedAuthorityCollection(result, aValue);
/*     */     }
/*     */   }
/*     */   
/*     */   private void addGrantedAuthorityCollection(Collection<GrantedAuthority> result, String value) {
/* 129 */     StringTokenizer st = new StringTokenizer(value, this.stringSeparator, false);
/* 130 */     while (st.hasMoreTokens()) {
/* 131 */       String nextToken = st.nextToken();
/* 132 */       if (StringUtils.hasText(nextToken)) {
/* 133 */         result.add(new SimpleGrantedAuthority(nextToken));
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Set<String> getMappableAttributes() {
/* 143 */     return this.mappableAttributes;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String getStringSeparator() {
/* 149 */     return this.stringSeparator;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void setStringSeparator(String stringSeparator) {
/* 155 */     this.stringSeparator = stringSeparator;
/*     */   }
/*     */ }


/* Location:              C:\Users\Gcorp\Downloads\spring-security-core-3.2.0.RELEASE.jar!\org\springframework\security\core\authority\mapping\MapBasedAttributes2GrantedAuthoritiesMapper.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */