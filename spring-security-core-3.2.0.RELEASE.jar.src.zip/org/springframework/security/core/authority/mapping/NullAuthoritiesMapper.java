/*    */ package org.springframework.security.core.authority.mapping;
/*    */ 
/*    */ import java.util.Collection;
/*    */ import org.springframework.security.core.GrantedAuthority;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class NullAuthoritiesMapper
/*    */   implements GrantedAuthoritiesMapper
/*    */ {
/*    */   public Collection<? extends GrantedAuthority> mapAuthorities(Collection<? extends GrantedAuthority> authorities) {
/* 12 */     return authorities;
/*    */   }
/*    */ }


/* Location:              C:\Users\Gcorp\Downloads\spring-security-core-3.2.0.RELEASE.jar!\org\springframework\security\core\authority\mapping\NullAuthoritiesMapper.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */