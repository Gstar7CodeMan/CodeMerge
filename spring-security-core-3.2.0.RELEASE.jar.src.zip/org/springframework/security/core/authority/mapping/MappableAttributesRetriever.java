package org.springframework.security.core.authority.mapping;

import java.util.Set;

public interface MappableAttributesRetriever {
  Set<String> getMappableAttributes();
}


/* Location:              C:\Users\Gcorp\Downloads\spring-security-core-3.2.0.RELEASE.jar!\org\springframework\security\core\authority\mapping\MappableAttributesRetriever.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */