/*     */ package org.springframework.security.core.authority.mapping;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.List;
/*     */ import java.util.Locale;
/*     */ import org.springframework.beans.factory.InitializingBean;
/*     */ import org.springframework.security.core.GrantedAuthority;
/*     */ import org.springframework.security.core.authority.SimpleGrantedAuthority;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SimpleAttributes2GrantedAuthoritiesMapper
/*     */   implements Attributes2GrantedAuthoritiesMapper, InitializingBean
/*     */ {
/*  28 */   private String attributePrefix = "ROLE_";
/*     */ 
/*     */   
/*     */   private boolean convertAttributeToUpperCase = false;
/*     */ 
/*     */   
/*     */   private boolean convertAttributeToLowerCase = false;
/*     */   
/*     */   private boolean addPrefixIfAlreadyExisting = false;
/*     */ 
/*     */   
/*     */   public void afterPropertiesSet() throws Exception {
/*  40 */     Assert.isTrue((!isConvertAttributeToUpperCase() || !isConvertAttributeToLowerCase()), "Either convertAttributeToUpperCase or convertAttributeToLowerCase can be set to true, but not both");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<GrantedAuthority> getGrantedAuthorities(Collection<String> attributes) {
/*  48 */     List<GrantedAuthority> result = new ArrayList<GrantedAuthority>(attributes.size());
/*  49 */     for (String attribute : attributes) {
/*  50 */       result.add(getGrantedAuthority(attribute));
/*     */     }
/*  52 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private GrantedAuthority getGrantedAuthority(String attribute) {
/*  64 */     if (isConvertAttributeToLowerCase()) {
/*  65 */       attribute = attribute.toLowerCase(Locale.getDefault());
/*  66 */     } else if (isConvertAttributeToUpperCase()) {
/*  67 */       attribute = attribute.toUpperCase(Locale.getDefault());
/*     */     } 
/*  69 */     if (isAddPrefixIfAlreadyExisting() || !attribute.startsWith(getAttributePrefix())) {
/*  70 */       return (GrantedAuthority)new SimpleGrantedAuthority(getAttributePrefix() + attribute);
/*     */     }
/*  72 */     return (GrantedAuthority)new SimpleGrantedAuthority(attribute);
/*     */   }
/*     */ 
/*     */   
/*     */   private boolean isConvertAttributeToLowerCase() {
/*  77 */     return this.convertAttributeToLowerCase;
/*     */   }
/*     */   
/*     */   public void setConvertAttributeToLowerCase(boolean b) {
/*  81 */     this.convertAttributeToLowerCase = b;
/*     */   }
/*     */   
/*     */   private boolean isConvertAttributeToUpperCase() {
/*  85 */     return this.convertAttributeToUpperCase;
/*     */   }
/*     */   
/*     */   public void setConvertAttributeToUpperCase(boolean b) {
/*  89 */     this.convertAttributeToUpperCase = b;
/*     */   }
/*     */   
/*     */   private String getAttributePrefix() {
/*  93 */     return (this.attributePrefix == null) ? "" : this.attributePrefix;
/*     */   }
/*     */   
/*     */   public void setAttributePrefix(String string) {
/*  97 */     this.attributePrefix = string;
/*     */   }
/*     */   
/*     */   private boolean isAddPrefixIfAlreadyExisting() {
/* 101 */     return this.addPrefixIfAlreadyExisting;
/*     */   }
/*     */   
/*     */   public void setAddPrefixIfAlreadyExisting(boolean b) {
/* 105 */     this.addPrefixIfAlreadyExisting = b;
/*     */   }
/*     */ }


/* Location:              C:\Users\Gcorp\Downloads\spring-security-core-3.2.0.RELEASE.jar!\org\springframework\security\core\authority\mapping\SimpleAttributes2GrantedAuthoritiesMapper.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */