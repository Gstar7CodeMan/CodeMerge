/*    */ package org.springframework.security.core.authority.mapping;
/*    */ 
/*    */ import java.util.Collections;
/*    */ import java.util.HashSet;
/*    */ import java.util.Set;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SimpleMappableAttributesRetriever
/*    */   implements MappableAttributesRetriever
/*    */ {
/* 16 */   private Set<String> mappableAttributes = null;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Set<String> getMappableAttributes() {
/* 24 */     return this.mappableAttributes;
/*    */   }
/*    */   
/*    */   public void setMappableAttributes(Set<String> aMappableRoles) {
/* 28 */     this.mappableAttributes = new HashSet<String>();
/* 29 */     this.mappableAttributes.addAll(aMappableRoles);
/* 30 */     this.mappableAttributes = Collections.unmodifiableSet(this.mappableAttributes);
/*    */   }
/*    */ }


/* Location:              C:\Users\Gcorp\Downloads\spring-security-core-3.2.0.RELEASE.jar!\org\springframework\security\core\authority\mapping\SimpleMappableAttributesRetriever.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */