/*    */ package org.springframework.security.core.authority;
/*    */ 
/*    */ import org.springframework.security.core.GrantedAuthority;
/*    */ import org.springframework.util.Assert;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class SimpleGrantedAuthority
/*    */   implements GrantedAuthority
/*    */ {
/*    */   private static final long serialVersionUID = 320L;
/*    */   private final String role;
/*    */   
/*    */   public SimpleGrantedAuthority(String role) {
/* 23 */     Assert.hasText(role, "A granted authority textual representation is required");
/* 24 */     this.role = role;
/*    */   }
/*    */   
/*    */   public String getAuthority() {
/* 28 */     return this.role;
/*    */   }
/*    */   
/*    */   public boolean equals(Object obj) {
/* 32 */     if (this == obj) {
/* 33 */       return true;
/*    */     }
/*    */     
/* 36 */     if (obj instanceof SimpleGrantedAuthority) {
/* 37 */       return this.role.equals(((SimpleGrantedAuthority)obj).role);
/*    */     }
/*    */     
/* 40 */     return false;
/*    */   }
/*    */   
/*    */   public int hashCode() {
/* 44 */     return this.role.hashCode();
/*    */   }
/*    */   
/*    */   public String toString() {
/* 48 */     return this.role;
/*    */   }
/*    */ }


/* Location:              C:\Users\Gcorp\Downloads\spring-security-core-3.2.0.RELEASE.jar!\org\springframework\security\core\authority\SimpleGrantedAuthority.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */