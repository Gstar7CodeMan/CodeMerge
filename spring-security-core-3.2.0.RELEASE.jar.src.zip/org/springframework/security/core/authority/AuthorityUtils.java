/*    */ package org.springframework.security.core.authority;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.Collection;
/*    */ import java.util.Collections;
/*    */ import java.util.HashSet;
/*    */ import java.util.List;
/*    */ import java.util.Set;
/*    */ import org.springframework.security.core.GrantedAuthority;
/*    */ import org.springframework.util.StringUtils;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class AuthorityUtils
/*    */ {
/* 21 */   public static final List<GrantedAuthority> NO_AUTHORITIES = Collections.emptyList();
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static List<GrantedAuthority> commaSeparatedStringToAuthorityList(String authorityString) {
/* 31 */     return createAuthorityList(StringUtils.tokenizeToStringArray(authorityString, ","));
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static Set<String> authorityListToSet(Collection<? extends GrantedAuthority> userAuthorities) {
/* 39 */     Set<String> set = new HashSet<String>(userAuthorities.size());
/*    */     
/* 41 */     for (GrantedAuthority authority : userAuthorities) {
/* 42 */       set.add(authority.getAuthority());
/*    */     }
/*    */     
/* 45 */     return set;
/*    */   }
/*    */   
/*    */   public static List<GrantedAuthority> createAuthorityList(String... roles) {
/* 49 */     List<GrantedAuthority> authorities = new ArrayList<GrantedAuthority>(roles.length);
/*    */     
/* 51 */     for (String role : roles) {
/* 52 */       authorities.add(new SimpleGrantedAuthority(role));
/*    */     }
/*    */     
/* 55 */     return authorities;
/*    */   }
/*    */ }


/* Location:              C:\Users\Gcorp\Downloads\spring-security-core-3.2.0.RELEASE.jar!\org\springframework\security\core\authority\AuthorityUtils.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */