/*    */ package org.springframework.security.core.authority;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.Collection;
/*    */ import java.util.Collections;
/*    */ import java.util.List;
/*    */ import org.springframework.security.core.GrantedAuthority;
/*    */ import org.springframework.util.Assert;
/*    */ 
/*    */ @Deprecated
/*    */ public class GrantedAuthoritiesContainerImpl
/*    */   implements MutableGrantedAuthoritiesContainer {
/*    */   private static final long serialVersionUID = 320L;
/*    */   private List<GrantedAuthority> authorities;
/*    */   
/*    */   public void setGrantedAuthorities(Collection<? extends GrantedAuthority> newAuthorities) {
/* 17 */     ArrayList<GrantedAuthority> temp = new ArrayList<GrantedAuthority>(newAuthorities.size());
/* 18 */     temp.addAll(newAuthorities);
/* 19 */     this.authorities = Collections.unmodifiableList(temp);
/*    */   }
/*    */   
/*    */   public List<GrantedAuthority> getGrantedAuthorities() {
/* 23 */     Assert.notNull(this.authorities, "Granted authorities have not been set");
/* 24 */     return this.authorities;
/*    */   }
/*    */   
/*    */   public String toString() {
/* 28 */     StringBuilder sb = new StringBuilder();
/* 29 */     sb.append("Authorities: ").append(this.authorities);
/* 30 */     return sb.toString();
/*    */   }
/*    */ }


/* Location:              C:\Users\Gcorp\Downloads\spring-security-core-3.2.0.RELEASE.jar!\org\springframework\security\core\authority\GrantedAuthoritiesContainerImpl.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */