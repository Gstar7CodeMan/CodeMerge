package org.springframework.security.core;

public interface CredentialsContainer {
  void eraseCredentials();
}


/* Location:              C:\Users\Gcorp\Downloads\spring-security-core-3.2.0.RELEASE.jar!\org\springframework\security\core\CredentialsContainer.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */