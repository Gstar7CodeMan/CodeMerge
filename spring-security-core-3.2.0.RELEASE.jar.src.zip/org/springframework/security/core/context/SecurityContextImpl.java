/*    */ package org.springframework.security.core.context;
/*    */ 
/*    */ import org.springframework.security.core.Authentication;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SecurityContextImpl
/*    */   implements SecurityContext
/*    */ {
/*    */   private static final long serialVersionUID = 320L;
/*    */   private Authentication authentication;
/*    */   
/*    */   public boolean equals(Object obj) {
/* 40 */     if (obj instanceof SecurityContextImpl) {
/* 41 */       SecurityContextImpl test = (SecurityContextImpl)obj;
/*    */       
/* 43 */       if (getAuthentication() == null && test.getAuthentication() == null) {
/* 44 */         return true;
/*    */       }
/*    */       
/* 47 */       if (getAuthentication() != null && test.getAuthentication() != null && getAuthentication().equals(test.getAuthentication()))
/*    */       {
/* 49 */         return true;
/*    */       }
/*    */     } 
/*    */     
/* 53 */     return false;
/*    */   }
/*    */   
/*    */   public Authentication getAuthentication() {
/* 57 */     return this.authentication;
/*    */   }
/*    */   
/*    */   public int hashCode() {
/* 61 */     if (this.authentication == null) {
/* 62 */       return -1;
/*    */     }
/* 64 */     return this.authentication.hashCode();
/*    */   }
/*    */ 
/*    */   
/*    */   public void setAuthentication(Authentication authentication) {
/* 69 */     this.authentication = authentication;
/*    */   }
/*    */   
/*    */   public String toString() {
/* 73 */     StringBuilder sb = new StringBuilder();
/* 74 */     sb.append(super.toString());
/*    */     
/* 76 */     if (this.authentication == null) {
/* 77 */       sb.append(": Null authentication");
/*    */     } else {
/* 79 */       sb.append(": Authentication: ").append(this.authentication);
/*    */     } 
/*    */     
/* 82 */     return sb.toString();
/*    */   }
/*    */ }


/* Location:              C:\Users\Gcorp\Downloads\spring-security-core-3.2.0.RELEASE.jar!\org\springframework\security\core\context\SecurityContextImpl.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */