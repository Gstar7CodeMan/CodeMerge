/*     */ package org.springframework.security.core.context;
/*     */ 
/*     */ import java.lang.reflect.Constructor;
/*     */ import org.springframework.util.ReflectionUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SecurityContextHolder
/*     */ {
/*     */   public static final String MODE_THREADLOCAL = "MODE_THREADLOCAL";
/*     */   public static final String MODE_INHERITABLETHREADLOCAL = "MODE_INHERITABLETHREADLOCAL";
/*     */   public static final String MODE_GLOBAL = "MODE_GLOBAL";
/*     */   public static final String SYSTEM_PROPERTY = "spring.security.strategy";
/*  53 */   private static String strategyName = System.getProperty("spring.security.strategy");
/*     */   private static SecurityContextHolderStrategy strategy;
/*  55 */   private static int initializeCount = 0;
/*     */   
/*     */   static {
/*  58 */     initialize();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void clearContext() {
/*  67 */     strategy.clearContext();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static SecurityContext getContext() {
/*  76 */     return strategy.getContext();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int getInitializeCount() {
/*  87 */     return initializeCount;
/*     */   }
/*     */   
/*     */   private static void initialize() {
/*  91 */     if (strategyName == null || "".equals(strategyName))
/*     */     {
/*  93 */       strategyName = "MODE_THREADLOCAL";
/*     */     }
/*     */     
/*  96 */     if (strategyName.equals("MODE_THREADLOCAL")) {
/*  97 */       strategy = new ThreadLocalSecurityContextHolderStrategy();
/*  98 */     } else if (strategyName.equals("MODE_INHERITABLETHREADLOCAL")) {
/*  99 */       strategy = new InheritableThreadLocalSecurityContextHolderStrategy();
/* 100 */     } else if (strategyName.equals("MODE_GLOBAL")) {
/* 101 */       strategy = new GlobalSecurityContextHolderStrategy();
/*     */     } else {
/*     */       
/*     */       try {
/* 105 */         Class<?> clazz = Class.forName(strategyName);
/* 106 */         Constructor<?> customStrategy = clazz.getConstructor(new Class[0]);
/* 107 */         strategy = (SecurityContextHolderStrategy)customStrategy.newInstance(new Object[0]);
/* 108 */       } catch (Exception ex) {
/* 109 */         ReflectionUtils.handleReflectionException(ex);
/*     */       } 
/*     */     } 
/*     */     
/* 113 */     initializeCount++;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void setContext(SecurityContext context) {
/* 122 */     strategy.setContext(context);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void setStrategyName(String strategyName) {
/* 132 */     SecurityContextHolder.strategyName = strategyName;
/* 133 */     initialize();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static SecurityContextHolderStrategy getContextHolderStrategy() {
/* 142 */     return strategy;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static SecurityContext createEmptyContext() {
/* 149 */     return strategy.createEmptyContext();
/*     */   }
/*     */   
/*     */   public String toString() {
/* 153 */     return "SecurityContextHolder[strategy='" + strategyName + "'; initializeCount=" + initializeCount + "]";
/*     */   }
/*     */ }


/* Location:              C:\Users\Gcorp\Downloads\spring-security-core-3.2.0.RELEASE.jar!\org\springframework\security\core\context\SecurityContextHolder.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */