/*    */ package org.springframework.security.core.context;
/*    */ 
/*    */ import org.springframework.util.Assert;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class GlobalSecurityContextHolderStrategy
/*    */   implements SecurityContextHolderStrategy
/*    */ {
/*    */   private static SecurityContext contextHolder;
/*    */   
/*    */   public void clearContext() {
/* 37 */     contextHolder = null;
/*    */   }
/*    */   
/*    */   public SecurityContext getContext() {
/* 41 */     if (contextHolder == null) {
/* 42 */       contextHolder = new SecurityContextImpl();
/*    */     }
/*    */     
/* 45 */     return contextHolder;
/*    */   }
/*    */   
/*    */   public void setContext(SecurityContext context) {
/* 49 */     Assert.notNull(context, "Only non-null SecurityContext instances are permitted");
/* 50 */     contextHolder = context;
/*    */   }
/*    */   
/*    */   public SecurityContext createEmptyContext() {
/* 54 */     return new SecurityContextImpl();
/*    */   }
/*    */ }


/* Location:              C:\Users\Gcorp\Downloads\spring-security-core-3.2.0.RELEASE.jar!\org\springframework\security\core\context\GlobalSecurityContextHolderStrategy.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */