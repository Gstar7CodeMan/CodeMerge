/*    */ package org.springframework.security.core.context;
/*    */ 
/*    */ import org.springframework.util.Assert;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class InheritableThreadLocalSecurityContextHolderStrategy
/*    */   implements SecurityContextHolderStrategy
/*    */ {
/* 32 */   private static final ThreadLocal<SecurityContext> contextHolder = new InheritableThreadLocal<SecurityContext>();
/*    */ 
/*    */ 
/*    */   
/*    */   public void clearContext() {
/* 37 */     contextHolder.remove();
/*    */   }
/*    */   
/*    */   public SecurityContext getContext() {
/* 41 */     SecurityContext ctx = contextHolder.get();
/*    */     
/* 43 */     if (ctx == null) {
/* 44 */       ctx = createEmptyContext();
/* 45 */       contextHolder.set(ctx);
/*    */     } 
/*    */     
/* 48 */     return ctx;
/*    */   }
/*    */   
/*    */   public void setContext(SecurityContext context) {
/* 52 */     Assert.notNull(context, "Only non-null SecurityContext instances are permitted");
/* 53 */     contextHolder.set(context);
/*    */   }
/*    */   
/*    */   public SecurityContext createEmptyContext() {
/* 57 */     return new SecurityContextImpl();
/*    */   }
/*    */ }


/* Location:              C:\Users\Gcorp\Downloads\spring-security-core-3.2.0.RELEASE.jar!\org\springframework\security\core\context\InheritableThreadLocalSecurityContextHolderStrategy.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */