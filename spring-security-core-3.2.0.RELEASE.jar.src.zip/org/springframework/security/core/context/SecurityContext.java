package org.springframework.security.core.context;

import java.io.Serializable;
import org.springframework.security.core.Authentication;

public interface SecurityContext extends Serializable {
  Authentication getAuthentication();
  
  void setAuthentication(Authentication paramAuthentication);
}


/* Location:              C:\Users\Gcorp\Downloads\spring-security-core-3.2.0.RELEASE.jar!\org\springframework\security\core\context\SecurityContext.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */