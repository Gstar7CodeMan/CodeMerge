package org.springframework.security.core;

import java.io.Serializable;
import java.security.Principal;
import java.util.Collection;

public interface Authentication extends Principal, Serializable {
  Collection<? extends GrantedAuthority> getAuthorities();
  
  Object getCredentials();
  
  Object getDetails();
  
  Object getPrincipal();
  
  boolean isAuthenticated();
  
  void setAuthenticated(boolean paramBoolean) throws IllegalArgumentException;
}


/* Location:              C:\Users\Gcorp\Downloads\spring-security-core-3.2.0.RELEASE.jar!\org\springframework\security\core\Authentication.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */