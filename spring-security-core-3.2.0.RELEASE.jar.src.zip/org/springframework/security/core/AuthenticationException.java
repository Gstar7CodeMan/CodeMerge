/*    */ package org.springframework.security.core;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class AuthenticationException
/*    */   extends RuntimeException
/*    */ {
/*    */   private Authentication authentication;
/*    */   private transient Object extraInformation;
/*    */   
/*    */   public AuthenticationException(String msg, Throwable t) {
/* 39 */     super(msg, t);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public AuthenticationException(String msg) {
/* 48 */     super(msg);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   @Deprecated
/*    */   public AuthenticationException(String msg, Object extraInformation) {
/* 56 */     super(msg);
/* 57 */     if (extraInformation instanceof CredentialsContainer) {
/* 58 */       ((CredentialsContainer)extraInformation).eraseCredentials();
/*    */     }
/* 60 */     this.extraInformation = extraInformation;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   @Deprecated
/*    */   public Authentication getAuthentication() {
/* 71 */     return this.authentication;
/*    */   }
/*    */   
/*    */   @Deprecated
/*    */   public void setAuthentication(Authentication authentication) {
/* 76 */     this.authentication = authentication;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   @Deprecated
/*    */   public Object getExtraInformation() {
/* 87 */     return this.extraInformation;
/*    */   }
/*    */   
/*    */   @Deprecated
/*    */   public void clearExtraInformation() {
/* 92 */     this.extraInformation = null;
/*    */   }
/*    */ }


/* Location:              C:\Users\Gcorp\Downloads\spring-security-core-3.2.0.RELEASE.jar!\org\springframework\security\core\AuthenticationException.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */