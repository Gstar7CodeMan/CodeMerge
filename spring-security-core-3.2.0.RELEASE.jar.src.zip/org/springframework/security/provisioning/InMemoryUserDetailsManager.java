/*     */ package org.springframework.security.provisioning;
/*     */ 
/*     */ import java.util.Collection;
/*     */ import java.util.Enumeration;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import java.util.Properties;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.security.access.AccessDeniedException;
/*     */ import org.springframework.security.authentication.AuthenticationManager;
/*     */ import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
/*     */ import org.springframework.security.core.Authentication;
/*     */ import org.springframework.security.core.context.SecurityContextHolder;
/*     */ import org.springframework.security.core.userdetails.User;
/*     */ import org.springframework.security.core.userdetails.UserDetails;
/*     */ import org.springframework.security.core.userdetails.UsernameNotFoundException;
/*     */ import org.springframework.security.core.userdetails.memory.UserAttribute;
/*     */ import org.springframework.security.core.userdetails.memory.UserAttributeEditor;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class InMemoryUserDetailsManager
/*     */   implements UserDetailsManager
/*     */ {
/*  32 */   protected final Log logger = LogFactory.getLog(getClass());
/*     */   
/*  34 */   private final Map<String, MutableUserDetails> users = new HashMap<String, MutableUserDetails>();
/*     */   
/*     */   private AuthenticationManager authenticationManager;
/*     */   
/*     */   public InMemoryUserDetailsManager(Collection<UserDetails> users) {
/*  39 */     for (UserDetails user : users) {
/*  40 */       createUser(user);
/*     */     }
/*     */   }
/*     */   
/*     */   public InMemoryUserDetailsManager(Properties users) {
/*  45 */     Enumeration<?> names = users.propertyNames();
/*  46 */     UserAttributeEditor editor = new UserAttributeEditor();
/*     */     
/*  48 */     while (names.hasMoreElements()) {
/*  49 */       String name = (String)names.nextElement();
/*  50 */       editor.setAsText(users.getProperty(name));
/*  51 */       UserAttribute attr = (UserAttribute)editor.getValue();
/*  52 */       User user = new User(name, attr.getPassword(), attr.isEnabled(), true, true, true, attr.getAuthorities());
/*     */       
/*  54 */       createUser((UserDetails)user);
/*     */     } 
/*     */   }
/*     */   
/*     */   public void createUser(UserDetails user) {
/*  59 */     Assert.isTrue(!userExists(user.getUsername()));
/*     */     
/*  61 */     this.users.put(user.getUsername().toLowerCase(), new MutableUser(user));
/*     */   }
/*     */   
/*     */   public void deleteUser(String username) {
/*  65 */     this.users.remove(username.toLowerCase());
/*     */   }
/*     */   
/*     */   public void updateUser(UserDetails user) {
/*  69 */     Assert.isTrue(userExists(user.getUsername()));
/*     */     
/*  71 */     this.users.put(user.getUsername().toLowerCase(), new MutableUser(user));
/*     */   }
/*     */   
/*     */   public boolean userExists(String username) {
/*  75 */     return this.users.containsKey(username.toLowerCase());
/*     */   }
/*     */   
/*     */   public void changePassword(String oldPassword, String newPassword) {
/*  79 */     Authentication currentUser = SecurityContextHolder.getContext().getAuthentication();
/*     */     
/*  81 */     if (currentUser == null)
/*     */     {
/*  83 */       throw new AccessDeniedException("Can't change password as no Authentication object found in context for current user.");
/*     */     }
/*     */ 
/*     */     
/*  87 */     String username = currentUser.getName();
/*     */     
/*  89 */     this.logger.debug("Changing password for user '" + username + "'");
/*     */ 
/*     */     
/*  92 */     if (this.authenticationManager != null) {
/*  93 */       this.logger.debug("Reauthenticating user '" + username + "' for password change request.");
/*     */       
/*  95 */       this.authenticationManager.authenticate((Authentication)new UsernamePasswordAuthenticationToken(username, oldPassword));
/*     */     } else {
/*  97 */       this.logger.debug("No authentication manager set. Password won't be re-checked.");
/*     */     } 
/*     */     
/* 100 */     MutableUserDetails user = this.users.get(username);
/*     */     
/* 102 */     if (user == null) {
/* 103 */       throw new IllegalStateException("Current user doesn't exist in database.");
/*     */     }
/*     */     
/* 106 */     user.setPassword(newPassword);
/*     */   }
/*     */   
/*     */   public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
/* 110 */     UserDetails user = this.users.get(username.toLowerCase());
/*     */     
/* 112 */     if (user == null) {
/* 113 */       throw new UsernameNotFoundException(username);
/*     */     }
/*     */     
/* 116 */     return (UserDetails)new User(user.getUsername(), user.getPassword(), user.isEnabled(), user.isAccountNonExpired(), user.isCredentialsNonExpired(), user.isAccountNonLocked(), user.getAuthorities());
/*     */   }
/*     */ 
/*     */   
/*     */   public void setAuthenticationManager(AuthenticationManager authenticationManager) {
/* 121 */     this.authenticationManager = authenticationManager;
/*     */   }
/*     */ }


/* Location:              C:\Users\Gcorp\Downloads\spring-security-core-3.2.0.RELEASE.jar!\org\springframework\security\provisioning\InMemoryUserDetailsManager.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */