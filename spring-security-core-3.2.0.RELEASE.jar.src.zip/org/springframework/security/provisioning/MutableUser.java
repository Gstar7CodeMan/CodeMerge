/*    */ package org.springframework.security.provisioning;
/*    */ 
/*    */ import java.util.Collection;
/*    */ import org.springframework.security.core.GrantedAuthority;
/*    */ import org.springframework.security.core.userdetails.UserDetails;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class MutableUser
/*    */   implements MutableUserDetails
/*    */ {
/*    */   private static final long serialVersionUID = 320L;
/*    */   private String password;
/*    */   private final UserDetails delegate;
/*    */   
/*    */   public MutableUser(UserDetails user) {
/* 22 */     this.delegate = user;
/* 23 */     this.password = user.getPassword();
/*    */   }
/*    */   
/*    */   public String getPassword() {
/* 27 */     return this.password;
/*    */   }
/*    */   
/*    */   public void setPassword(String password) {
/* 31 */     this.password = password;
/*    */   }
/*    */   
/*    */   public Collection<? extends GrantedAuthority> getAuthorities() {
/* 35 */     return this.delegate.getAuthorities();
/*    */   }
/*    */   
/*    */   public String getUsername() {
/* 39 */     return this.delegate.getUsername();
/*    */   }
/*    */   
/*    */   public boolean isAccountNonExpired() {
/* 43 */     return this.delegate.isAccountNonExpired();
/*    */   }
/*    */   
/*    */   public boolean isAccountNonLocked() {
/* 47 */     return this.delegate.isAccountNonLocked();
/*    */   }
/*    */   
/*    */   public boolean isCredentialsNonExpired() {
/* 51 */     return this.delegate.isCredentialsNonExpired();
/*    */   }
/*    */   
/*    */   public boolean isEnabled() {
/* 55 */     return this.delegate.isEnabled();
/*    */   }
/*    */ }


/* Location:              C:\Users\Gcorp\Downloads\spring-security-core-3.2.0.RELEASE.jar!\org\springframework\security\provisioning\MutableUser.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */