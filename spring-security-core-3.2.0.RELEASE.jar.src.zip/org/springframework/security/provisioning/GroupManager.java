package org.springframework.security.provisioning;

import java.util.List;
import org.springframework.security.core.GrantedAuthority;

public interface GroupManager {
  List<String> findAllGroups();
  
  List<String> findUsersInGroup(String paramString);
  
  void createGroup(String paramString, List<GrantedAuthority> paramList);
  
  void deleteGroup(String paramString);
  
  void renameGroup(String paramString1, String paramString2);
  
  void addUserToGroup(String paramString1, String paramString2);
  
  void removeUserFromGroup(String paramString1, String paramString2);
  
  List<GrantedAuthority> findGroupAuthorities(String paramString);
  
  void addGroupAuthority(String paramString, GrantedAuthority paramGrantedAuthority);
  
  void removeGroupAuthority(String paramString, GrantedAuthority paramGrantedAuthority);
}


/* Location:              C:\Users\Gcorp\Downloads\spring-security-core-3.2.0.RELEASE.jar!\org\springframework\security\provisioning\GroupManager.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */