/*     */ package org.springframework.security.provisioning;
/*     */ 
/*     */ import java.sql.PreparedStatement;
/*     */ import java.sql.ResultSet;
/*     */ import java.sql.SQLException;
/*     */ import java.util.Collection;
/*     */ import java.util.List;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.context.ApplicationContextException;
/*     */ import org.springframework.dao.IncorrectResultSizeDataAccessException;
/*     */ import org.springframework.jdbc.core.PreparedStatementSetter;
/*     */ import org.springframework.jdbc.core.RowMapper;
/*     */ import org.springframework.security.access.AccessDeniedException;
/*     */ import org.springframework.security.authentication.AuthenticationManager;
/*     */ import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
/*     */ import org.springframework.security.core.Authentication;
/*     */ import org.springframework.security.core.AuthenticationException;
/*     */ import org.springframework.security.core.GrantedAuthority;
/*     */ import org.springframework.security.core.authority.AuthorityUtils;
/*     */ import org.springframework.security.core.authority.SimpleGrantedAuthority;
/*     */ import org.springframework.security.core.context.SecurityContextHolder;
/*     */ import org.springframework.security.core.userdetails.UserCache;
/*     */ import org.springframework.security.core.userdetails.UserDetails;
/*     */ import org.springframework.security.core.userdetails.cache.NullUserCache;
/*     */ import org.springframework.security.core.userdetails.jdbc.JdbcDaoImpl;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class JdbcUserDetailsManager
/*     */   extends JdbcDaoImpl
/*     */   implements UserDetailsManager, GroupManager
/*     */ {
/*     */   public static final String DEF_CREATE_USER_SQL = "insert into users (username, password, enabled) values (?,?,?)";
/*     */   public static final String DEF_DELETE_USER_SQL = "delete from users where username = ?";
/*     */   public static final String DEF_UPDATE_USER_SQL = "update users set password = ?, enabled = ? where username = ?";
/*     */   public static final String DEF_INSERT_AUTHORITY_SQL = "insert into authorities (username, authority) values (?,?)";
/*     */   public static final String DEF_DELETE_USER_AUTHORITIES_SQL = "delete from authorities where username = ?";
/*     */   public static final String DEF_USER_EXISTS_SQL = "select username from users where username = ?";
/*     */   public static final String DEF_CHANGE_PASSWORD_SQL = "update users set password = ? where username = ?";
/*     */   public static final String DEF_FIND_GROUPS_SQL = "select group_name from groups";
/*     */   public static final String DEF_FIND_USERS_IN_GROUP_SQL = "select username from group_members gm, groups g where gm.group_id = g.id and g.group_name = ?";
/*     */   public static final String DEF_INSERT_GROUP_SQL = "insert into groups (group_name) values (?)";
/*     */   public static final String DEF_FIND_GROUP_ID_SQL = "select id from groups where group_name = ?";
/*     */   public static final String DEF_INSERT_GROUP_AUTHORITY_SQL = "insert into group_authorities (group_id, authority) values (?,?)";
/*     */   public static final String DEF_DELETE_GROUP_SQL = "delete from groups where id = ?";
/*     */   public static final String DEF_DELETE_GROUP_AUTHORITIES_SQL = "delete from group_authorities where group_id = ?";
/*     */   public static final String DEF_DELETE_GROUP_MEMBERS_SQL = "delete from group_members where group_id = ?";
/*     */   public static final String DEF_RENAME_GROUP_SQL = "update groups set group_name = ? where group_name = ?";
/*     */   public static final String DEF_INSERT_GROUP_MEMBER_SQL = "insert into group_members (group_id, username) values (?,?)";
/*     */   public static final String DEF_DELETE_GROUP_MEMBER_SQL = "delete from group_members where group_id = ? and username = ?";
/*     */   public static final String DEF_GROUP_AUTHORITIES_QUERY_SQL = "select g.id, g.group_name, ga.authority from groups g, group_authorities ga where g.group_name = ? and g.id = ga.group_id ";
/*     */   public static final String DEF_DELETE_GROUP_AUTHORITY_SQL = "delete from group_authorities where group_id = ? and authority = ?";
/*  98 */   protected final Log logger = LogFactory.getLog(getClass());
/*     */   
/* 100 */   private String createUserSql = "insert into users (username, password, enabled) values (?,?,?)";
/* 101 */   private String deleteUserSql = "delete from users where username = ?";
/* 102 */   private String updateUserSql = "update users set password = ?, enabled = ? where username = ?";
/* 103 */   private String createAuthoritySql = "insert into authorities (username, authority) values (?,?)";
/* 104 */   private String deleteUserAuthoritiesSql = "delete from authorities where username = ?";
/* 105 */   private String userExistsSql = "select username from users where username = ?";
/* 106 */   private String changePasswordSql = "update users set password = ? where username = ?";
/*     */   
/* 108 */   private String findAllGroupsSql = "select group_name from groups";
/* 109 */   private String findUsersInGroupSql = "select username from group_members gm, groups g where gm.group_id = g.id and g.group_name = ?";
/* 110 */   private String insertGroupSql = "insert into groups (group_name) values (?)";
/* 111 */   private String findGroupIdSql = "select id from groups where group_name = ?";
/* 112 */   private String insertGroupAuthoritySql = "insert into group_authorities (group_id, authority) values (?,?)";
/* 113 */   private String deleteGroupSql = "delete from groups where id = ?";
/* 114 */   private String deleteGroupAuthoritiesSql = "delete from group_authorities where group_id = ?";
/* 115 */   private String deleteGroupMembersSql = "delete from group_members where group_id = ?";
/* 116 */   private String renameGroupSql = "update groups set group_name = ? where group_name = ?";
/* 117 */   private String insertGroupMemberSql = "insert into group_members (group_id, username) values (?,?)";
/* 118 */   private String deleteGroupMemberSql = "delete from group_members where group_id = ? and username = ?";
/* 119 */   private String groupAuthoritiesSql = "select g.id, g.group_name, ga.authority from groups g, group_authorities ga where g.group_name = ? and g.id = ga.group_id ";
/* 120 */   private String deleteGroupAuthoritySql = "delete from group_authorities where group_id = ? and authority = ?";
/*     */   
/*     */   private AuthenticationManager authenticationManager;
/*     */   
/* 124 */   private UserCache userCache = (UserCache)new NullUserCache();
/*     */ 
/*     */ 
/*     */   
/*     */   protected void initDao() throws ApplicationContextException {
/* 129 */     if (this.authenticationManager == null) {
/* 130 */       this.logger.info("No authentication manager set. Reauthentication of users when changing passwords will not be performed.");
/*     */     }
/*     */ 
/*     */     
/* 134 */     super.initDao();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void createUser(final UserDetails user) {
/* 140 */     validateUserDetails(user);
/* 141 */     getJdbcTemplate().update(this.createUserSql, new PreparedStatementSetter() {
/*     */           public void setValues(PreparedStatement ps) throws SQLException {
/* 143 */             ps.setString(1, user.getUsername());
/* 144 */             ps.setString(2, user.getPassword());
/* 145 */             ps.setBoolean(3, user.isEnabled());
/*     */           }
/*     */         });
/*     */ 
/*     */     
/* 150 */     if (getEnableAuthorities()) {
/* 151 */       insertUserAuthorities(user);
/*     */     }
/*     */   }
/*     */   
/*     */   public void updateUser(final UserDetails user) {
/* 156 */     validateUserDetails(user);
/* 157 */     getJdbcTemplate().update(this.updateUserSql, new PreparedStatementSetter() {
/*     */           public void setValues(PreparedStatement ps) throws SQLException {
/* 159 */             ps.setString(1, user.getPassword());
/* 160 */             ps.setBoolean(2, user.isEnabled());
/* 161 */             ps.setString(3, user.getUsername());
/*     */           }
/*     */         });
/*     */     
/* 165 */     if (getEnableAuthorities()) {
/* 166 */       deleteUserAuthorities(user.getUsername());
/* 167 */       insertUserAuthorities(user);
/*     */     } 
/*     */     
/* 170 */     this.userCache.removeUserFromCache(user.getUsername());
/*     */   }
/*     */   
/*     */   private void insertUserAuthorities(UserDetails user) {
/* 174 */     for (GrantedAuthority auth : user.getAuthorities()) {
/* 175 */       getJdbcTemplate().update(this.createAuthoritySql, new Object[] { user.getUsername(), auth.getAuthority() });
/*     */     } 
/*     */   }
/*     */   
/*     */   public void deleteUser(String username) {
/* 180 */     if (getEnableAuthorities()) {
/* 181 */       deleteUserAuthorities(username);
/*     */     }
/* 183 */     getJdbcTemplate().update(this.deleteUserSql, new Object[] { username });
/* 184 */     this.userCache.removeUserFromCache(username);
/*     */   }
/*     */   
/*     */   private void deleteUserAuthorities(String username) {
/* 188 */     getJdbcTemplate().update(this.deleteUserAuthoritiesSql, new Object[] { username });
/*     */   }
/*     */   
/*     */   public void changePassword(String oldPassword, String newPassword) throws AuthenticationException {
/* 192 */     Authentication currentUser = SecurityContextHolder.getContext().getAuthentication();
/*     */     
/* 194 */     if (currentUser == null)
/*     */     {
/* 196 */       throw new AccessDeniedException("Can't change password as no Authentication object found in context for current user.");
/*     */     }
/*     */ 
/*     */     
/* 200 */     String username = currentUser.getName();
/*     */ 
/*     */     
/* 203 */     if (this.authenticationManager != null) {
/* 204 */       this.logger.debug("Reauthenticating user '" + username + "' for password change request.");
/*     */       
/* 206 */       this.authenticationManager.authenticate((Authentication)new UsernamePasswordAuthenticationToken(username, oldPassword));
/*     */     } else {
/* 208 */       this.logger.debug("No authentication manager set. Password won't be re-checked.");
/*     */     } 
/*     */     
/* 211 */     this.logger.debug("Changing password for user '" + username + "'");
/*     */     
/* 213 */     getJdbcTemplate().update(this.changePasswordSql, new Object[] { newPassword, username });
/*     */     
/* 215 */     SecurityContextHolder.getContext().setAuthentication(createNewAuthentication(currentUser, newPassword));
/*     */     
/* 217 */     this.userCache.removeUserFromCache(username);
/*     */   }
/*     */   
/*     */   protected Authentication createNewAuthentication(Authentication currentAuth, String newPassword) {
/* 221 */     UserDetails user = loadUserByUsername(currentAuth.getName());
/*     */     
/* 223 */     UsernamePasswordAuthenticationToken newAuthentication = new UsernamePasswordAuthenticationToken(user, user.getPassword(), user.getAuthorities());
/*     */     
/* 225 */     newAuthentication.setDetails(currentAuth.getDetails());
/*     */     
/* 227 */     return (Authentication)newAuthentication;
/*     */   }
/*     */   
/*     */   public boolean userExists(String username) {
/* 231 */     List<String> users = getJdbcTemplate().queryForList(this.userExistsSql, (Object[])new String[] { username }, String.class);
/*     */     
/* 233 */     if (users.size() > 1) {
/* 234 */       throw new IncorrectResultSizeDataAccessException("More than one user found with name '" + username + "'", 1);
/*     */     }
/*     */     
/* 237 */     return (users.size() == 1);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public List<String> findAllGroups() {
/* 243 */     return getJdbcTemplate().queryForList(this.findAllGroupsSql, String.class);
/*     */   }
/*     */   
/*     */   public List<String> findUsersInGroup(String groupName) {
/* 247 */     Assert.hasText(groupName);
/* 248 */     return getJdbcTemplate().queryForList(this.findUsersInGroupSql, (Object[])new String[] { groupName }, String.class);
/*     */   }
/*     */   
/*     */   public void createGroup(String groupName, List<GrantedAuthority> authorities) {
/* 252 */     Assert.hasText(groupName);
/* 253 */     Assert.notNull(authorities);
/*     */     
/* 255 */     this.logger.debug("Creating new group '" + groupName + "' with authorities " + AuthorityUtils.authorityListToSet(authorities));
/*     */ 
/*     */     
/* 258 */     getJdbcTemplate().update(this.insertGroupSql, new Object[] { groupName });
/*     */     
/* 260 */     final int groupId = findGroupId(groupName);
/*     */     
/* 262 */     for (GrantedAuthority a : authorities) {
/* 263 */       final String authority = a.getAuthority();
/* 264 */       getJdbcTemplate().update(this.insertGroupAuthoritySql, new PreparedStatementSetter() {
/*     */             public void setValues(PreparedStatement ps) throws SQLException {
/* 266 */               ps.setInt(1, groupId);
/* 267 */               ps.setString(2, authority);
/*     */             }
/*     */           });
/*     */     } 
/*     */   }
/*     */   
/*     */   public void deleteGroup(String groupName) {
/* 274 */     this.logger.debug("Deleting group '" + groupName + "'");
/* 275 */     Assert.hasText(groupName);
/*     */     
/* 277 */     final int id = findGroupId(groupName);
/* 278 */     PreparedStatementSetter groupIdPSS = new PreparedStatementSetter() {
/*     */         public void setValues(PreparedStatement ps) throws SQLException {
/* 280 */           ps.setInt(1, id);
/*     */         }
/*     */       };
/* 283 */     getJdbcTemplate().update(this.deleteGroupMembersSql, groupIdPSS);
/* 284 */     getJdbcTemplate().update(this.deleteGroupAuthoritiesSql, groupIdPSS);
/* 285 */     getJdbcTemplate().update(this.deleteGroupSql, groupIdPSS);
/*     */   }
/*     */   
/*     */   public void renameGroup(String oldName, String newName) {
/* 289 */     this.logger.debug("Changing group name from '" + oldName + "' to '" + newName + "'");
/* 290 */     Assert.hasText(oldName);
/* 291 */     Assert.hasText(newName);
/*     */     
/* 293 */     getJdbcTemplate().update(this.renameGroupSql, new Object[] { newName, oldName });
/*     */   }
/*     */   
/*     */   public void addUserToGroup(final String username, String groupName) {
/* 297 */     this.logger.debug("Adding user '" + username + "' to group '" + groupName + "'");
/* 298 */     Assert.hasText(username);
/* 299 */     Assert.hasText(groupName);
/*     */     
/* 301 */     final int id = findGroupId(groupName);
/* 302 */     getJdbcTemplate().update(this.insertGroupMemberSql, new PreparedStatementSetter() {
/*     */           public void setValues(PreparedStatement ps) throws SQLException {
/* 304 */             ps.setInt(1, id);
/* 305 */             ps.setString(2, username);
/*     */           }
/*     */         });
/*     */     
/* 309 */     this.userCache.removeUserFromCache(username);
/*     */   }
/*     */   
/*     */   public void removeUserFromGroup(final String username, String groupName) {
/* 313 */     this.logger.debug("Removing user '" + username + "' to group '" + groupName + "'");
/* 314 */     Assert.hasText(username);
/* 315 */     Assert.hasText(groupName);
/*     */     
/* 317 */     final int id = findGroupId(groupName);
/*     */     
/* 319 */     getJdbcTemplate().update(this.deleteGroupMemberSql, new PreparedStatementSetter() {
/*     */           public void setValues(PreparedStatement ps) throws SQLException {
/* 321 */             ps.setInt(1, id);
/* 322 */             ps.setString(2, username);
/*     */           }
/*     */         });
/*     */     
/* 326 */     this.userCache.removeUserFromCache(username);
/*     */   }
/*     */   
/*     */   public List<GrantedAuthority> findGroupAuthorities(String groupName) {
/* 330 */     this.logger.debug("Loading authorities for group '" + groupName + "'");
/* 331 */     Assert.hasText(groupName);
/*     */     
/* 333 */     return getJdbcTemplate().query(this.groupAuthoritiesSql, (Object[])new String[] { groupName }, new RowMapper<GrantedAuthority>() {
/*     */           public GrantedAuthority mapRow(ResultSet rs, int rowNum) throws SQLException {
/* 335 */             String roleName = JdbcUserDetailsManager.this.getRolePrefix() + rs.getString(3);
/*     */             
/* 337 */             return (GrantedAuthority)new SimpleGrantedAuthority(roleName);
/*     */           }
/*     */         });
/*     */   }
/*     */   
/*     */   public void removeGroupAuthority(String groupName, final GrantedAuthority authority) {
/* 343 */     this.logger.debug("Removing authority '" + authority + "' from group '" + groupName + "'");
/* 344 */     Assert.hasText(groupName);
/* 345 */     Assert.notNull(authority);
/*     */     
/* 347 */     final int id = findGroupId(groupName);
/*     */     
/* 349 */     getJdbcTemplate().update(this.deleteGroupAuthoritySql, new PreparedStatementSetter()
/*     */         {
/*     */           public void setValues(PreparedStatement ps) throws SQLException {
/* 352 */             ps.setInt(1, id);
/* 353 */             ps.setString(2, authority.getAuthority());
/*     */           }
/*     */         });
/*     */   }
/*     */   
/*     */   public void addGroupAuthority(String groupName, final GrantedAuthority authority) {
/* 359 */     this.logger.debug("Adding authority '" + authority + "' to group '" + groupName + "'");
/* 360 */     Assert.hasText(groupName);
/* 361 */     Assert.notNull(authority);
/*     */     
/* 363 */     final int id = findGroupId(groupName);
/* 364 */     getJdbcTemplate().update(this.insertGroupAuthoritySql, new PreparedStatementSetter() {
/*     */           public void setValues(PreparedStatement ps) throws SQLException {
/* 366 */             ps.setInt(1, id);
/* 367 */             ps.setString(2, authority.getAuthority());
/*     */           }
/*     */         });
/*     */   }
/*     */   
/*     */   private int findGroupId(String group) {
/* 373 */     return getJdbcTemplate().queryForInt(this.findGroupIdSql, new Object[] { group });
/*     */   }
/*     */   
/*     */   public void setAuthenticationManager(AuthenticationManager authenticationManager) {
/* 377 */     this.authenticationManager = authenticationManager;
/*     */   }
/*     */   
/*     */   public void setCreateUserSql(String createUserSql) {
/* 381 */     Assert.hasText(createUserSql);
/* 382 */     this.createUserSql = createUserSql;
/*     */   }
/*     */   
/*     */   public void setDeleteUserSql(String deleteUserSql) {
/* 386 */     Assert.hasText(deleteUserSql);
/* 387 */     this.deleteUserSql = deleteUserSql;
/*     */   }
/*     */   
/*     */   public void setUpdateUserSql(String updateUserSql) {
/* 391 */     Assert.hasText(updateUserSql);
/* 392 */     this.updateUserSql = updateUserSql;
/*     */   }
/*     */   
/*     */   public void setCreateAuthoritySql(String createAuthoritySql) {
/* 396 */     Assert.hasText(createAuthoritySql);
/* 397 */     this.createAuthoritySql = createAuthoritySql;
/*     */   }
/*     */   
/*     */   public void setDeleteUserAuthoritiesSql(String deleteUserAuthoritiesSql) {
/* 401 */     Assert.hasText(deleteUserAuthoritiesSql);
/* 402 */     this.deleteUserAuthoritiesSql = deleteUserAuthoritiesSql;
/*     */   }
/*     */   
/*     */   public void setUserExistsSql(String userExistsSql) {
/* 406 */     Assert.hasText(userExistsSql);
/* 407 */     this.userExistsSql = userExistsSql;
/*     */   }
/*     */   
/*     */   public void setChangePasswordSql(String changePasswordSql) {
/* 411 */     Assert.hasText(changePasswordSql);
/* 412 */     this.changePasswordSql = changePasswordSql;
/*     */   }
/*     */   
/*     */   public void setFindAllGroupsSql(String findAllGroupsSql) {
/* 416 */     Assert.hasText(findAllGroupsSql);
/* 417 */     this.findAllGroupsSql = findAllGroupsSql;
/*     */   }
/*     */   
/*     */   public void setFindUsersInGroupSql(String findUsersInGroupSql) {
/* 421 */     Assert.hasText(findUsersInGroupSql);
/* 422 */     this.findUsersInGroupSql = findUsersInGroupSql;
/*     */   }
/*     */   
/*     */   public void setInsertGroupSql(String insertGroupSql) {
/* 426 */     Assert.hasText(insertGroupSql);
/* 427 */     this.insertGroupSql = insertGroupSql;
/*     */   }
/*     */   
/*     */   public void setFindGroupIdSql(String findGroupIdSql) {
/* 431 */     Assert.hasText(findGroupIdSql);
/* 432 */     this.findGroupIdSql = findGroupIdSql;
/*     */   }
/*     */   
/*     */   public void setInsertGroupAuthoritySql(String insertGroupAuthoritySql) {
/* 436 */     Assert.hasText(insertGroupAuthoritySql);
/* 437 */     this.insertGroupAuthoritySql = insertGroupAuthoritySql;
/*     */   }
/*     */   
/*     */   public void setDeleteGroupSql(String deleteGroupSql) {
/* 441 */     Assert.hasText(deleteGroupSql);
/* 442 */     this.deleteGroupSql = deleteGroupSql;
/*     */   }
/*     */   
/*     */   public void setDeleteGroupAuthoritiesSql(String deleteGroupAuthoritiesSql) {
/* 446 */     Assert.hasText(deleteGroupAuthoritiesSql);
/* 447 */     this.deleteGroupAuthoritiesSql = deleteGroupAuthoritiesSql;
/*     */   }
/*     */   
/*     */   public void setDeleteGroupMembersSql(String deleteGroupMembersSql) {
/* 451 */     Assert.hasText(deleteGroupMembersSql);
/* 452 */     this.deleteGroupMembersSql = deleteGroupMembersSql;
/*     */   }
/*     */   
/*     */   public void setRenameGroupSql(String renameGroupSql) {
/* 456 */     Assert.hasText(renameGroupSql);
/* 457 */     this.renameGroupSql = renameGroupSql;
/*     */   }
/*     */   
/*     */   public void setInsertGroupMemberSql(String insertGroupMemberSql) {
/* 461 */     Assert.hasText(insertGroupMemberSql);
/* 462 */     this.insertGroupMemberSql = insertGroupMemberSql;
/*     */   }
/*     */   
/*     */   public void setDeleteGroupMemberSql(String deleteGroupMemberSql) {
/* 466 */     Assert.hasText(deleteGroupMemberSql);
/* 467 */     this.deleteGroupMemberSql = deleteGroupMemberSql;
/*     */   }
/*     */   
/*     */   public void setGroupAuthoritiesSql(String groupAuthoritiesSql) {
/* 471 */     Assert.hasText(groupAuthoritiesSql);
/* 472 */     this.groupAuthoritiesSql = groupAuthoritiesSql;
/*     */   }
/*     */   
/*     */   public void setDeleteGroupAuthoritySql(String deleteGroupAuthoritySql) {
/* 476 */     Assert.hasText(deleteGroupAuthoritySql);
/* 477 */     this.deleteGroupAuthoritySql = deleteGroupAuthoritySql;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setUserCache(UserCache userCache) {
/* 487 */     Assert.notNull(userCache, "userCache cannot be null");
/* 488 */     this.userCache = userCache;
/*     */   }
/*     */   
/*     */   private void validateUserDetails(UserDetails user) {
/* 492 */     Assert.hasText(user.getUsername(), "Username may not be empty or null");
/* 493 */     validateAuthorities(user.getAuthorities());
/*     */   }
/*     */   
/*     */   private void validateAuthorities(Collection<? extends GrantedAuthority> authorities) {
/* 497 */     Assert.notNull(authorities, "Authorities list must not be null");
/*     */     
/* 499 */     for (GrantedAuthority authority : authorities) {
/* 500 */       Assert.notNull(authority, "Authorities list contains a null entry");
/* 501 */       Assert.hasText(authority.getAuthority(), "getAuthority() method must return a non-empty string");
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\Gcorp\Downloads\spring-security-core-3.2.0.RELEASE.jar!\org\springframework\security\provisioning\JdbcUserDetailsManager.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */