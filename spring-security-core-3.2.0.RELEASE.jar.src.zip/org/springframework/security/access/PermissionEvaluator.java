package org.springframework.security.access;

import java.io.Serializable;
import org.springframework.aop.framework.AopInfrastructureBean;
import org.springframework.security.core.Authentication;

public interface PermissionEvaluator extends AopInfrastructureBean {
  boolean hasPermission(Authentication paramAuthentication, Object paramObject1, Object paramObject2);
  
  boolean hasPermission(Authentication paramAuthentication, Serializable paramSerializable, String paramString, Object paramObject);
}


/* Location:              C:\Users\Gcorp\Downloads\spring-security-core-3.2.0.RELEASE.jar!\org\springframework\security\access\PermissionEvaluator.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */