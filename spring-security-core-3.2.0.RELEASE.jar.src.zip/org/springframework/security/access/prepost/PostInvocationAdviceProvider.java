/*    */ package org.springframework.security.access.prepost;
/*    */ 
/*    */ import java.util.Collection;
/*    */ import org.aopalliance.intercept.MethodInvocation;
/*    */ import org.apache.commons.logging.Log;
/*    */ import org.apache.commons.logging.LogFactory;
/*    */ import org.springframework.security.access.AccessDeniedException;
/*    */ import org.springframework.security.access.AfterInvocationProvider;
/*    */ import org.springframework.security.access.ConfigAttribute;
/*    */ import org.springframework.security.core.Authentication;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class PostInvocationAdviceProvider
/*    */   implements AfterInvocationProvider
/*    */ {
/* 21 */   protected final Log logger = LogFactory.getLog(getClass());
/*    */   
/*    */   private final PostInvocationAuthorizationAdvice postAdvice;
/*    */   
/*    */   public PostInvocationAdviceProvider(PostInvocationAuthorizationAdvice postAdvice) {
/* 26 */     this.postAdvice = postAdvice;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public Object decide(Authentication authentication, Object object, Collection<ConfigAttribute> config, Object returnedObject) throws AccessDeniedException {
/* 32 */     PostInvocationAttribute pia = findPostInvocationAttribute(config);
/*    */     
/* 34 */     if (pia == null) {
/* 35 */       return returnedObject;
/*    */     }
/*    */     
/* 38 */     return this.postAdvice.after(authentication, (MethodInvocation)object, pia, returnedObject);
/*    */   }
/*    */   
/*    */   private PostInvocationAttribute findPostInvocationAttribute(Collection<ConfigAttribute> config) {
/* 42 */     for (ConfigAttribute attribute : config) {
/* 43 */       if (attribute instanceof PostInvocationAttribute) {
/* 44 */         return (PostInvocationAttribute)attribute;
/*    */       }
/*    */     } 
/*    */     
/* 48 */     return null;
/*    */   }
/*    */   
/*    */   public boolean supports(ConfigAttribute attribute) {
/* 52 */     return attribute instanceof PostInvocationAttribute;
/*    */   }
/*    */   
/*    */   public boolean supports(Class<?> clazz) {
/* 56 */     return clazz.isAssignableFrom(MethodInvocation.class);
/*    */   }
/*    */ }


/* Location:              C:\Users\Gcorp\Downloads\spring-security-core-3.2.0.RELEASE.jar!\org\springframework\security\access\prepost\PostInvocationAdviceProvider.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */