package org.springframework.security.access.prepost;

import org.aopalliance.intercept.MethodInvocation;
import org.springframework.aop.framework.AopInfrastructureBean;
import org.springframework.security.core.Authentication;

public interface PreInvocationAuthorizationAdvice extends AopInfrastructureBean {
  boolean before(Authentication paramAuthentication, MethodInvocation paramMethodInvocation, PreInvocationAttribute paramPreInvocationAttribute);
}


/* Location:              C:\Users\Gcorp\Downloads\spring-security-core-3.2.0.RELEASE.jar!\org\springframework\security\access\prepost\PreInvocationAuthorizationAdvice.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */