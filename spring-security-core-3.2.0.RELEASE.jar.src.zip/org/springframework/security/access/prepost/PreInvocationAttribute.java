package org.springframework.security.access.prepost;

import org.springframework.security.access.ConfigAttribute;

public interface PreInvocationAttribute extends ConfigAttribute {}


/* Location:              C:\Users\Gcorp\Downloads\spring-security-core-3.2.0.RELEASE.jar!\org\springframework\security\access\prepost\PreInvocationAttribute.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */