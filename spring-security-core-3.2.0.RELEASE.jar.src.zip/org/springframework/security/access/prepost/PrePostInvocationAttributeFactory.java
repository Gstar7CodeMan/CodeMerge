package org.springframework.security.access.prepost;

import org.springframework.aop.framework.AopInfrastructureBean;

public interface PrePostInvocationAttributeFactory extends AopInfrastructureBean {
  PreInvocationAttribute createPreInvocationAttribute(String paramString1, String paramString2, String paramString3);
  
  PostInvocationAttribute createPostInvocationAttribute(String paramString1, String paramString2);
}


/* Location:              C:\Users\Gcorp\Downloads\spring-security-core-3.2.0.RELEASE.jar!\org\springframework\security\access\prepost\PrePostInvocationAttributeFactory.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */