/*    */ package org.springframework.security.access.prepost;
/*    */ 
/*    */ import java.util.Collection;
/*    */ import org.aopalliance.intercept.MethodInvocation;
/*    */ import org.apache.commons.logging.Log;
/*    */ import org.apache.commons.logging.LogFactory;
/*    */ import org.springframework.security.access.AccessDecisionVoter;
/*    */ import org.springframework.security.access.ConfigAttribute;
/*    */ import org.springframework.security.core.Authentication;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class PreInvocationAuthorizationAdviceVoter
/*    */   implements AccessDecisionVoter<MethodInvocation>
/*    */ {
/* 25 */   protected final Log logger = LogFactory.getLog(getClass());
/*    */   
/*    */   private final PreInvocationAuthorizationAdvice preAdvice;
/*    */   
/*    */   public PreInvocationAuthorizationAdviceVoter(PreInvocationAuthorizationAdvice pre) {
/* 30 */     this.preAdvice = pre;
/*    */   }
/*    */   
/*    */   public boolean supports(ConfigAttribute attribute) {
/* 34 */     return attribute instanceof PreInvocationAttribute;
/*    */   }
/*    */   
/*    */   public boolean supports(Class<?> clazz) {
/* 38 */     return MethodInvocation.class.isAssignableFrom(clazz);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public int vote(Authentication authentication, MethodInvocation method, Collection<ConfigAttribute> attributes) {
/* 47 */     PreInvocationAttribute preAttr = findPreInvocationAttribute(attributes);
/*    */     
/* 49 */     if (preAttr == null)
/*    */     {
/* 51 */       return 0;
/*    */     }
/*    */     
/* 54 */     boolean allowed = this.preAdvice.before(authentication, method, preAttr);
/*    */     
/* 56 */     return allowed ? 1 : -1;
/*    */   }
/*    */   
/*    */   private PreInvocationAttribute findPreInvocationAttribute(Collection<ConfigAttribute> config) {
/* 60 */     for (ConfigAttribute attribute : config) {
/* 61 */       if (attribute instanceof PreInvocationAttribute) {
/* 62 */         return (PreInvocationAttribute)attribute;
/*    */       }
/*    */     } 
/*    */     
/* 66 */     return null;
/*    */   }
/*    */ }


/* Location:              C:\Users\Gcorp\Downloads\spring-security-core-3.2.0.RELEASE.jar!\org\springframework\security\access\prepost\PreInvocationAuthorizationAdviceVoter.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */