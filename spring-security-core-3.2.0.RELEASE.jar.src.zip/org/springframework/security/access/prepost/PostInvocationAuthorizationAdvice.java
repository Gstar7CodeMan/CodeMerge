package org.springframework.security.access.prepost;

import org.aopalliance.intercept.MethodInvocation;
import org.springframework.aop.framework.AopInfrastructureBean;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.security.core.Authentication;

public interface PostInvocationAuthorizationAdvice extends AopInfrastructureBean {
  Object after(Authentication paramAuthentication, MethodInvocation paramMethodInvocation, PostInvocationAttribute paramPostInvocationAttribute, Object paramObject) throws AccessDeniedException;
}


/* Location:              C:\Users\Gcorp\Downloads\spring-security-core-3.2.0.RELEASE.jar!\org\springframework\security\access\prepost\PostInvocationAuthorizationAdvice.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */