/*     */ package org.springframework.security.access.prepost;
/*     */ 
/*     */ import java.lang.annotation.Annotation;
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import org.springframework.core.annotation.AnnotationUtils;
/*     */ import org.springframework.security.access.ConfigAttribute;
/*     */ import org.springframework.security.access.method.AbstractMethodSecurityMetadataSource;
/*     */ import org.springframework.util.ClassUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PrePostAnnotationSecurityMetadataSource
/*     */   extends AbstractMethodSecurityMetadataSource
/*     */ {
/*     */   private final PrePostInvocationAttributeFactory attributeFactory;
/*     */   
/*     */   public PrePostAnnotationSecurityMetadataSource(PrePostInvocationAttributeFactory attributeFactory) {
/*  35 */     this.attributeFactory = attributeFactory;
/*     */   }
/*     */   
/*     */   public Collection<ConfigAttribute> getAttributes(Method method, Class<?> targetClass) {
/*  39 */     if (method.getDeclaringClass() == Object.class) {
/*  40 */       return Collections.emptyList();
/*     */     }
/*     */     
/*  43 */     this.logger.trace("Looking for Pre/Post annotations for method '" + method.getName() + "' on target class '" + targetClass + "'");
/*     */     
/*  45 */     PreFilter preFilter = findAnnotation(method, targetClass, PreFilter.class);
/*  46 */     PreAuthorize preAuthorize = findAnnotation(method, targetClass, PreAuthorize.class);
/*  47 */     PostFilter postFilter = findAnnotation(method, targetClass, PostFilter.class);
/*     */     
/*  49 */     PostAuthorize postAuthorize = findAnnotation(method, targetClass, PostAuthorize.class);
/*     */     
/*  51 */     if (preFilter == null && preAuthorize == null && postFilter == null && postAuthorize == null) {
/*     */       
/*  53 */       this.logger.trace("No expression annotations found");
/*  54 */       return Collections.emptyList();
/*     */     } 
/*     */     
/*  57 */     String preFilterAttribute = (preFilter == null) ? null : preFilter.value();
/*  58 */     String filterObject = (preFilter == null) ? null : preFilter.filterTarget();
/*  59 */     String preAuthorizeAttribute = (preAuthorize == null) ? null : preAuthorize.value();
/*  60 */     String postFilterAttribute = (postFilter == null) ? null : postFilter.value();
/*  61 */     String postAuthorizeAttribute = (postAuthorize == null) ? null : postAuthorize.value();
/*     */     
/*  63 */     ArrayList<ConfigAttribute> attrs = new ArrayList<ConfigAttribute>(2);
/*     */     
/*  65 */     PreInvocationAttribute pre = this.attributeFactory.createPreInvocationAttribute(preFilterAttribute, filterObject, preAuthorizeAttribute);
/*     */     
/*  67 */     if (pre != null) {
/*  68 */       attrs.add(pre);
/*     */     }
/*     */     
/*  71 */     PostInvocationAttribute post = this.attributeFactory.createPostInvocationAttribute(postFilterAttribute, postAuthorizeAttribute);
/*     */     
/*  73 */     if (post != null) {
/*  74 */       attrs.add(post);
/*     */     }
/*     */     
/*  77 */     attrs.trimToSize();
/*     */     
/*  79 */     return attrs;
/*     */   }
/*     */   
/*     */   public Collection<ConfigAttribute> getAllConfigAttributes() {
/*  83 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private <A extends Annotation> A findAnnotation(Method method, Class<?> targetClass, Class<A> annotationClass) {
/*  94 */     Method specificMethod = ClassUtils.getMostSpecificMethod(method, targetClass);
/*  95 */     Annotation annotation = AnnotationUtils.findAnnotation(specificMethod, annotationClass);
/*     */     
/*  97 */     if (annotation != null) {
/*  98 */       this.logger.debug(annotation + " found on specific method: " + specificMethod);
/*  99 */       return (A)annotation;
/*     */     } 
/*     */ 
/*     */     
/* 103 */     if (specificMethod != method) {
/* 104 */       annotation = AnnotationUtils.findAnnotation(method, annotationClass);
/*     */       
/* 106 */       if (annotation != null) {
/* 107 */         this.logger.debug(annotation + " found on: " + method);
/* 108 */         return (A)annotation;
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 113 */     annotation = AnnotationUtils.findAnnotation(specificMethod.getDeclaringClass(), annotationClass);
/*     */     
/* 115 */     if (annotation != null) {
/* 116 */       this.logger.debug(annotation + " found on: " + specificMethod.getDeclaringClass().getName());
/* 117 */       return (A)annotation;
/*     */     } 
/*     */     
/* 120 */     return null;
/*     */   }
/*     */ }


/* Location:              C:\Users\Gcorp\Downloads\spring-security-core-3.2.0.RELEASE.jar!\org\springframework\security\access\prepost\PrePostAnnotationSecurityMetadataSource.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */