package org.springframework.security.access;

import java.util.Collection;
import org.springframework.aop.framework.AopInfrastructureBean;
import org.springframework.security.core.Authentication;

public interface PermissionCacheOptimizer extends AopInfrastructureBean {
  void cachePermissionsFor(Authentication paramAuthentication, Collection<?> paramCollection);
}


/* Location:              C:\Users\Gcorp\Downloads\spring-security-core-3.2.0.RELEASE.jar!\org\springframework\security\access\PermissionCacheOptimizer.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */