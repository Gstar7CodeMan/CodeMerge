/*    */ package org.springframework.security.access.event;
/*    */ 
/*    */ import org.apache.commons.logging.Log;
/*    */ import org.apache.commons.logging.LogFactory;
/*    */ import org.springframework.context.ApplicationEvent;
/*    */ import org.springframework.context.ApplicationListener;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class LoggerListener
/*    */   implements ApplicationListener<AbstractAuthorizationEvent>
/*    */ {
/* 35 */   private static final Log logger = LogFactory.getLog(LoggerListener.class);
/*    */ 
/*    */ 
/*    */   
/*    */   public void onApplicationEvent(AbstractAuthorizationEvent event) {
/* 40 */     if (event instanceof AuthenticationCredentialsNotFoundEvent) {
/* 41 */       AuthenticationCredentialsNotFoundEvent authEvent = (AuthenticationCredentialsNotFoundEvent)event;
/*    */       
/* 43 */       if (logger.isWarnEnabled()) {
/* 44 */         logger.warn("Security interception failed due to: " + authEvent.getCredentialsNotFoundException() + "; secure object: " + authEvent.getSource() + "; configuration attributes: " + authEvent.getConfigAttributes());
/*    */       }
/*    */     } 
/*    */ 
/*    */ 
/*    */     
/* 50 */     if (event instanceof AuthorizationFailureEvent) {
/* 51 */       AuthorizationFailureEvent authEvent = (AuthorizationFailureEvent)event;
/*    */       
/* 53 */       if (logger.isWarnEnabled()) {
/* 54 */         logger.warn("Security authorization failed due to: " + authEvent.getAccessDeniedException() + "; authenticated principal: " + authEvent.getAuthentication() + "; secure object: " + authEvent.getSource() + "; configuration attributes: " + authEvent.getConfigAttributes());
/*    */       }
/*    */     } 
/*    */ 
/*    */ 
/*    */ 
/*    */     
/* 61 */     if (event instanceof AuthorizedEvent) {
/* 62 */       AuthorizedEvent authEvent = (AuthorizedEvent)event;
/*    */       
/* 64 */       if (logger.isInfoEnabled()) {
/* 65 */         logger.info("Security authorized for authenticated principal: " + authEvent.getAuthentication() + "; secure object: " + authEvent.getSource() + "; configuration attributes: " + authEvent.getConfigAttributes());
/*    */       }
/*    */     } 
/*    */ 
/*    */ 
/*    */     
/* 71 */     if (event instanceof PublicInvocationEvent) {
/* 72 */       PublicInvocationEvent authEvent = (PublicInvocationEvent)event;
/*    */       
/* 74 */       if (logger.isInfoEnabled())
/* 75 */         logger.info("Security interception not required for public secure object: " + authEvent.getSource()); 
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\Gcorp\Downloads\spring-security-core-3.2.0.RELEASE.jar!\org\springframework\security\access\event\LoggerListener.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */