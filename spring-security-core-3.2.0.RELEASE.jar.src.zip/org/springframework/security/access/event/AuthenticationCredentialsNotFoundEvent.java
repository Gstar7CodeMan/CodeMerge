/*    */ package org.springframework.security.access.event;
/*    */ 
/*    */ import java.util.Collection;
/*    */ import org.springframework.security.access.ConfigAttribute;
/*    */ import org.springframework.security.authentication.AuthenticationCredentialsNotFoundException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class AuthenticationCredentialsNotFoundEvent
/*    */   extends AbstractAuthorizationEvent
/*    */ {
/*    */   private AuthenticationCredentialsNotFoundException credentialsNotFoundException;
/*    */   private Collection<ConfigAttribute> configAttribs;
/*    */   
/*    */   public AuthenticationCredentialsNotFoundEvent(Object secureObject, Collection<ConfigAttribute> attributes, AuthenticationCredentialsNotFoundException credentialsNotFoundException) {
/* 48 */     super(secureObject);
/*    */     
/* 50 */     if (attributes == null || credentialsNotFoundException == null) {
/* 51 */       throw new IllegalArgumentException("All parameters are required and cannot be null");
/*    */     }
/*    */     
/* 54 */     this.configAttribs = attributes;
/* 55 */     this.credentialsNotFoundException = credentialsNotFoundException;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public Collection<ConfigAttribute> getConfigAttributes() {
/* 61 */     return this.configAttribs;
/*    */   }
/*    */   
/*    */   public AuthenticationCredentialsNotFoundException getCredentialsNotFoundException() {
/* 65 */     return this.credentialsNotFoundException;
/*    */   }
/*    */ }


/* Location:              C:\Users\Gcorp\Downloads\spring-security-core-3.2.0.RELEASE.jar!\org\springframework\security\access\event\AuthenticationCredentialsNotFoundEvent.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */