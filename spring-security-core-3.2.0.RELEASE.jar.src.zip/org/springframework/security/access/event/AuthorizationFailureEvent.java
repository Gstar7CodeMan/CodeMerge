/*    */ package org.springframework.security.access.event;
/*    */ 
/*    */ import java.util.Collection;
/*    */ import org.springframework.security.access.AccessDeniedException;
/*    */ import org.springframework.security.access.ConfigAttribute;
/*    */ import org.springframework.security.core.Authentication;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class AuthorizationFailureEvent
/*    */   extends AbstractAuthorizationEvent
/*    */ {
/*    */   private AccessDeniedException accessDeniedException;
/*    */   private Authentication authentication;
/*    */   private Collection<ConfigAttribute> configAttributes;
/*    */   
/*    */   public AuthorizationFailureEvent(Object secureObject, Collection<ConfigAttribute> attributes, Authentication authentication, AccessDeniedException accessDeniedException) {
/* 57 */     super(secureObject);
/*    */     
/* 59 */     if (attributes == null || authentication == null || accessDeniedException == null) {
/* 60 */       throw new IllegalArgumentException("All parameters are required and cannot be null");
/*    */     }
/*    */     
/* 63 */     this.configAttributes = attributes;
/* 64 */     this.authentication = authentication;
/* 65 */     this.accessDeniedException = accessDeniedException;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public AccessDeniedException getAccessDeniedException() {
/* 71 */     return this.accessDeniedException;
/*    */   }
/*    */   
/*    */   public Authentication getAuthentication() {
/* 75 */     return this.authentication;
/*    */   }
/*    */   
/*    */   public Collection<ConfigAttribute> getConfigAttributes() {
/* 79 */     return this.configAttributes;
/*    */   }
/*    */ }


/* Location:              C:\Users\Gcorp\Downloads\spring-security-core-3.2.0.RELEASE.jar!\org\springframework\security\access\event\AuthorizationFailureEvent.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */