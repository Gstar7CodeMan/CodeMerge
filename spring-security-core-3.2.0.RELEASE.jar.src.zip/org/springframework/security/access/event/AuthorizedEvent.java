/*    */ package org.springframework.security.access.event;
/*    */ 
/*    */ import java.util.Collection;
/*    */ import org.springframework.security.access.ConfigAttribute;
/*    */ import org.springframework.security.core.Authentication;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class AuthorizedEvent
/*    */   extends AbstractAuthorizationEvent
/*    */ {
/*    */   private Authentication authentication;
/*    */   private Collection<ConfigAttribute> configAttributes;
/*    */   
/*    */   public AuthorizedEvent(Object secureObject, Collection<ConfigAttribute> attributes, Authentication authentication) {
/* 47 */     super(secureObject);
/*    */     
/* 49 */     if (attributes == null || authentication == null) {
/* 50 */       throw new IllegalArgumentException("All parameters are required and cannot be null");
/*    */     }
/*    */     
/* 53 */     this.configAttributes = attributes;
/* 54 */     this.authentication = authentication;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public Authentication getAuthentication() {
/* 60 */     return this.authentication;
/*    */   }
/*    */   
/*    */   public Collection<ConfigAttribute> getConfigAttributes() {
/* 64 */     return this.configAttributes;
/*    */   }
/*    */ }


/* Location:              C:\Users\Gcorp\Downloads\spring-security-core-3.2.0.RELEASE.jar!\org\springframework\security\access\event\AuthorizedEvent.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */