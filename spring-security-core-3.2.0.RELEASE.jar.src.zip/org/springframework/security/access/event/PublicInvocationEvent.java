/*    */ package org.springframework.security.access.event;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class PublicInvocationEvent
/*    */   extends AbstractAuthorizationEvent
/*    */ {
/*    */   public PublicInvocationEvent(Object secureObject) {
/* 35 */     super(secureObject);
/*    */   }
/*    */ }


/* Location:              C:\Users\Gcorp\Downloads\spring-security-core-3.2.0.RELEASE.jar!\org\springframework\security\access\event\PublicInvocationEvent.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */