package org.springframework.security.access;

import java.util.Collection;
import org.springframework.security.authentication.InsufficientAuthenticationException;
import org.springframework.security.core.Authentication;

public interface AccessDecisionManager {
  void decide(Authentication paramAuthentication, Object paramObject, Collection<ConfigAttribute> paramCollection) throws AccessDeniedException, InsufficientAuthenticationException;
  
  boolean supports(ConfigAttribute paramConfigAttribute);
  
  boolean supports(Class<?> paramClass);
}


/* Location:              C:\Users\Gcorp\Downloads\spring-security-core-3.2.0.RELEASE.jar!\org\springframework\security\access\AccessDecisionManager.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */