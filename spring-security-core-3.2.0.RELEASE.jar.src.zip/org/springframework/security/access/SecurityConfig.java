/*    */ package org.springframework.security.access;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ import org.springframework.util.Assert;
/*    */ import org.springframework.util.StringUtils;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SecurityConfig
/*    */   implements ConfigAttribute
/*    */ {
/*    */   private final String attrib;
/*    */   
/*    */   public SecurityConfig(String config) {
/* 37 */     Assert.hasText(config, "You must provide a configuration attribute");
/* 38 */     this.attrib = config;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean equals(Object obj) {
/* 44 */     if (obj instanceof ConfigAttribute) {
/* 45 */       ConfigAttribute attr = (ConfigAttribute)obj;
/*    */       
/* 47 */       return this.attrib.equals(attr.getAttribute());
/*    */     } 
/*    */     
/* 50 */     return false;
/*    */   }
/*    */   
/*    */   public String getAttribute() {
/* 54 */     return this.attrib;
/*    */   }
/*    */   
/*    */   public int hashCode() {
/* 58 */     return this.attrib.hashCode();
/*    */   }
/*    */   
/*    */   public String toString() {
/* 62 */     return this.attrib;
/*    */   }
/*    */   
/*    */   public static List<ConfigAttribute> createListFromCommaDelimitedString(String access) {
/* 66 */     return createList(StringUtils.commaDelimitedListToStringArray(access));
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   @Deprecated
/*    */   public static List<ConfigAttribute> createSingleAttributeList(String access) {
/* 74 */     return createList(new String[] { access });
/*    */   }
/*    */   
/*    */   public static List<ConfigAttribute> createList(String... attributeNames) {
/* 78 */     Assert.notNull(attributeNames, "You must supply an array of attribute names");
/* 79 */     List<ConfigAttribute> attributes = new ArrayList<ConfigAttribute>(attributeNames.length);
/*    */     
/* 81 */     for (String attribute : attributeNames) {
/* 82 */       attributes.add(new SecurityConfig(attribute.trim()));
/*    */     }
/*    */     
/* 85 */     return attributes;
/*    */   }
/*    */ }


/* Location:              C:\Users\Gcorp\Downloads\spring-security-core-3.2.0.RELEASE.jar!\org\springframework\security\access\SecurityConfig.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */