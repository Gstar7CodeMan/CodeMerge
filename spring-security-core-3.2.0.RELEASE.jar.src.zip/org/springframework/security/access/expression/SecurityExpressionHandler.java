package org.springframework.security.access.expression;

import org.springframework.aop.framework.AopInfrastructureBean;
import org.springframework.expression.EvaluationContext;
import org.springframework.expression.ExpressionParser;
import org.springframework.security.core.Authentication;

public interface SecurityExpressionHandler<T> extends AopInfrastructureBean {
  ExpressionParser getExpressionParser();
  
  EvaluationContext createEvaluationContext(Authentication paramAuthentication, T paramT);
}


/* Location:              C:\Users\Gcorp\Downloads\spring-security-core-3.2.0.RELEASE.jar!\org\springframework\security\access\expression\SecurityExpressionHandler.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */