/*     */ package org.springframework.security.access.expression;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.util.Collection;
/*     */ import java.util.HashSet;
/*     */ import java.util.Set;
/*     */ import org.springframework.security.access.PermissionEvaluator;
/*     */ import org.springframework.security.access.hierarchicalroles.RoleHierarchy;
/*     */ import org.springframework.security.authentication.AuthenticationTrustResolver;
/*     */ import org.springframework.security.core.Authentication;
/*     */ import org.springframework.security.core.GrantedAuthority;
/*     */ import org.springframework.security.core.authority.AuthorityUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class SecurityExpressionRoot
/*     */   implements SecurityExpressionOperations
/*     */ {
/*     */   protected final Authentication authentication;
/*     */   private AuthenticationTrustResolver trustResolver;
/*     */   private RoleHierarchy roleHierarchy;
/*     */   private Set<String> roles;
/*     */   public final boolean permitAll = true;
/*     */   public final boolean denyAll = false;
/*     */   private PermissionEvaluator permissionEvaluator;
/*  34 */   public final String read = "read";
/*  35 */   public final String write = "write";
/*  36 */   public final String create = "create";
/*  37 */   public final String delete = "delete";
/*  38 */   public final String admin = "administration";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SecurityExpressionRoot(Authentication authentication) {
/*  45 */     if (authentication == null) {
/*  46 */       throw new IllegalArgumentException("Authentication object cannot be null");
/*     */     }
/*  48 */     this.authentication = authentication;
/*     */   }
/*     */   
/*     */   public final boolean hasAuthority(String authority) {
/*  52 */     return hasRole(authority);
/*     */   }
/*     */   
/*     */   public final boolean hasAnyAuthority(String... authorities) {
/*  56 */     return hasAnyRole(authorities);
/*     */   }
/*     */   
/*     */   public final boolean hasRole(String role) {
/*  60 */     return getAuthoritySet().contains(role);
/*     */   }
/*     */   
/*     */   public final boolean hasAnyRole(String... roles) {
/*  64 */     Set<String> roleSet = getAuthoritySet();
/*     */     
/*  66 */     for (String role : roles) {
/*  67 */       if (roleSet.contains(role)) {
/*  68 */         return true;
/*     */       }
/*     */     } 
/*     */     
/*  72 */     return false;
/*     */   }
/*     */   
/*     */   public final Authentication getAuthentication() {
/*  76 */     return this.authentication;
/*     */   }
/*     */   
/*     */   public final boolean permitAll() {
/*  80 */     return true;
/*     */   }
/*     */   
/*     */   public final boolean denyAll() {
/*  84 */     return false;
/*     */   }
/*     */   
/*     */   public final boolean isAnonymous() {
/*  88 */     return this.trustResolver.isAnonymous(this.authentication);
/*     */   }
/*     */   
/*     */   public final boolean isAuthenticated() {
/*  92 */     return !isAnonymous();
/*     */   }
/*     */   
/*     */   public final boolean isRememberMe() {
/*  96 */     return this.trustResolver.isRememberMe(this.authentication);
/*     */   }
/*     */   
/*     */   public final boolean isFullyAuthenticated() {
/* 100 */     return (!this.trustResolver.isAnonymous(this.authentication) && !this.trustResolver.isRememberMe(this.authentication));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object getPrincipal() {
/* 108 */     return this.authentication.getPrincipal();
/*     */   }
/*     */   
/*     */   public void setTrustResolver(AuthenticationTrustResolver trustResolver) {
/* 112 */     this.trustResolver = trustResolver;
/*     */   }
/*     */   
/*     */   public void setRoleHierarchy(RoleHierarchy roleHierarchy) {
/* 116 */     this.roleHierarchy = roleHierarchy;
/*     */   }
/*     */   
/*     */   private Set<String> getAuthoritySet() {
/* 120 */     if (this.roles == null) {
/* 121 */       this.roles = new HashSet<String>();
/* 122 */       Collection<? extends GrantedAuthority> userAuthorities = this.authentication.getAuthorities();
/*     */       
/* 124 */       if (this.roleHierarchy != null) {
/* 125 */         userAuthorities = this.roleHierarchy.getReachableGrantedAuthorities(userAuthorities);
/*     */       }
/*     */       
/* 128 */       this.roles = AuthorityUtils.authorityListToSet(userAuthorities);
/*     */     } 
/*     */     
/* 131 */     return this.roles;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean hasPermission(Object target, Object permission) {
/* 136 */     return this.permissionEvaluator.hasPermission(this.authentication, target, permission);
/*     */   }
/*     */   
/*     */   public boolean hasPermission(Object targetId, String targetType, Object permission) {
/* 140 */     return this.permissionEvaluator.hasPermission(this.authentication, (Serializable)targetId, targetType, permission);
/*     */   }
/*     */   
/*     */   public void setPermissionEvaluator(PermissionEvaluator permissionEvaluator) {
/* 144 */     this.permissionEvaluator = permissionEvaluator;
/*     */   }
/*     */ }


/* Location:              C:\Users\Gcorp\Downloads\spring-security-core-3.2.0.RELEASE.jar!\org\springframework\security\access\expression\SecurityExpressionRoot.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */