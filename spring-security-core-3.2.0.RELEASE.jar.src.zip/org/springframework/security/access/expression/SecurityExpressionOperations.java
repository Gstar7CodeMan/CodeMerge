package org.springframework.security.access.expression;

import org.springframework.security.core.Authentication;

public interface SecurityExpressionOperations {
  Authentication getAuthentication();
  
  boolean hasAuthority(String paramString);
  
  boolean hasAnyAuthority(String... paramVarArgs);
  
  boolean hasRole(String paramString);
  
  boolean hasAnyRole(String... paramVarArgs);
  
  boolean permitAll();
  
  boolean denyAll();
  
  boolean isAnonymous();
  
  boolean isAuthenticated();
  
  boolean isRememberMe();
  
  boolean isFullyAuthenticated();
  
  boolean hasPermission(Object paramObject1, Object paramObject2);
  
  boolean hasPermission(Object paramObject1, String paramString, Object paramObject2);
}


/* Location:              C:\Users\Gcorp\Downloads\spring-security-core-3.2.0.RELEASE.jar!\org\springframework\security\access\expression\SecurityExpressionOperations.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */