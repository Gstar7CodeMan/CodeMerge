/*     */ package org.springframework.security.access.expression.method;
/*     */ 
/*     */ import java.lang.reflect.Array;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collection;
/*     */ import java.util.List;
/*     */ import org.aopalliance.intercept.MethodInvocation;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.core.ParameterNameDiscoverer;
/*     */ import org.springframework.expression.EvaluationContext;
/*     */ import org.springframework.expression.Expression;
/*     */ import org.springframework.expression.spel.support.StandardEvaluationContext;
/*     */ import org.springframework.security.access.PermissionCacheOptimizer;
/*     */ import org.springframework.security.access.expression.AbstractSecurityExpressionHandler;
/*     */ import org.springframework.security.access.expression.ExpressionUtils;
/*     */ import org.springframework.security.access.expression.SecurityExpressionOperations;
/*     */ import org.springframework.security.authentication.AuthenticationTrustResolver;
/*     */ import org.springframework.security.authentication.AuthenticationTrustResolverImpl;
/*     */ import org.springframework.security.core.Authentication;
/*     */ import org.springframework.security.core.parameters.DefaultSecurityParameterNameDiscoverer;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DefaultMethodSecurityExpressionHandler
/*     */   extends AbstractSecurityExpressionHandler<MethodInvocation>
/*     */   implements MethodSecurityExpressionHandler
/*     */ {
/*  35 */   protected final Log logger = LogFactory.getLog(getClass());
/*     */   
/*  37 */   private AuthenticationTrustResolver trustResolver = (AuthenticationTrustResolver)new AuthenticationTrustResolverImpl();
/*  38 */   private ParameterNameDiscoverer parameterNameDiscoverer = (ParameterNameDiscoverer)new DefaultSecurityParameterNameDiscoverer();
/*  39 */   private PermissionCacheOptimizer permissionCacheOptimizer = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public StandardEvaluationContext createEvaluationContextInternal(Authentication auth, MethodInvocation mi) {
/*  48 */     return new MethodSecurityEvaluationContext(auth, mi, this.parameterNameDiscoverer);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected MethodSecurityExpressionOperations createSecurityExpressionRoot(Authentication authentication, MethodInvocation invocation) {
/*  55 */     MethodSecurityExpressionRoot root = new MethodSecurityExpressionRoot(authentication);
/*  56 */     root.setThis(invocation.getThis());
/*  57 */     root.setPermissionEvaluator(getPermissionEvaluator());
/*  58 */     root.setTrustResolver(this.trustResolver);
/*  59 */     root.setRoleHierarchy(getRoleHierarchy());
/*     */     
/*  61 */     return root;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object filter(Object filterTarget, Expression filterExpression, EvaluationContext ctx) {
/*  73 */     MethodSecurityExpressionOperations rootObject = (MethodSecurityExpressionOperations)ctx.getRootObject().getValue();
/*  74 */     boolean debug = this.logger.isDebugEnabled();
/*     */ 
/*     */     
/*  77 */     if (debug) {
/*  78 */       this.logger.debug("Filtering with expression: " + filterExpression.getExpressionString());
/*     */     }
/*     */     
/*  81 */     if (filterTarget instanceof Collection) {
/*  82 */       Collection<Object> collection = (Collection)filterTarget;
/*  83 */       List<Object> retainList = new ArrayList(collection.size());
/*     */       
/*  85 */       if (debug) {
/*  86 */         this.logger.debug("Filtering collection with " + collection.size() + " elements");
/*     */       }
/*     */       
/*  89 */       if (this.permissionCacheOptimizer != null) {
/*  90 */         this.permissionCacheOptimizer.cachePermissionsFor(rootObject.getAuthentication(), collection);
/*     */       }
/*     */       
/*  93 */       for (Object filterObject : filterTarget) {
/*  94 */         rootObject.setFilterObject(filterObject);
/*     */         
/*  96 */         if (ExpressionUtils.evaluateAsBoolean(filterExpression, ctx)) {
/*  97 */           retainList.add(filterObject);
/*     */         }
/*     */       } 
/*     */       
/* 101 */       if (debug) {
/* 102 */         this.logger.debug("Retaining elements: " + retainList);
/*     */       }
/*     */       
/* 105 */       collection.clear();
/* 106 */       collection.addAll(retainList);
/*     */       
/* 108 */       return filterTarget;
/*     */     } 
/*     */     
/* 111 */     if (filterTarget.getClass().isArray()) {
/* 112 */       Object[] array = (Object[])filterTarget;
/* 113 */       List<Object> retainList = new ArrayList(array.length);
/*     */       
/* 115 */       if (debug) {
/* 116 */         this.logger.debug("Filtering array with " + array.length + " elements");
/*     */       }
/*     */       
/* 119 */       if (this.permissionCacheOptimizer != null) {
/* 120 */         this.permissionCacheOptimizer.cachePermissionsFor(rootObject.getAuthentication(), Arrays.asList(array));
/*     */       }
/*     */       
/* 123 */       for (Object o : array) {
/* 124 */         rootObject.setFilterObject(o);
/*     */         
/* 126 */         if (ExpressionUtils.evaluateAsBoolean(filterExpression, ctx)) {
/* 127 */           retainList.add(o);
/*     */         }
/*     */       } 
/*     */       
/* 131 */       if (debug) {
/* 132 */         this.logger.debug("Retaining elements: " + retainList);
/*     */       }
/*     */       
/* 135 */       Object[] filtered = (Object[])Array.newInstance(filterTarget.getClass().getComponentType(), retainList.size());
/*     */       
/* 137 */       for (int i = 0; i < retainList.size(); i++) {
/* 138 */         filtered[i] = retainList.get(i);
/*     */       }
/*     */       
/* 141 */       return filtered;
/*     */     } 
/*     */     
/* 144 */     throw new IllegalArgumentException("Filter target must be a collection or array type, but was " + filterTarget);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setTrustResolver(AuthenticationTrustResolver trustResolver) {
/* 156 */     Assert.notNull(trustResolver, "trustResolver cannot be null");
/* 157 */     this.trustResolver = trustResolver;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setParameterNameDiscoverer(ParameterNameDiscoverer parameterNameDiscoverer) {
/* 165 */     this.parameterNameDiscoverer = parameterNameDiscoverer;
/*     */   }
/*     */   
/*     */   public void setPermissionCacheOptimizer(PermissionCacheOptimizer permissionCacheOptimizer) {
/* 169 */     this.permissionCacheOptimizer = permissionCacheOptimizer;
/*     */   }
/*     */   
/*     */   public void setReturnObject(Object returnObject, EvaluationContext ctx) {
/* 173 */     ((MethodSecurityExpressionOperations)ctx.getRootObject().getValue()).setReturnObject(returnObject);
/*     */   }
/*     */ }


/* Location:              C:\Users\Gcorp\Downloads\spring-security-core-3.2.0.RELEASE.jar!\org\springframework\security\access\expression\method\DefaultMethodSecurityExpressionHandler.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */