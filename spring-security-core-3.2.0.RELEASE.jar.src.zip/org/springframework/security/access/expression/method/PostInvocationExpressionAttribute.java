/*    */ package org.springframework.security.access.expression.method;
/*    */ 
/*    */ import org.springframework.expression.Expression;
/*    */ import org.springframework.expression.ParseException;
/*    */ import org.springframework.security.access.prepost.PostInvocationAttribute;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class PostInvocationExpressionAttribute
/*    */   extends AbstractExpressionBasedMethodConfigAttribute
/*    */   implements PostInvocationAttribute
/*    */ {
/*    */   PostInvocationExpressionAttribute(String filterExpression, String authorizeExpression) throws ParseException {
/* 17 */     super(filterExpression, authorizeExpression);
/*    */   }
/*    */ 
/*    */   
/*    */   PostInvocationExpressionAttribute(Expression filterExpression, Expression authorizeExpression) throws ParseException {
/* 22 */     super(filterExpression, authorizeExpression);
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 27 */     StringBuilder sb = new StringBuilder();
/* 28 */     Expression authorize = getAuthorizeExpression();
/* 29 */     Expression filter = getFilterExpression();
/* 30 */     sb.append("[authorize: '").append((authorize == null) ? "null" : authorize.getExpressionString());
/* 31 */     sb.append("', filter: '").append((filter == null) ? "null" : filter.getExpressionString()).append("']");
/* 32 */     return sb.toString();
/*    */   }
/*    */ }


/* Location:              C:\Users\Gcorp\Downloads\spring-security-core-3.2.0.RELEASE.jar!\org\springframework\security\access\expression\method\PostInvocationExpressionAttribute.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */