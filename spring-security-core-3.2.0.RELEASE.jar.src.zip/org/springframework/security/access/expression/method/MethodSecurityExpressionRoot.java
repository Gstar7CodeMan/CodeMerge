/*    */ package org.springframework.security.access.expression.method;
/*    */ 
/*    */ import org.springframework.security.access.expression.SecurityExpressionRoot;
/*    */ import org.springframework.security.core.Authentication;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class MethodSecurityExpressionRoot
/*    */   extends SecurityExpressionRoot
/*    */   implements MethodSecurityExpressionOperations
/*    */ {
/*    */   private Object filterObject;
/*    */   private Object returnObject;
/*    */   private Object target;
/*    */   
/*    */   MethodSecurityExpressionRoot(Authentication a) {
/* 19 */     super(a);
/*    */   }
/*    */   
/*    */   public void setFilterObject(Object filterObject) {
/* 23 */     this.filterObject = filterObject;
/*    */   }
/*    */   
/*    */   public Object getFilterObject() {
/* 27 */     return this.filterObject;
/*    */   }
/*    */   
/*    */   public void setReturnObject(Object returnObject) {
/* 31 */     this.returnObject = returnObject;
/*    */   }
/*    */   
/*    */   public Object getReturnObject() {
/* 35 */     return this.returnObject;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   void setThis(Object target) {
/* 45 */     this.target = target;
/*    */   }
/*    */   
/*    */   public Object getThis() {
/* 49 */     return this.target;
/*    */   }
/*    */ }


/* Location:              C:\Users\Gcorp\Downloads\spring-security-core-3.2.0.RELEASE.jar!\org\springframework\security\access\expression\method\MethodSecurityExpressionRoot.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */