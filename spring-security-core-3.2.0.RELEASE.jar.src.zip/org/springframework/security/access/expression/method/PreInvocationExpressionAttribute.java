/*    */ package org.springframework.security.access.expression.method;
/*    */ 
/*    */ import org.springframework.expression.Expression;
/*    */ import org.springframework.expression.ParseException;
/*    */ import org.springframework.security.access.prepost.PreInvocationAttribute;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class PreInvocationExpressionAttribute
/*    */   extends AbstractExpressionBasedMethodConfigAttribute
/*    */   implements PreInvocationAttribute
/*    */ {
/*    */   private final String filterTarget;
/*    */   
/*    */   PreInvocationExpressionAttribute(String filterExpression, String filterTarget, String authorizeExpression) throws ParseException {
/* 19 */     super(filterExpression, authorizeExpression);
/*    */     
/* 21 */     this.filterTarget = filterTarget;
/*    */   }
/*    */ 
/*    */   
/*    */   PreInvocationExpressionAttribute(Expression filterExpression, String filterTarget, Expression authorizeExpression) throws ParseException {
/* 26 */     super(filterExpression, authorizeExpression);
/*    */     
/* 28 */     this.filterTarget = filterTarget;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   String getFilterTarget() {
/* 37 */     return this.filterTarget;
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 42 */     StringBuilder sb = new StringBuilder();
/* 43 */     Expression authorize = getAuthorizeExpression();
/* 44 */     Expression filter = getFilterExpression();
/* 45 */     sb.append("[authorize: '").append((authorize == null) ? "null" : authorize.getExpressionString());
/* 46 */     sb.append("', filter: '").append((filter == null) ? "null" : filter.getExpressionString());
/* 47 */     sb.append("', filterTarget: '").append(this.filterTarget).append("']");
/* 48 */     return sb.toString();
/*    */   }
/*    */ }


/* Location:              C:\Users\Gcorp\Downloads\spring-security-core-3.2.0.RELEASE.jar!\org\springframework\security\access\expression\method\PreInvocationExpressionAttribute.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */