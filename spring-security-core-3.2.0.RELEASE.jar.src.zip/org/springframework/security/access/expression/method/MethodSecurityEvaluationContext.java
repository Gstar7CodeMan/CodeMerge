/*    */ package org.springframework.security.access.expression.method;
/*    */ 
/*    */ import java.lang.reflect.Method;
/*    */ import org.aopalliance.intercept.MethodInvocation;
/*    */ import org.apache.commons.logging.Log;
/*    */ import org.apache.commons.logging.LogFactory;
/*    */ import org.springframework.aop.framework.AopProxyUtils;
/*    */ import org.springframework.aop.support.AopUtils;
/*    */ import org.springframework.core.ParameterNameDiscoverer;
/*    */ import org.springframework.expression.spel.support.StandardEvaluationContext;
/*    */ import org.springframework.security.core.Authentication;
/*    */ import org.springframework.security.core.parameters.DefaultSecurityParameterNameDiscoverer;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class MethodSecurityEvaluationContext
/*    */   extends StandardEvaluationContext
/*    */ {
/* 24 */   private static final Log logger = LogFactory.getLog(MethodSecurityEvaluationContext.class);
/*    */ 
/*    */   
/*    */   private ParameterNameDiscoverer parameterNameDiscoverer;
/*    */ 
/*    */   
/*    */   private final MethodInvocation mi;
/*    */   
/*    */   private boolean argumentsAdded;
/*    */ 
/*    */   
/*    */   public MethodSecurityEvaluationContext(Authentication user, MethodInvocation mi) {
/* 36 */     this(user, mi, (ParameterNameDiscoverer)new DefaultSecurityParameterNameDiscoverer());
/*    */   }
/*    */ 
/*    */   
/*    */   public MethodSecurityEvaluationContext(Authentication user, MethodInvocation mi, ParameterNameDiscoverer parameterNameDiscoverer) {
/* 41 */     this.mi = mi;
/* 42 */     this.parameterNameDiscoverer = parameterNameDiscoverer;
/*    */   }
/*    */ 
/*    */   
/*    */   public Object lookupVariable(String name) {
/* 47 */     Object variable = super.lookupVariable(name);
/*    */     
/* 49 */     if (variable != null) {
/* 50 */       return variable;
/*    */     }
/*    */     
/* 53 */     if (!this.argumentsAdded) {
/* 54 */       addArgumentsAsVariables();
/* 55 */       this.argumentsAdded = true;
/*    */     } 
/*    */     
/* 58 */     variable = super.lookupVariable(name);
/*    */     
/* 60 */     if (variable != null) {
/* 61 */       return variable;
/*    */     }
/*    */     
/* 64 */     return null;
/*    */   }
/*    */   
/*    */   public void setParameterNameDiscoverer(ParameterNameDiscoverer parameterNameDiscoverer) {
/* 68 */     this.parameterNameDiscoverer = parameterNameDiscoverer;
/*    */   }
/*    */   
/*    */   private void addArgumentsAsVariables() {
/* 72 */     Object[] args = this.mi.getArguments();
/*    */     
/* 74 */     if (args.length == 0) {
/*    */       return;
/*    */     }
/*    */     
/* 78 */     Object targetObject = this.mi.getThis();
/*    */     
/* 80 */     Class<?> targetClass = AopProxyUtils.ultimateTargetClass(targetObject);
/*    */     
/* 82 */     if (targetClass == null)
/*    */     {
/* 84 */       targetClass = targetObject.getClass();
/*    */     }
/*    */     
/* 87 */     Method method = AopUtils.getMostSpecificMethod(this.mi.getMethod(), targetClass);
/* 88 */     String[] paramNames = this.parameterNameDiscoverer.getParameterNames(method);
/*    */     
/* 90 */     if (paramNames == null) {
/* 91 */       logger.warn("Unable to resolve method parameter names for method: " + method + ". Debug symbol information is required if you are using parameter names in expressions.");
/*    */       
/*    */       return;
/*    */     } 
/*    */     
/* 96 */     for (int i = 0; i < args.length; i++)
/* 97 */       setVariable(paramNames[i], args[i]); 
/*    */   }
/*    */ }


/* Location:              C:\Users\Gcorp\Downloads\spring-security-core-3.2.0.RELEASE.jar!\org\springframework\security\access\expression\method\MethodSecurityEvaluationContext.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */