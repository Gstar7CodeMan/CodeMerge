package org.springframework.security.access.expression.method;

import org.springframework.security.access.expression.SecurityExpressionOperations;

public interface MethodSecurityExpressionOperations extends SecurityExpressionOperations {
  void setFilterObject(Object paramObject);
  
  Object getFilterObject();
  
  void setReturnObject(Object paramObject);
  
  Object getReturnObject();
  
  Object getThis();
}


/* Location:              C:\Users\Gcorp\Downloads\spring-security-core-3.2.0.RELEASE.jar!\org\springframework\security\access\expression\method\MethodSecurityExpressionOperations.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */