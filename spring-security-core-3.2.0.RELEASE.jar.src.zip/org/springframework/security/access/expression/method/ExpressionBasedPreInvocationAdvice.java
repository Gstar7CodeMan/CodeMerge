/*    */ package org.springframework.security.access.expression.method;
/*    */ 
/*    */ import org.aopalliance.intercept.MethodInvocation;
/*    */ import org.springframework.expression.EvaluationContext;
/*    */ import org.springframework.expression.Expression;
/*    */ import org.springframework.security.access.expression.ExpressionUtils;
/*    */ import org.springframework.security.access.prepost.PreInvocationAttribute;
/*    */ import org.springframework.security.access.prepost.PreInvocationAuthorizationAdvice;
/*    */ import org.springframework.security.core.Authentication;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ExpressionBasedPreInvocationAdvice
/*    */   implements PreInvocationAuthorizationAdvice
/*    */ {
/* 23 */   private MethodSecurityExpressionHandler expressionHandler = new DefaultMethodSecurityExpressionHandler();
/*    */   
/*    */   public boolean before(Authentication authentication, MethodInvocation mi, PreInvocationAttribute attr) {
/* 26 */     PreInvocationExpressionAttribute preAttr = (PreInvocationExpressionAttribute)attr;
/* 27 */     EvaluationContext ctx = this.expressionHandler.createEvaluationContext(authentication, mi);
/* 28 */     Expression preFilter = preAttr.getFilterExpression();
/* 29 */     Expression preAuthorize = preAttr.getAuthorizeExpression();
/*    */     
/* 31 */     if (preFilter != null) {
/* 32 */       Object filterTarget = findFilterTarget(preAttr.getFilterTarget(), ctx, mi);
/*    */       
/* 34 */       this.expressionHandler.filter(filterTarget, preFilter, ctx);
/*    */     } 
/*    */     
/* 37 */     if (preAuthorize == null) {
/* 38 */       return true;
/*    */     }
/*    */     
/* 41 */     return ExpressionUtils.evaluateAsBoolean(preAuthorize, ctx);
/*    */   }
/*    */   
/*    */   private Object findFilterTarget(String filterTargetName, EvaluationContext ctx, MethodInvocation mi) {
/* 45 */     Object filterTarget = null;
/*    */     
/* 47 */     if (filterTargetName.length() > 0) {
/* 48 */       filterTarget = ctx.lookupVariable(filterTargetName);
/* 49 */       if (filterTarget == null) {
/* 50 */         throw new IllegalArgumentException("Filter target was null, or no argument with name " + filterTargetName + " found in method");
/*    */       }
/*    */     }
/* 53 */     else if ((mi.getArguments()).length == 1) {
/* 54 */       Object arg = mi.getArguments()[0];
/* 55 */       if (arg.getClass().isArray() || arg instanceof java.util.Collection) {
/* 56 */         filterTarget = arg;
/*    */       }
/* 58 */       if (filterTarget == null) {
/* 59 */         throw new IllegalArgumentException("A PreFilter expression was set but the method argument type" + arg.getClass() + " is not filterable");
/*    */       }
/*    */     } 
/*    */ 
/*    */     
/* 64 */     if (filterTarget.getClass().isArray()) {
/* 65 */       throw new IllegalArgumentException("Pre-filtering on array types is not supported. Using a Collection will solve this problem");
/*    */     }
/*    */ 
/*    */     
/* 69 */     return filterTarget;
/*    */   }
/*    */ 
/*    */   
/*    */   public void setExpressionHandler(MethodSecurityExpressionHandler expressionHandler) {
/* 74 */     this.expressionHandler = expressionHandler;
/*    */   }
/*    */ }


/* Location:              C:\Users\Gcorp\Downloads\spring-security-core-3.2.0.RELEASE.jar!\org\springframework\security\access\expression\method\ExpressionBasedPreInvocationAdvice.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */