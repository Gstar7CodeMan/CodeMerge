package org.springframework.security.access.expression.method;

import org.aopalliance.intercept.MethodInvocation;
import org.springframework.expression.EvaluationContext;
import org.springframework.expression.Expression;
import org.springframework.security.access.expression.SecurityExpressionHandler;

public interface MethodSecurityExpressionHandler extends SecurityExpressionHandler<MethodInvocation> {
  Object filter(Object paramObject, Expression paramExpression, EvaluationContext paramEvaluationContext);
  
  void setReturnObject(Object paramObject, EvaluationContext paramEvaluationContext);
}


/* Location:              C:\Users\Gcorp\Downloads\spring-security-core-3.2.0.RELEASE.jar!\org\springframework\security\access\expression\method\MethodSecurityExpressionHandler.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */