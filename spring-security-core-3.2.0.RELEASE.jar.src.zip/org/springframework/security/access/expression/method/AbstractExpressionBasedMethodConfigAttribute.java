/*    */ package org.springframework.security.access.expression.method;
/*    */ 
/*    */ import org.springframework.expression.Expression;
/*    */ import org.springframework.expression.ParseException;
/*    */ import org.springframework.expression.spel.standard.SpelExpressionParser;
/*    */ import org.springframework.security.access.ConfigAttribute;
/*    */ import org.springframework.util.Assert;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ abstract class AbstractExpressionBasedMethodConfigAttribute
/*    */   implements ConfigAttribute
/*    */ {
/*    */   private final Expression filterExpression;
/*    */   private final Expression authorizeExpression;
/*    */   
/*    */   AbstractExpressionBasedMethodConfigAttribute(String filterExpression, String authorizeExpression) throws ParseException {
/* 27 */     Assert.isTrue((filterExpression != null || authorizeExpression != null), "Filter and authorization Expressions cannot both be null");
/* 28 */     SpelExpressionParser parser = new SpelExpressionParser();
/* 29 */     this.filterExpression = (filterExpression == null) ? null : parser.parseExpression(filterExpression);
/* 30 */     this.authorizeExpression = (authorizeExpression == null) ? null : parser.parseExpression(authorizeExpression);
/*    */   }
/*    */   
/*    */   AbstractExpressionBasedMethodConfigAttribute(Expression filterExpression, Expression authorizeExpression) throws ParseException {
/* 34 */     Assert.isTrue((filterExpression != null || authorizeExpression != null), "Filter and authorization Expressions cannot both be null");
/* 35 */     this.filterExpression = (filterExpression == null) ? null : filterExpression;
/* 36 */     this.authorizeExpression = (authorizeExpression == null) ? null : authorizeExpression;
/*    */   }
/*    */   
/*    */   Expression getFilterExpression() {
/* 40 */     return this.filterExpression;
/*    */   }
/*    */   
/*    */   Expression getAuthorizeExpression() {
/* 44 */     return this.authorizeExpression;
/*    */   }
/*    */   
/*    */   public String getAttribute() {
/* 48 */     return null;
/*    */   }
/*    */ }


/* Location:              C:\Users\Gcorp\Downloads\spring-security-core-3.2.0.RELEASE.jar!\org\springframework\security\access\expression\method\AbstractExpressionBasedMethodConfigAttribute.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */