/*    */ package org.springframework.security.access.expression.method;
/*    */ 
/*    */ import org.aopalliance.intercept.MethodInvocation;
/*    */ import org.apache.commons.logging.Log;
/*    */ import org.apache.commons.logging.LogFactory;
/*    */ import org.springframework.expression.EvaluationContext;
/*    */ import org.springframework.expression.Expression;
/*    */ import org.springframework.security.access.AccessDeniedException;
/*    */ import org.springframework.security.access.expression.ExpressionUtils;
/*    */ import org.springframework.security.access.prepost.PostInvocationAttribute;
/*    */ import org.springframework.security.access.prepost.PostInvocationAuthorizationAdvice;
/*    */ import org.springframework.security.core.Authentication;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ExpressionBasedPostInvocationAdvice
/*    */   implements PostInvocationAuthorizationAdvice
/*    */ {
/* 20 */   protected final Log logger = LogFactory.getLog(getClass());
/*    */   
/*    */   private final MethodSecurityExpressionHandler expressionHandler;
/*    */   
/*    */   public ExpressionBasedPostInvocationAdvice(MethodSecurityExpressionHandler expressionHandler) {
/* 25 */     this.expressionHandler = expressionHandler;
/*    */   }
/*    */ 
/*    */   
/*    */   public Object after(Authentication authentication, MethodInvocation mi, PostInvocationAttribute postAttr, Object returnedObject) throws AccessDeniedException {
/* 30 */     PostInvocationExpressionAttribute pia = (PostInvocationExpressionAttribute)postAttr;
/* 31 */     EvaluationContext ctx = this.expressionHandler.createEvaluationContext(authentication, mi);
/* 32 */     Expression postFilter = pia.getFilterExpression();
/* 33 */     Expression postAuthorize = pia.getAuthorizeExpression();
/*    */     
/* 35 */     if (postFilter != null) {
/* 36 */       if (this.logger.isDebugEnabled()) {
/* 37 */         this.logger.debug("Applying PostFilter expression " + postFilter);
/*    */       }
/*    */       
/* 40 */       if (returnedObject != null) {
/* 41 */         returnedObject = this.expressionHandler.filter(returnedObject, postFilter, ctx);
/*    */       }
/* 43 */       else if (this.logger.isDebugEnabled()) {
/* 44 */         this.logger.debug("Return object is null, filtering will be skipped");
/*    */       } 
/*    */     } 
/*    */ 
/*    */     
/* 49 */     this.expressionHandler.setReturnObject(returnedObject, ctx);
/*    */     
/* 51 */     if (postAuthorize != null && !ExpressionUtils.evaluateAsBoolean(postAuthorize, ctx)) {
/* 52 */       if (this.logger.isDebugEnabled()) {
/* 53 */         this.logger.debug("PostAuthorize expression rejected access");
/*    */       }
/* 55 */       throw new AccessDeniedException("Access is denied");
/*    */     } 
/*    */     
/* 58 */     return returnedObject;
/*    */   }
/*    */ }


/* Location:              C:\Users\Gcorp\Downloads\spring-security-core-3.2.0.RELEASE.jar!\org\springframework\security\access\expression\method\ExpressionBasedPostInvocationAdvice.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */