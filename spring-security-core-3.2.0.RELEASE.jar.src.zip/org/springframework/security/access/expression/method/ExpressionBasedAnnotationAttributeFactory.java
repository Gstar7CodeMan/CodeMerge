/*    */ package org.springframework.security.access.expression.method;
/*    */ 
/*    */ import org.springframework.expression.Expression;
/*    */ import org.springframework.expression.ExpressionParser;
/*    */ import org.springframework.expression.ParseException;
/*    */ import org.springframework.security.access.prepost.PostInvocationAttribute;
/*    */ import org.springframework.security.access.prepost.PreInvocationAttribute;
/*    */ import org.springframework.security.access.prepost.PrePostInvocationAttributeFactory;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ExpressionBasedAnnotationAttributeFactory
/*    */   implements PrePostInvocationAttributeFactory
/*    */ {
/* 34 */   private final Object parserLock = new Object();
/*    */   private ExpressionParser parser;
/*    */   private MethodSecurityExpressionHandler handler;
/*    */   
/*    */   public ExpressionBasedAnnotationAttributeFactory(MethodSecurityExpressionHandler handler) {
/* 39 */     this.handler = handler;
/*    */   }
/*    */ 
/*    */   
/*    */   public PreInvocationAttribute createPreInvocationAttribute(String preFilterAttribute, String filterObject, String preAuthorizeAttribute) {
/*    */     try {
/* 45 */       ExpressionParser parser = getParser();
/* 46 */       Expression preAuthorizeExpression = (preAuthorizeAttribute == null) ? parser.parseExpression("permitAll") : parser.parseExpression(preAuthorizeAttribute);
/* 47 */       Expression preFilterExpression = (preFilterAttribute == null) ? null : parser.parseExpression(preFilterAttribute);
/* 48 */       return new PreInvocationExpressionAttribute(preFilterExpression, filterObject, preAuthorizeExpression);
/* 49 */     } catch (ParseException e) {
/* 50 */       throw new IllegalArgumentException("Failed to parse expression '" + e.getExpressionString() + "'", e);
/*    */     } 
/*    */   }
/*    */   
/*    */   public PostInvocationAttribute createPostInvocationAttribute(String postFilterAttribute, String postAuthorizeAttribute) {
/*    */     try {
/* 56 */       ExpressionParser parser = getParser();
/* 57 */       Expression postAuthorizeExpression = (postAuthorizeAttribute == null) ? null : parser.parseExpression(postAuthorizeAttribute);
/* 58 */       Expression postFilterExpression = (postFilterAttribute == null) ? null : parser.parseExpression(postFilterAttribute);
/*    */       
/* 60 */       if (postFilterExpression != null || postAuthorizeExpression != null) {
/* 61 */         return new PostInvocationExpressionAttribute(postFilterExpression, postAuthorizeExpression);
/*    */       }
/* 63 */     } catch (ParseException e) {
/* 64 */       throw new IllegalArgumentException("Failed to parse expression '" + e.getExpressionString() + "'", e);
/*    */     } 
/*    */     
/* 67 */     return null;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   private ExpressionParser getParser() {
/* 76 */     if (this.parser != null) {
/* 77 */       return this.parser;
/*    */     }
/* 79 */     synchronized (this.parserLock) {
/* 80 */       this.parser = this.handler.getExpressionParser();
/* 81 */       this.handler = null;
/*    */     } 
/* 83 */     return this.parser;
/*    */   }
/*    */ }


/* Location:              C:\Users\Gcorp\Downloads\spring-security-core-3.2.0.RELEASE.jar!\org\springframework\security\access\expression\method\ExpressionBasedAnnotationAttributeFactory.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */