/*    */ package org.springframework.security.access.expression;
/*    */ 
/*    */ import org.springframework.beans.factory.BeanFactory;
/*    */ import org.springframework.context.ApplicationContext;
/*    */ import org.springframework.context.ApplicationContextAware;
/*    */ import org.springframework.context.expression.BeanFactoryResolver;
/*    */ import org.springframework.expression.BeanResolver;
/*    */ import org.springframework.expression.EvaluationContext;
/*    */ import org.springframework.expression.ExpressionParser;
/*    */ import org.springframework.expression.spel.standard.SpelExpressionParser;
/*    */ import org.springframework.expression.spel.support.StandardEvaluationContext;
/*    */ import org.springframework.security.access.PermissionEvaluator;
/*    */ import org.springframework.security.access.hierarchicalroles.RoleHierarchy;
/*    */ import org.springframework.security.core.Authentication;
/*    */ import org.springframework.util.Assert;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class AbstractSecurityExpressionHandler<T>
/*    */   implements SecurityExpressionHandler<T>, ApplicationContextAware
/*    */ {
/* 24 */   private ExpressionParser expressionParser = (ExpressionParser)new SpelExpressionParser();
/*    */   private BeanResolver br;
/*    */   private RoleHierarchy roleHierarchy;
/* 27 */   private PermissionEvaluator permissionEvaluator = new DenyAllPermissionEvaluator();
/*    */   
/*    */   public final ExpressionParser getExpressionParser() {
/* 30 */     return this.expressionParser;
/*    */   }
/*    */   
/*    */   public final void setExpressionParser(ExpressionParser expressionParser) {
/* 34 */     Assert.notNull(expressionParser, "expressionParser cannot be null");
/* 35 */     this.expressionParser = expressionParser;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public final EvaluationContext createEvaluationContext(Authentication authentication, T invocation) {
/* 47 */     SecurityExpressionOperations root = createSecurityExpressionRoot(authentication, invocation);
/* 48 */     StandardEvaluationContext ctx = createEvaluationContextInternal(authentication, invocation);
/* 49 */     ctx.setBeanResolver(this.br);
/* 50 */     ctx.setRootObject(root);
/*    */     
/* 52 */     return (EvaluationContext)ctx;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected StandardEvaluationContext createEvaluationContextInternal(Authentication authentication, T invocation) {
/* 66 */     return new StandardEvaluationContext();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected abstract SecurityExpressionOperations createSecurityExpressionRoot(Authentication paramAuthentication, T paramT);
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected RoleHierarchy getRoleHierarchy() {
/* 79 */     return this.roleHierarchy;
/*    */   }
/*    */   
/*    */   public void setRoleHierarchy(RoleHierarchy roleHierarchy) {
/* 83 */     this.roleHierarchy = roleHierarchy;
/*    */   }
/*    */   
/*    */   protected PermissionEvaluator getPermissionEvaluator() {
/* 87 */     return this.permissionEvaluator;
/*    */   }
/*    */   
/*    */   public void setPermissionEvaluator(PermissionEvaluator permissionEvaluator) {
/* 91 */     this.permissionEvaluator = permissionEvaluator;
/*    */   }
/*    */   
/*    */   public void setApplicationContext(ApplicationContext applicationContext) {
/* 95 */     this.br = (BeanResolver)new BeanFactoryResolver((BeanFactory)applicationContext);
/*    */   }
/*    */ }


/* Location:              C:\Users\Gcorp\Downloads\spring-security-core-3.2.0.RELEASE.jar!\org\springframework\security\access\expression\AbstractSecurityExpressionHandler.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */