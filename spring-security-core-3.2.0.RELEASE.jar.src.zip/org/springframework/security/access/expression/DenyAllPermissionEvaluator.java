/*    */ package org.springframework.security.access.expression;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ import org.apache.commons.logging.Log;
/*    */ import org.apache.commons.logging.LogFactory;
/*    */ import org.springframework.security.access.PermissionEvaluator;
/*    */ import org.springframework.security.core.Authentication;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DenyAllPermissionEvaluator
/*    */   implements PermissionEvaluator
/*    */ {
/* 19 */   private final Log logger = LogFactory.getLog(getClass());
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean hasPermission(Authentication authentication, Object target, Object permission) {
/* 25 */     this.logger.warn("Denying user " + authentication.getName() + " permission '" + permission + "' on object " + target);
/* 26 */     return false;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean hasPermission(Authentication authentication, Serializable targetId, String targetType, Object permission) {
/* 34 */     this.logger.warn("Denying user " + authentication.getName() + " permission '" + permission + "' on object with Id '" + targetId);
/*    */     
/* 36 */     return false;
/*    */   }
/*    */ }


/* Location:              C:\Users\Gcorp\Downloads\spring-security-core-3.2.0.RELEASE.jar!\org\springframework\security\access\expression\DenyAllPermissionEvaluator.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */