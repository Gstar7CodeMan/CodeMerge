/*    */ package org.springframework.security.access.hierarchicalroles;
/*    */ 
/*    */ import java.util.Collection;
/*    */ import org.springframework.security.core.GrantedAuthority;
/*    */ import org.springframework.security.core.userdetails.UserDetails;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class UserDetailsWrapper
/*    */   implements UserDetails
/*    */ {
/*    */   private static final long serialVersionUID = 1532428778390085311L;
/* 35 */   private UserDetails userDetails = null;
/*    */   
/* 37 */   private RoleHierarchy roleHierarchy = null;
/*    */   
/*    */   public UserDetailsWrapper(UserDetails userDetails, RoleHierarchy roleHierarchy) {
/* 40 */     this.userDetails = userDetails;
/* 41 */     this.roleHierarchy = roleHierarchy;
/*    */   }
/*    */   
/*    */   public boolean isAccountNonExpired() {
/* 45 */     return this.userDetails.isAccountNonExpired();
/*    */   }
/*    */   
/*    */   public boolean isAccountNonLocked() {
/* 49 */     return this.userDetails.isAccountNonLocked();
/*    */   }
/*    */   
/*    */   public Collection<? extends GrantedAuthority> getAuthorities() {
/* 53 */     return this.roleHierarchy.getReachableGrantedAuthorities(this.userDetails.getAuthorities());
/*    */   }
/*    */   
/*    */   public boolean isCredentialsNonExpired() {
/* 57 */     return this.userDetails.isCredentialsNonExpired();
/*    */   }
/*    */   
/*    */   public boolean isEnabled() {
/* 61 */     return this.userDetails.isEnabled();
/*    */   }
/*    */   
/*    */   public String getPassword() {
/* 65 */     return this.userDetails.getPassword();
/*    */   }
/*    */   
/*    */   public String getUsername() {
/* 69 */     return this.userDetails.getUsername();
/*    */   }
/*    */   
/*    */   public UserDetails getUnwrappedUserDetails() {
/* 73 */     return this.userDetails;
/*    */   }
/*    */ }


/* Location:              C:\Users\Gcorp\Downloads\spring-security-core-3.2.0.RELEASE.jar!\org\springframework\security\access\hierarchicalroles\UserDetailsWrapper.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */