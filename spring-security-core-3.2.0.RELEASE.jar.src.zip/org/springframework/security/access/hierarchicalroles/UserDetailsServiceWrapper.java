/*    */ package org.springframework.security.access.hierarchicalroles;
/*    */ 
/*    */ import org.springframework.security.core.userdetails.UserDetails;
/*    */ import org.springframework.security.core.userdetails.UserDetailsService;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class UserDetailsServiceWrapper
/*    */   implements UserDetailsService
/*    */ {
/* 31 */   private UserDetailsService userDetailsService = null;
/*    */   
/* 33 */   private RoleHierarchy roleHierarchy = null;
/*    */   
/*    */   public void setRoleHierarchy(RoleHierarchy roleHierarchy) {
/* 36 */     this.roleHierarchy = roleHierarchy;
/*    */   }
/*    */   
/*    */   public void setUserDetailsService(UserDetailsService userDetailsService) {
/* 40 */     this.userDetailsService = userDetailsService;
/*    */   }
/*    */   
/*    */   public UserDetails loadUserByUsername(String username) {
/* 44 */     UserDetails userDetails = this.userDetailsService.loadUserByUsername(username);
/*    */     
/* 46 */     return new UserDetailsWrapper(userDetails, this.roleHierarchy);
/*    */   }
/*    */   
/*    */   public UserDetailsService getWrappedUserDetailsService() {
/* 50 */     return this.userDetailsService;
/*    */   }
/*    */ }


/* Location:              C:\Users\Gcorp\Downloads\spring-security-core-3.2.0.RELEASE.jar!\org\springframework\security\access\hierarchicalroles\UserDetailsServiceWrapper.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */