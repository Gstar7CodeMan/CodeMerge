/*     */ package org.springframework.security.access.hierarchicalroles;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import java.util.regex.Matcher;
/*     */ import java.util.regex.Pattern;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.security.core.GrantedAuthority;
/*     */ import org.springframework.security.core.authority.AuthorityUtils;
/*     */ import org.springframework.security.core.authority.SimpleGrantedAuthority;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class RoleHierarchyImpl
/*     */   implements RoleHierarchy
/*     */ {
/*  67 */   private static final Log logger = LogFactory.getLog(RoleHierarchyImpl.class);
/*     */   
/*  69 */   private String roleHierarchyStringRepresentation = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  75 */   private Map<GrantedAuthority, Set<GrantedAuthority>> rolesReachableInOneStepMap = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  81 */   private Map<GrantedAuthority, Set<GrantedAuthority>> rolesReachableInOneOrMoreStepsMap = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setHierarchy(String roleHierarchyStringRepresentation) {
/*  93 */     this.roleHierarchyStringRepresentation = roleHierarchyStringRepresentation;
/*     */     
/*  95 */     logger.debug("setHierarchy() - The following role hierarchy was set: " + roleHierarchyStringRepresentation);
/*     */     
/*  97 */     buildRolesReachableInOneStepMap();
/*  98 */     buildRolesReachableInOneOrMoreStepsMap();
/*     */   }
/*     */   
/*     */   public Collection<GrantedAuthority> getReachableGrantedAuthorities(Collection<? extends GrantedAuthority> authorities) {
/* 102 */     if (authorities == null || authorities.isEmpty()) {
/* 103 */       return AuthorityUtils.NO_AUTHORITIES;
/*     */     }
/*     */     
/* 106 */     Set<GrantedAuthority> reachableRoles = new HashSet<GrantedAuthority>();
/*     */     
/* 108 */     for (GrantedAuthority authority : authorities) {
/* 109 */       addReachableRoles(reachableRoles, authority);
/* 110 */       Set<GrantedAuthority> additionalReachableRoles = getRolesReachableInOneOrMoreSteps(authority);
/* 111 */       if (additionalReachableRoles != null) {
/* 112 */         reachableRoles.addAll(additionalReachableRoles);
/*     */       }
/*     */     } 
/*     */     
/* 116 */     if (logger.isDebugEnabled()) {
/* 117 */       logger.debug("getReachableGrantedAuthorities() - From the roles " + authorities + " one can reach " + reachableRoles + " in zero or more steps.");
/*     */     }
/*     */ 
/*     */     
/* 121 */     List<GrantedAuthority> reachableRoleList = new ArrayList<GrantedAuthority>(reachableRoles.size());
/* 122 */     reachableRoleList.addAll(reachableRoles);
/*     */     
/* 124 */     return reachableRoleList;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void addReachableRoles(Set<GrantedAuthority> reachableRoles, GrantedAuthority authority) {
/* 131 */     for (GrantedAuthority testAuthority : reachableRoles) {
/* 132 */       String testKey = testAuthority.getAuthority();
/* 133 */       if (testKey != null && testKey.equals(authority.getAuthority())) {
/*     */         return;
/*     */       }
/*     */     } 
/* 137 */     reachableRoles.add(authority);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Set<GrantedAuthority> getRolesReachableInOneOrMoreSteps(GrantedAuthority authority) {
/* 144 */     if (authority.getAuthority() == null) {
/* 145 */       return null;
/*     */     }
/*     */     
/* 148 */     for (GrantedAuthority testAuthority : this.rolesReachableInOneOrMoreStepsMap.keySet()) {
/* 149 */       String testKey = testAuthority.getAuthority();
/* 150 */       if (testKey != null && testKey.equals(authority.getAuthority())) {
/* 151 */         return this.rolesReachableInOneOrMoreStepsMap.get(testAuthority);
/*     */       }
/*     */     } 
/*     */     
/* 155 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void buildRolesReachableInOneStepMap() {
/* 163 */     Pattern pattern = Pattern.compile("(\\s*([^\\s>]+)\\s*>\\s*([^\\s>]+))");
/*     */     
/* 165 */     Matcher roleHierarchyMatcher = pattern.matcher(this.roleHierarchyStringRepresentation);
/* 166 */     this.rolesReachableInOneStepMap = new HashMap<GrantedAuthority, Set<GrantedAuthority>>();
/*     */     
/* 168 */     while (roleHierarchyMatcher.find()) {
/* 169 */       Set<GrantedAuthority> rolesReachableInOneStepSet; SimpleGrantedAuthority simpleGrantedAuthority1 = new SimpleGrantedAuthority(roleHierarchyMatcher.group(2));
/* 170 */       SimpleGrantedAuthority simpleGrantedAuthority2 = new SimpleGrantedAuthority(roleHierarchyMatcher.group(3));
/*     */ 
/*     */       
/* 173 */       if (!this.rolesReachableInOneStepMap.containsKey(simpleGrantedAuthority1)) {
/* 174 */         rolesReachableInOneStepSet = new HashSet<GrantedAuthority>();
/* 175 */         this.rolesReachableInOneStepMap.put(simpleGrantedAuthority1, rolesReachableInOneStepSet);
/*     */       } else {
/* 177 */         rolesReachableInOneStepSet = this.rolesReachableInOneStepMap.get(simpleGrantedAuthority1);
/*     */       } 
/* 179 */       addReachableRoles(rolesReachableInOneStepSet, (GrantedAuthority)simpleGrantedAuthority2);
/*     */       
/* 181 */       logger.debug("buildRolesReachableInOneStepMap() - From role " + simpleGrantedAuthority1 + " one can reach role " + simpleGrantedAuthority2 + " in one step.");
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void buildRolesReachableInOneOrMoreStepsMap() {
/* 192 */     this.rolesReachableInOneOrMoreStepsMap = new HashMap<GrantedAuthority, Set<GrantedAuthority>>();
/*     */ 
/*     */     
/* 195 */     for (GrantedAuthority role : this.rolesReachableInOneStepMap.keySet()) {
/* 196 */       Set<GrantedAuthority> rolesToVisitSet = new HashSet<GrantedAuthority>();
/*     */       
/* 198 */       if (this.rolesReachableInOneStepMap.containsKey(role)) {
/* 199 */         rolesToVisitSet.addAll(this.rolesReachableInOneStepMap.get(role));
/*     */       }
/*     */       
/* 202 */       Set<GrantedAuthority> visitedRolesSet = new HashSet<GrantedAuthority>();
/*     */       
/* 204 */       while (!rolesToVisitSet.isEmpty()) {
/*     */         
/* 206 */         GrantedAuthority aRole = rolesToVisitSet.iterator().next();
/* 207 */         rolesToVisitSet.remove(aRole);
/* 208 */         addReachableRoles(visitedRolesSet, aRole);
/* 209 */         if (this.rolesReachableInOneStepMap.containsKey(aRole)) {
/* 210 */           Set<GrantedAuthority> newReachableRoles = this.rolesReachableInOneStepMap.get(aRole);
/*     */ 
/*     */           
/* 213 */           if (rolesToVisitSet.contains(role) || visitedRolesSet.contains(role)) {
/* 214 */             throw new CycleInRoleHierarchyException();
/*     */           }
/*     */           
/* 217 */           rolesToVisitSet.addAll(newReachableRoles);
/*     */         } 
/*     */       } 
/*     */       
/* 221 */       this.rolesReachableInOneOrMoreStepsMap.put(role, visitedRolesSet);
/*     */       
/* 223 */       logger.debug("buildRolesReachableInOneOrMoreStepsMap() - From role " + role + " one can reach " + visitedRolesSet + " in one or more steps.");
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\Gcorp\Downloads\spring-security-core-3.2.0.RELEASE.jar!\org\springframework\security\access\hierarchicalroles\RoleHierarchyImpl.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */