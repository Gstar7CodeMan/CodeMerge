/*    */ package org.springframework.security.access.hierarchicalroles;
/*    */ 
/*    */ import java.util.Collection;
/*    */ import org.springframework.security.core.GrantedAuthority;
/*    */ import org.springframework.security.core.authority.mapping.GrantedAuthoritiesMapper;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class RoleHierarchyAuthoritiesMapper
/*    */   implements GrantedAuthoritiesMapper
/*    */ {
/*    */   private final RoleHierarchy roleHierarchy;
/*    */   
/*    */   public RoleHierarchyAuthoritiesMapper(RoleHierarchy roleHierarchy) {
/* 15 */     this.roleHierarchy = roleHierarchy;
/*    */   }
/*    */   
/*    */   public Collection<? extends GrantedAuthority> mapAuthorities(Collection<? extends GrantedAuthority> authorities) {
/* 19 */     return this.roleHierarchy.getReachableGrantedAuthorities(authorities);
/*    */   }
/*    */ }


/* Location:              C:\Users\Gcorp\Downloads\spring-security-core-3.2.0.RELEASE.jar!\org\springframework\security\access\hierarchicalroles\RoleHierarchyAuthoritiesMapper.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */