package org.springframework.security.access.hierarchicalroles;

import java.util.Collection;
import org.springframework.security.core.GrantedAuthority;

public interface RoleHierarchy {
  Collection<? extends GrantedAuthority> getReachableGrantedAuthorities(Collection<? extends GrantedAuthority> paramCollection);
}


/* Location:              C:\Users\Gcorp\Downloads\spring-security-core-3.2.0.RELEASE.jar!\org\springframework\security\access\hierarchicalroles\RoleHierarchy.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */