/*    */ package org.springframework.security.access.hierarchicalroles;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CycleInRoleHierarchyException
/*    */   extends RuntimeException
/*    */ {
/*    */   private static final long serialVersionUID = -4970510612118296707L;
/*    */   
/*    */   public CycleInRoleHierarchyException() {
/* 27 */     super("Exception thrown because of a cycle in the role hierarchy definition!");
/*    */   }
/*    */ }


/* Location:              C:\Users\Gcorp\Downloads\spring-security-core-3.2.0.RELEASE.jar!\org\springframework\security\access\hierarchicalroles\CycleInRoleHierarchyException.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */