/*    */ package org.springframework.security.access.hierarchicalroles;
/*    */ 
/*    */ import java.util.Collection;
/*    */ import org.springframework.security.core.GrantedAuthority;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class NullRoleHierarchy
/*    */   implements RoleHierarchy
/*    */ {
/*    */   public Collection<? extends GrantedAuthority> getReachableGrantedAuthorities(Collection<? extends GrantedAuthority> authorities) {
/* 15 */     return authorities;
/*    */   }
/*    */ }


/* Location:              C:\Users\Gcorp\Downloads\spring-security-core-3.2.0.RELEASE.jar!\org\springframework\security\access\hierarchicalroles\NullRoleHierarchy.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */