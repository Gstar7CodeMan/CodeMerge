package org.springframework.security.access;

import java.util.Collection;
import org.springframework.aop.framework.AopInfrastructureBean;

public interface SecurityMetadataSource extends AopInfrastructureBean {
  Collection<ConfigAttribute> getAttributes(Object paramObject) throws IllegalArgumentException;
  
  Collection<ConfigAttribute> getAllConfigAttributes();
  
  boolean supports(Class<?> paramClass);
}


/* Location:              C:\Users\Gcorp\Downloads\spring-security-core-3.2.0.RELEASE.jar!\org\springframework\security\access\SecurityMetadataSource.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */