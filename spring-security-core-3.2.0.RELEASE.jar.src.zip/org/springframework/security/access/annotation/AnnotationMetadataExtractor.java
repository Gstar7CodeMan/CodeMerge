package org.springframework.security.access.annotation;

import java.util.Collection;
import org.springframework.security.access.ConfigAttribute;

public interface AnnotationMetadataExtractor<A extends java.lang.annotation.Annotation> {
  Collection<? extends ConfigAttribute> extractAttributes(A paramA);
}


/* Location:              C:\Users\Gcorp\Downloads\spring-security-core-3.2.0.RELEASE.jar!\org\springframework\security\access\annotation\AnnotationMetadataExtractor.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */