/*    */ package org.springframework.security.access.annotation;
/*    */ 
/*    */ import java.lang.annotation.Annotation;
/*    */ import java.util.ArrayList;
/*    */ import java.util.Collection;
/*    */ import java.util.List;
/*    */ import org.springframework.security.access.ConfigAttribute;
/*    */ import org.springframework.security.access.SecurityConfig;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class SecuredAnnotationMetadataExtractor
/*    */   implements AnnotationMetadataExtractor<Secured>
/*    */ {
/*    */   public Collection<ConfigAttribute> extractAttributes(Secured secured) {
/* 81 */     String[] attributeTokens = secured.value();
/* 82 */     List<ConfigAttribute> attributes = new ArrayList<ConfigAttribute>(attributeTokens.length);
/*    */     
/* 84 */     for (String token : attributeTokens) {
/* 85 */       attributes.add(new SecurityConfig(token));
/*    */     }
/*    */     
/* 88 */     return attributes;
/*    */   }
/*    */ }


/* Location:              C:\Users\Gcorp\Downloads\spring-security-core-3.2.0.RELEASE.jar!\org\springframework\security\access\annotation\SecuredAnnotationMetadataExtractor.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */