/*    */ package org.springframework.security.access.annotation;
/*    */ 
/*    */ import javax.annotation.security.DenyAll;
/*    */ import javax.annotation.security.PermitAll;
/*    */ import org.springframework.security.access.SecurityConfig;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Jsr250SecurityConfig
/*    */   extends SecurityConfig
/*    */ {
/* 15 */   public static final Jsr250SecurityConfig PERMIT_ALL_ATTRIBUTE = new Jsr250SecurityConfig(PermitAll.class.getName());
/* 16 */   public static final Jsr250SecurityConfig DENY_ALL_ATTRIBUTE = new Jsr250SecurityConfig(DenyAll.class.getName());
/*    */   
/*    */   public Jsr250SecurityConfig(String role) {
/* 19 */     super(role);
/*    */   }
/*    */ }


/* Location:              C:\Users\Gcorp\Downloads\spring-security-core-3.2.0.RELEASE.jar!\org\springframework\security\access\annotation\Jsr250SecurityConfig.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */