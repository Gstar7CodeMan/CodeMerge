/*    */ package org.springframework.security.access.annotation;
/*    */ 
/*    */ import java.lang.annotation.Annotation;
/*    */ import java.lang.reflect.Method;
/*    */ import java.util.ArrayList;
/*    */ import java.util.Collection;
/*    */ import java.util.List;
/*    */ import javax.annotation.security.RolesAllowed;
/*    */ import org.springframework.core.annotation.AnnotationUtils;
/*    */ import org.springframework.security.access.ConfigAttribute;
/*    */ import org.springframework.security.access.method.AbstractFallbackMethodSecurityMetadataSource;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Jsr250MethodSecurityMetadataSource
/*    */   extends AbstractFallbackMethodSecurityMetadataSource
/*    */ {
/*    */   protected Collection<ConfigAttribute> findAttributes(Class<?> clazz) {
/* 42 */     return processAnnotations(clazz.getAnnotations());
/*    */   }
/*    */   
/*    */   protected Collection<ConfigAttribute> findAttributes(Method method, Class<?> targetClass) {
/* 46 */     return processAnnotations(AnnotationUtils.getAnnotations(method));
/*    */   }
/*    */   
/*    */   public Collection<ConfigAttribute> getAllConfigAttributes() {
/* 50 */     return null;
/*    */   }
/*    */   
/*    */   private List<ConfigAttribute> processAnnotations(Annotation[] annotations) {
/* 54 */     if (annotations == null || annotations.length == 0) {
/* 55 */       return null;
/*    */     }
/* 57 */     List<ConfigAttribute> attributes = new ArrayList<ConfigAttribute>();
/*    */     
/* 59 */     for (Annotation a : annotations) {
/* 60 */       if (a instanceof javax.annotation.security.DenyAll) {
/* 61 */         attributes.add(Jsr250SecurityConfig.DENY_ALL_ATTRIBUTE);
/* 62 */         return attributes;
/*    */       } 
/* 64 */       if (a instanceof javax.annotation.security.PermitAll) {
/* 65 */         attributes.add(Jsr250SecurityConfig.PERMIT_ALL_ATTRIBUTE);
/* 66 */         return attributes;
/*    */       } 
/* 68 */       if (a instanceof RolesAllowed) {
/* 69 */         RolesAllowed ra = (RolesAllowed)a;
/*    */         
/* 71 */         for (String allowed : ra.value()) {
/* 72 */           attributes.add(new Jsr250SecurityConfig(allowed));
/*    */         }
/* 74 */         return attributes;
/*    */       } 
/*    */     } 
/* 77 */     return null;
/*    */   }
/*    */ }


/* Location:              C:\Users\Gcorp\Downloads\spring-security-core-3.2.0.RELEASE.jar!\org\springframework\security\access\annotation\Jsr250MethodSecurityMetadataSource.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */