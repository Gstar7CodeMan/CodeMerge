/*    */ package org.springframework.security.access.annotation;
/*    */ 
/*    */ import java.lang.annotation.Annotation;
/*    */ import java.lang.reflect.Method;
/*    */ import java.util.Collection;
/*    */ import org.springframework.core.GenericTypeResolver;
/*    */ import org.springframework.core.annotation.AnnotationUtils;
/*    */ import org.springframework.security.access.ConfigAttribute;
/*    */ import org.springframework.security.access.method.AbstractFallbackMethodSecurityMetadataSource;
/*    */ import org.springframework.util.Assert;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SecuredAnnotationSecurityMetadataSource
/*    */   extends AbstractFallbackMethodSecurityMetadataSource
/*    */ {
/*    */   private AnnotationMetadataExtractor annotationExtractor;
/*    */   private Class<? extends Annotation> annotationType;
/*    */   
/*    */   public SecuredAnnotationSecurityMetadataSource() {
/* 45 */     this(new SecuredAnnotationMetadataExtractor());
/*    */   }
/*    */   
/*    */   public SecuredAnnotationSecurityMetadataSource(AnnotationMetadataExtractor annotationMetadataExtractor) {
/* 49 */     Assert.notNull(annotationMetadataExtractor);
/* 50 */     this.annotationExtractor = annotationMetadataExtractor;
/* 51 */     this.annotationType = GenericTypeResolver.resolveTypeArgument(this.annotationExtractor.getClass(), AnnotationMetadataExtractor.class);
/*    */     
/* 53 */     Assert.notNull(this.annotationType, this.annotationExtractor.getClass().getName() + " must supply a generic parameter for AnnotationMetadataExtractor");
/*    */   }
/*    */ 
/*    */   
/*    */   protected Collection<ConfigAttribute> findAttributes(Class<?> clazz) {
/* 58 */     return processAnnotation(AnnotationUtils.findAnnotation(clazz, this.annotationType));
/*    */   }
/*    */   
/*    */   protected Collection<ConfigAttribute> findAttributes(Method method, Class<?> targetClass) {
/* 62 */     return processAnnotation(AnnotationUtils.findAnnotation(method, this.annotationType));
/*    */   }
/*    */   
/*    */   public Collection<ConfigAttribute> getAllConfigAttributes() {
/* 66 */     return null;
/*    */   }
/*    */   
/*    */   private Collection<ConfigAttribute> processAnnotation(Annotation a) {
/* 70 */     if (a == null) {
/* 71 */       return null;
/*    */     }
/*    */     
/* 74 */     return (Collection)this.annotationExtractor.extractAttributes(a);
/*    */   }
/*    */ }


/* Location:              C:\Users\Gcorp\Downloads\spring-security-core-3.2.0.RELEASE.jar!\org\springframework\security\access\annotation\SecuredAnnotationSecurityMetadataSource.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */