/*    */ package org.springframework.security.access.annotation;
/*    */ 
/*    */ import java.util.Collection;
/*    */ import org.springframework.security.access.AccessDecisionVoter;
/*    */ import org.springframework.security.access.ConfigAttribute;
/*    */ import org.springframework.security.core.Authentication;
/*    */ import org.springframework.security.core.GrantedAuthority;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Jsr250Voter
/*    */   implements AccessDecisionVoter<Object>
/*    */ {
/*    */   public boolean supports(ConfigAttribute configAttribute) {
/* 25 */     return configAttribute instanceof Jsr250SecurityConfig;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean supports(Class<?> clazz) {
/* 35 */     return true;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public int vote(Authentication authentication, Object object, Collection<ConfigAttribute> definition) {
/* 50 */     boolean jsr250AttributeFound = false;
/*    */     
/* 52 */     for (ConfigAttribute attribute : definition) {
/* 53 */       if (Jsr250SecurityConfig.PERMIT_ALL_ATTRIBUTE.equals(attribute)) {
/* 54 */         return 1;
/*    */       }
/*    */       
/* 57 */       if (Jsr250SecurityConfig.DENY_ALL_ATTRIBUTE.equals(attribute)) {
/* 58 */         return -1;
/*    */       }
/*    */       
/* 61 */       if (supports(attribute)) {
/* 62 */         jsr250AttributeFound = true;
/*    */         
/* 64 */         for (GrantedAuthority authority : authentication.getAuthorities()) {
/* 65 */           if (attribute.getAttribute().equals(authority.getAuthority())) {
/* 66 */             return 1;
/*    */           }
/*    */         } 
/*    */       } 
/*    */     } 
/*    */     
/* 72 */     return jsr250AttributeFound ? -1 : 0;
/*    */   }
/*    */ }


/* Location:              C:\Users\Gcorp\Downloads\spring-security-core-3.2.0.RELEASE.jar!\org\springframework\security\access\annotation\Jsr250Voter.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */