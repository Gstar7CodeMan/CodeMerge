/*    */ package org.springframework.security.access.vote;
/*    */ 
/*    */ import org.aopalliance.intercept.MethodInvocation;
/*    */ import org.springframework.security.access.AccessDecisionVoter;
/*    */ import org.springframework.security.access.AuthorizationServiceException;
/*    */ import org.springframework.util.Assert;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class AbstractAclVoter
/*    */   implements AccessDecisionVoter<MethodInvocation>
/*    */ {
/*    */   private Class<?> processDomainObjectClass;
/*    */   
/*    */   protected Object getDomainObjectInstance(MethodInvocation invocation) {
/* 40 */     Class<?>[] params = invocation.getMethod().getParameterTypes();
/* 41 */     Object[] args = invocation.getArguments();
/*    */     
/* 43 */     for (int i = 0; i < params.length; i++) {
/* 44 */       if (this.processDomainObjectClass.isAssignableFrom(params[i])) {
/* 45 */         return args[i];
/*    */       }
/*    */     } 
/*    */     
/* 49 */     throw new AuthorizationServiceException("MethodInvocation: " + invocation + " did not provide any argument of type: " + this.processDomainObjectClass);
/*    */   }
/*    */ 
/*    */   
/*    */   public Class<?> getProcessDomainObjectClass() {
/* 54 */     return this.processDomainObjectClass;
/*    */   }
/*    */   
/*    */   public void setProcessDomainObjectClass(Class<?> processDomainObjectClass) {
/* 58 */     Assert.notNull(processDomainObjectClass, "processDomainObjectClass cannot be set to null");
/* 59 */     this.processDomainObjectClass = processDomainObjectClass;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean supports(Class<?> clazz) {
/* 71 */     return MethodInvocation.class.isAssignableFrom(clazz);
/*    */   }
/*    */ }


/* Location:              C:\Users\Gcorp\Downloads\spring-security-core-3.2.0.RELEASE.jar!\org\springframework\security\access\vote\AbstractAclVoter.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */