/*     */ package org.springframework.security.access.vote;
/*     */ 
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.beans.factory.InitializingBean;
/*     */ import org.springframework.context.MessageSource;
/*     */ import org.springframework.context.MessageSourceAware;
/*     */ import org.springframework.context.support.MessageSourceAccessor;
/*     */ import org.springframework.security.access.AccessDecisionManager;
/*     */ import org.springframework.security.access.AccessDecisionVoter;
/*     */ import org.springframework.security.access.AccessDeniedException;
/*     */ import org.springframework.security.access.ConfigAttribute;
/*     */ import org.springframework.security.core.SpringSecurityMessageSource;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AbstractAccessDecisionManager
/*     */   implements AccessDecisionManager, InitializingBean, MessageSourceAware
/*     */ {
/*  45 */   protected final Log logger = LogFactory.getLog(getClass());
/*     */   
/*     */   private List<AccessDecisionVoter> decisionVoters;
/*     */   
/*  49 */   protected MessageSourceAccessor messages = SpringSecurityMessageSource.getAccessor();
/*     */   
/*     */   private boolean allowIfAllAbstainDecisions = false;
/*     */ 
/*     */   
/*     */   protected AbstractAccessDecisionManager() {}
/*     */   
/*     */   protected AbstractAccessDecisionManager(List<AccessDecisionVoter> decisionVoters) {
/*  57 */     Assert.notEmpty(decisionVoters, "A list of AccessDecisionVoters is required");
/*  58 */     this.decisionVoters = decisionVoters;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void afterPropertiesSet() throws Exception {
/*  64 */     Assert.notEmpty(this.decisionVoters, "A list of AccessDecisionVoters is required");
/*  65 */     Assert.notNull(this.messages, "A message source must be set");
/*     */   }
/*     */   
/*     */   protected final void checkAllowIfAllAbstainDecisions() {
/*  69 */     if (!isAllowIfAllAbstainDecisions()) {
/*  70 */       throw new AccessDeniedException(this.messages.getMessage("AbstractAccessDecisionManager.accessDenied", "Access is denied"));
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public List<AccessDecisionVoter> getDecisionVoters() {
/*  76 */     return this.decisionVoters;
/*     */   }
/*     */   
/*     */   public boolean isAllowIfAllAbstainDecisions() {
/*  80 */     return this.allowIfAllAbstainDecisions;
/*     */   }
/*     */   
/*     */   public void setAllowIfAllAbstainDecisions(boolean allowIfAllAbstainDecisions) {
/*  84 */     this.allowIfAllAbstainDecisions = allowIfAllAbstainDecisions;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public void setDecisionVoters(List<AccessDecisionVoter> newList) {
/*  92 */     Assert.notEmpty(newList);
/*     */     
/*  94 */     Iterator<AccessDecisionVoter> iter = newList.iterator();
/*     */     
/*  96 */     while (iter.hasNext()) {
/*  97 */       Object currentObject = iter.next();
/*  98 */       Assert.isInstanceOf(AccessDecisionVoter.class, currentObject, "AccessDecisionVoter " + currentObject.getClass().getName() + " must implement AccessDecisionVoter");
/*     */     } 
/*     */ 
/*     */     
/* 102 */     this.decisionVoters = newList;
/*     */   }
/*     */   
/*     */   public void setMessageSource(MessageSource messageSource) {
/* 106 */     this.messages = new MessageSourceAccessor(messageSource);
/*     */   }
/*     */   
/*     */   public boolean supports(ConfigAttribute attribute) {
/* 110 */     for (AccessDecisionVoter voter : this.decisionVoters) {
/* 111 */       if (voter.supports(attribute)) {
/* 112 */         return true;
/*     */       }
/*     */     } 
/*     */     
/* 116 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean supports(Class<?> clazz) {
/* 129 */     for (AccessDecisionVoter voter : this.decisionVoters) {
/* 130 */       if (!voter.supports(clazz)) {
/* 131 */         return false;
/*     */       }
/*     */     } 
/*     */     
/* 135 */     return true;
/*     */   }
/*     */ }


/* Location:              C:\Users\Gcorp\Downloads\spring-security-core-3.2.0.RELEASE.jar!\org\springframework\security\access\vote\AbstractAccessDecisionManager.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */