/*     */ package org.springframework.security.access.vote;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.List;
/*     */ import org.springframework.security.access.AccessDecisionVoter;
/*     */ import org.springframework.security.access.AccessDeniedException;
/*     */ import org.springframework.security.access.ConfigAttribute;
/*     */ import org.springframework.security.core.Authentication;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class UnanimousBased
/*     */   extends AbstractAccessDecisionManager
/*     */ {
/*     */   @Deprecated
/*     */   public UnanimousBased() {}
/*     */   
/*     */   public UnanimousBased(List<AccessDecisionVoter> decisionVoters) {
/*  42 */     super(decisionVoters);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void decide(Authentication authentication, Object object, Collection<ConfigAttribute> attributes) throws AccessDeniedException {
/*  67 */     int grant = 0;
/*  68 */     int abstain = 0;
/*     */     
/*  70 */     List<ConfigAttribute> singleAttributeList = new ArrayList<ConfigAttribute>(1);
/*  71 */     singleAttributeList.add(null);
/*     */     
/*  73 */     for (ConfigAttribute attribute : attributes) {
/*  74 */       singleAttributeList.set(0, attribute);
/*     */       
/*  76 */       for (AccessDecisionVoter voter : getDecisionVoters()) {
/*  77 */         int result = voter.vote(authentication, object, singleAttributeList);
/*     */         
/*  79 */         if (this.logger.isDebugEnabled()) {
/*  80 */           this.logger.debug("Voter: " + voter + ", returned: " + result);
/*     */         }
/*     */         
/*  83 */         switch (result) {
/*     */           case 1:
/*  85 */             grant++;
/*     */             continue;
/*     */ 
/*     */           
/*     */           case -1:
/*  90 */             throw new AccessDeniedException(this.messages.getMessage("AbstractAccessDecisionManager.accessDenied", "Access is denied"));
/*     */         } 
/*     */ 
/*     */         
/*  94 */         abstain++;
/*     */       } 
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 102 */     if (grant > 0) {
/*     */       return;
/*     */     }
/*     */ 
/*     */     
/* 107 */     checkAllowIfAllAbstainDecisions();
/*     */   }
/*     */ }


/* Location:              C:\Users\Gcorp\Downloads\spring-security-core-3.2.0.RELEASE.jar!\org\springframework\security\access\vote\UnanimousBased.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */