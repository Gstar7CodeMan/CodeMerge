/*     */ package org.springframework.security.access.vote;
/*     */ 
/*     */ import java.util.Collection;
/*     */ import java.util.List;
/*     */ import org.springframework.security.access.AccessDecisionVoter;
/*     */ import org.springframework.security.access.AccessDeniedException;
/*     */ import org.springframework.security.access.ConfigAttribute;
/*     */ import org.springframework.security.core.Authentication;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ConsensusBased
/*     */   extends AbstractAccessDecisionManager
/*     */ {
/*     */   private boolean allowIfEqualGrantedDeniedDecisions = true;
/*     */   
/*     */   @Deprecated
/*     */   public ConsensusBased() {}
/*     */   
/*     */   public ConsensusBased(List<AccessDecisionVoter> decisionVoters) {
/*  45 */     super(decisionVoters);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void decide(Authentication authentication, Object object, Collection<ConfigAttribute> configAttributes) throws AccessDeniedException {
/*  68 */     int grant = 0;
/*  69 */     int deny = 0;
/*  70 */     int abstain = 0;
/*     */     
/*  72 */     for (AccessDecisionVoter voter : getDecisionVoters()) {
/*  73 */       int result = voter.vote(authentication, object, configAttributes);
/*     */       
/*  75 */       if (this.logger.isDebugEnabled()) {
/*  76 */         this.logger.debug("Voter: " + voter + ", returned: " + result);
/*     */       }
/*     */       
/*  79 */       switch (result) {
/*     */         case 1:
/*  81 */           grant++;
/*     */           continue;
/*     */ 
/*     */         
/*     */         case -1:
/*  86 */           deny++;
/*     */           continue;
/*     */       } 
/*     */ 
/*     */       
/*  91 */       abstain++;
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  97 */     if (grant > deny) {
/*     */       return;
/*     */     }
/*     */     
/* 101 */     if (deny > grant) {
/* 102 */       throw new AccessDeniedException(this.messages.getMessage("AbstractAccessDecisionManager.accessDenied", "Access is denied"));
/*     */     }
/*     */ 
/*     */     
/* 106 */     if (grant == deny && grant != 0) {
/* 107 */       if (this.allowIfEqualGrantedDeniedDecisions) {
/*     */         return;
/*     */       }
/* 110 */       throw new AccessDeniedException(this.messages.getMessage("AbstractAccessDecisionManager.accessDenied", "Access is denied"));
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 116 */     checkAllowIfAllAbstainDecisions();
/*     */   }
/*     */   
/*     */   public boolean isAllowIfEqualGrantedDeniedDecisions() {
/* 120 */     return this.allowIfEqualGrantedDeniedDecisions;
/*     */   }
/*     */   
/*     */   public void setAllowIfEqualGrantedDeniedDecisions(boolean allowIfEqualGrantedDeniedDecisions) {
/* 124 */     this.allowIfEqualGrantedDeniedDecisions = allowIfEqualGrantedDeniedDecisions;
/*     */   }
/*     */ }


/* Location:              C:\Users\Gcorp\Downloads\spring-security-core-3.2.0.RELEASE.jar!\org\springframework\security\access\vote\ConsensusBased.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */