/*    */ package org.springframework.security.access.vote;
/*    */ 
/*    */ import java.util.Collection;
/*    */ import org.springframework.security.access.hierarchicalroles.RoleHierarchy;
/*    */ import org.springframework.security.core.Authentication;
/*    */ import org.springframework.security.core.GrantedAuthority;
/*    */ import org.springframework.util.Assert;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class RoleHierarchyVoter
/*    */   extends RoleVoter
/*    */ {
/* 18 */   private RoleHierarchy roleHierarchy = null;
/*    */   
/*    */   public RoleHierarchyVoter(RoleHierarchy roleHierarchy) {
/* 21 */     Assert.notNull(roleHierarchy, "RoleHierarchy must not be null");
/* 22 */     this.roleHierarchy = roleHierarchy;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   Collection<? extends GrantedAuthority> extractAuthorities(Authentication authentication) {
/* 30 */     return this.roleHierarchy.getReachableGrantedAuthorities(authentication.getAuthorities());
/*    */   }
/*    */ }


/* Location:              C:\Users\Gcorp\Downloads\spring-security-core-3.2.0.RELEASE.jar!\org\springframework\security\access\vote\RoleHierarchyVoter.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */