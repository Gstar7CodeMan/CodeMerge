/*     */ package org.springframework.security.access.vote;
/*     */ 
/*     */ import java.util.Collection;
/*     */ import org.springframework.security.access.AccessDecisionVoter;
/*     */ import org.springframework.security.access.ConfigAttribute;
/*     */ import org.springframework.security.core.Authentication;
/*     */ import org.springframework.security.core.GrantedAuthority;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class RoleVoter
/*     */   implements AccessDecisionVoter<Object>
/*     */ {
/*  55 */   private String rolePrefix = "ROLE_";
/*     */ 
/*     */ 
/*     */   
/*     */   public String getRolePrefix() {
/*  60 */     return this.rolePrefix;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setRolePrefix(String rolePrefix) {
/*  70 */     this.rolePrefix = rolePrefix;
/*     */   }
/*     */   
/*     */   public boolean supports(ConfigAttribute attribute) {
/*  74 */     if (attribute.getAttribute() != null && attribute.getAttribute().startsWith(getRolePrefix())) {
/*  75 */       return true;
/*     */     }
/*     */     
/*  78 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean supports(Class<?> clazz) {
/*  91 */     return true;
/*     */   }
/*     */   
/*     */   public int vote(Authentication authentication, Object object, Collection<ConfigAttribute> attributes) {
/*  95 */     int result = 0;
/*  96 */     Collection<? extends GrantedAuthority> authorities = extractAuthorities(authentication);
/*     */     
/*  98 */     for (ConfigAttribute attribute : attributes) {
/*  99 */       if (supports(attribute)) {
/* 100 */         result = -1;
/*     */ 
/*     */         
/* 103 */         for (GrantedAuthority authority : authorities) {
/* 104 */           if (attribute.getAttribute().equals(authority.getAuthority())) {
/* 105 */             return 1;
/*     */           }
/*     */         } 
/*     */       } 
/*     */     } 
/*     */     
/* 111 */     return result;
/*     */   }
/*     */   
/*     */   Collection<? extends GrantedAuthority> extractAuthorities(Authentication authentication) {
/* 115 */     return authentication.getAuthorities();
/*     */   }
/*     */ }


/* Location:              C:\Users\Gcorp\Downloads\spring-security-core-3.2.0.RELEASE.jar!\org\springframework\security\access\vote\RoleVoter.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */