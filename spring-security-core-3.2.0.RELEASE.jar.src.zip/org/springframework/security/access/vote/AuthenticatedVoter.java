/*     */ package org.springframework.security.access.vote;
/*     */ 
/*     */ import java.util.Collection;
/*     */ import org.springframework.security.access.AccessDecisionVoter;
/*     */ import org.springframework.security.access.ConfigAttribute;
/*     */ import org.springframework.security.authentication.AuthenticationTrustResolver;
/*     */ import org.springframework.security.authentication.AuthenticationTrustResolverImpl;
/*     */ import org.springframework.security.core.Authentication;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class AuthenticatedVoter
/*     */   implements AccessDecisionVoter<Object>
/*     */ {
/*     */   public static final String IS_AUTHENTICATED_FULLY = "IS_AUTHENTICATED_FULLY";
/*     */   public static final String IS_AUTHENTICATED_REMEMBERED = "IS_AUTHENTICATED_REMEMBERED";
/*     */   public static final String IS_AUTHENTICATED_ANONYMOUSLY = "IS_AUTHENTICATED_ANONYMOUSLY";
/*  52 */   private AuthenticationTrustResolver authenticationTrustResolver = (AuthenticationTrustResolver)new AuthenticationTrustResolverImpl();
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean isFullyAuthenticated(Authentication authentication) {
/*  57 */     return (!this.authenticationTrustResolver.isAnonymous(authentication) && !this.authenticationTrustResolver.isRememberMe(authentication));
/*     */   }
/*     */ 
/*     */   
/*     */   public void setAuthenticationTrustResolver(AuthenticationTrustResolver authenticationTrustResolver) {
/*  62 */     Assert.notNull(authenticationTrustResolver, "AuthenticationTrustResolver cannot be set to null");
/*  63 */     this.authenticationTrustResolver = authenticationTrustResolver;
/*     */   }
/*     */   
/*     */   public boolean supports(ConfigAttribute attribute) {
/*  67 */     if (attribute.getAttribute() != null && ("IS_AUTHENTICATED_FULLY".equals(attribute.getAttribute()) || "IS_AUTHENTICATED_REMEMBERED".equals(attribute.getAttribute()) || "IS_AUTHENTICATED_ANONYMOUSLY".equals(attribute.getAttribute())))
/*     */     {
/*     */ 
/*     */       
/*  71 */       return true;
/*     */     }
/*  73 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean supports(Class<?> clazz) {
/*  85 */     return true;
/*     */   }
/*     */   
/*     */   public int vote(Authentication authentication, Object object, Collection<ConfigAttribute> attributes) {
/*  89 */     int result = 0;
/*     */     
/*  91 */     for (ConfigAttribute attribute : attributes) {
/*  92 */       if (supports(attribute)) {
/*  93 */         result = -1;
/*     */         
/*  95 */         if ("IS_AUTHENTICATED_FULLY".equals(attribute.getAttribute()) && 
/*  96 */           isFullyAuthenticated(authentication)) {
/*  97 */           return 1;
/*     */         }
/*     */ 
/*     */         
/* 101 */         if ("IS_AUTHENTICATED_REMEMBERED".equals(attribute.getAttribute()) && (
/* 102 */           this.authenticationTrustResolver.isRememberMe(authentication) || isFullyAuthenticated(authentication)))
/*     */         {
/* 104 */           return 1;
/*     */         }
/*     */ 
/*     */         
/* 108 */         if ("IS_AUTHENTICATED_ANONYMOUSLY".equals(attribute.getAttribute()) && (
/* 109 */           this.authenticationTrustResolver.isAnonymous(authentication) || isFullyAuthenticated(authentication) || this.authenticationTrustResolver.isRememberMe(authentication)))
/*     */         {
/* 111 */           return 1;
/*     */         }
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 117 */     return result;
/*     */   }
/*     */ }


/* Location:              C:\Users\Gcorp\Downloads\spring-security-core-3.2.0.RELEASE.jar!\org\springframework\security\access\vote\AuthenticatedVoter.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */