/*    */ package org.springframework.security.access.vote;
/*    */ 
/*    */ import java.util.Collection;
/*    */ import java.util.List;
/*    */ import org.springframework.security.access.AccessDecisionVoter;
/*    */ import org.springframework.security.access.AccessDeniedException;
/*    */ import org.springframework.security.access.ConfigAttribute;
/*    */ import org.springframework.security.core.Authentication;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class AffirmativeBased
/*    */   extends AbstractAccessDecisionManager
/*    */ {
/*    */   @Deprecated
/*    */   public AffirmativeBased() {}
/*    */   
/*    */   public AffirmativeBased(List<AccessDecisionVoter> decisionVoters) {
/* 40 */     super(decisionVoters);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void decide(Authentication authentication, Object object, Collection<ConfigAttribute> configAttributes) throws AccessDeniedException {
/* 59 */     int deny = 0;
/*    */     
/* 61 */     for (AccessDecisionVoter voter : getDecisionVoters()) {
/* 62 */       int result = voter.vote(authentication, object, configAttributes);
/*    */       
/* 64 */       if (this.logger.isDebugEnabled()) {
/* 65 */         this.logger.debug("Voter: " + voter + ", returned: " + result);
/*    */       }
/*    */       
/* 68 */       switch (result) {
/*    */         case 1:
/*    */           return;
/*    */         
/*    */         case -1:
/* 73 */           deny++;
/*    */       } 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */     
/*    */     } 
/* 82 */     if (deny > 0) {
/* 83 */       throw new AccessDeniedException(this.messages.getMessage("AbstractAccessDecisionManager.accessDenied", "Access is denied"));
/*    */     }
/*    */ 
/*    */ 
/*    */     
/* 88 */     checkAllowIfAllAbstainDecisions();
/*    */   }
/*    */ }


/* Location:              C:\Users\Gcorp\Downloads\spring-security-core-3.2.0.RELEASE.jar!\org\springframework\security\access\vote\AffirmativeBased.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */