package org.springframework.security.access;

import java.io.Serializable;

public interface ConfigAttribute extends Serializable {
  String getAttribute();
}


/* Location:              C:\Users\Gcorp\Downloads\spring-security-core-3.2.0.RELEASE.jar!\org\springframework\security\access\ConfigAttribute.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */