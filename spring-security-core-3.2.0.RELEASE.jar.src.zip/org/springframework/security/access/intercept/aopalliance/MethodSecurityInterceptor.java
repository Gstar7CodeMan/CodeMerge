/*    */ package org.springframework.security.access.intercept.aopalliance;
/*    */ 
/*    */ import org.aopalliance.intercept.MethodInterceptor;
/*    */ import org.aopalliance.intercept.MethodInvocation;
/*    */ import org.springframework.security.access.SecurityMetadataSource;
/*    */ import org.springframework.security.access.intercept.AbstractSecurityInterceptor;
/*    */ import org.springframework.security.access.intercept.InterceptorStatusToken;
/*    */ import org.springframework.security.access.method.MethodSecurityMetadataSource;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MethodSecurityInterceptor
/*    */   extends AbstractSecurityInterceptor
/*    */   implements MethodInterceptor
/*    */ {
/*    */   private MethodSecurityMetadataSource securityMetadataSource;
/*    */   
/*    */   public Class<?> getSecureObjectClass() {
/* 47 */     return MethodInvocation.class;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Object invoke(MethodInvocation mi) throws Throwable {
/*    */     Object result;
/* 60 */     InterceptorStatusToken token = beforeInvocation(mi);
/*    */ 
/*    */     
/*    */     try {
/* 64 */       result = mi.proceed();
/*    */     } finally {
/* 66 */       finallyInvocation(token);
/*    */     } 
/* 68 */     return afterInvocation(token, result);
/*    */   }
/*    */   
/*    */   public MethodSecurityMetadataSource getSecurityMetadataSource() {
/* 72 */     return this.securityMetadataSource;
/*    */   }
/*    */   
/*    */   public SecurityMetadataSource obtainSecurityMetadataSource() {
/* 76 */     return (SecurityMetadataSource)this.securityMetadataSource;
/*    */   }
/*    */   
/*    */   public void setSecurityMetadataSource(MethodSecurityMetadataSource newSource) {
/* 80 */     this.securityMetadataSource = newSource;
/*    */   }
/*    */ }


/* Location:              C:\Users\Gcorp\Downloads\spring-security-core-3.2.0.RELEASE.jar!\org\springframework\security\access\intercept\aopalliance\MethodSecurityInterceptor.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */