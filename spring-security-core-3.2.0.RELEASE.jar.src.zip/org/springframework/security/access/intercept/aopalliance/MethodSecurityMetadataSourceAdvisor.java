/*     */ package org.springframework.security.access.intercept.aopalliance;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.ObjectInputStream;
/*     */ import java.io.Serializable;
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.Collection;
/*     */ import org.aopalliance.aop.Advice;
/*     */ import org.springframework.aop.Pointcut;
/*     */ import org.springframework.aop.support.AbstractPointcutAdvisor;
/*     */ import org.springframework.aop.support.StaticMethodMatcherPointcut;
/*     */ import org.springframework.beans.BeansException;
/*     */ import org.springframework.beans.factory.BeanFactory;
/*     */ import org.springframework.beans.factory.BeanFactoryAware;
/*     */ import org.springframework.security.access.method.MethodSecurityMetadataSource;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MethodSecurityMetadataSourceAdvisor
/*     */   extends AbstractPointcutAdvisor
/*     */   implements BeanFactoryAware
/*     */ {
/*     */   private transient MethodSecurityMetadataSource attributeSource;
/*     */   private transient MethodSecurityInterceptor interceptor;
/*  56 */   private final Pointcut pointcut = (Pointcut)new MethodSecurityMetadataSourcePointcut();
/*     */   private BeanFactory beanFactory;
/*     */   private final String adviceBeanName;
/*     */   private final String metadataSourceBeanName;
/*  60 */   private volatile transient Object adviceMonitor = new Object();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MethodSecurityMetadataSourceAdvisor(String adviceBeanName, MethodSecurityMetadataSource attributeSource, String attributeSourceBeanName) {
/*  76 */     Assert.notNull(adviceBeanName, "The adviceBeanName cannot be null");
/*  77 */     Assert.notNull(attributeSource, "The attributeSource cannot be null");
/*  78 */     Assert.notNull(attributeSourceBeanName, "The attributeSourceBeanName cannot be null");
/*     */     
/*  80 */     this.adviceBeanName = adviceBeanName;
/*  81 */     this.attributeSource = attributeSource;
/*  82 */     this.metadataSourceBeanName = attributeSourceBeanName;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Pointcut getPointcut() {
/*  88 */     return this.pointcut;
/*     */   }
/*     */   
/*     */   public Advice getAdvice() {
/*  92 */     synchronized (this.adviceMonitor) {
/*  93 */       if (this.interceptor == null) {
/*  94 */         Assert.notNull(this.adviceBeanName, "'adviceBeanName' must be set for use with bean factory lookup.");
/*  95 */         Assert.state((this.beanFactory != null), "BeanFactory must be set to resolve 'adviceBeanName'");
/*  96 */         this.interceptor = (MethodSecurityInterceptor)this.beanFactory.getBean(this.adviceBeanName, MethodSecurityInterceptor.class);
/*     */       } 
/*  98 */       return (Advice)this.interceptor;
/*     */     } 
/*     */   }
/*     */   
/*     */   public void setBeanFactory(BeanFactory beanFactory) throws BeansException {
/* 103 */     this.beanFactory = beanFactory;
/*     */   }
/*     */   
/*     */   private void readObject(ObjectInputStream ois) throws IOException, ClassNotFoundException {
/* 107 */     ois.defaultReadObject();
/* 108 */     this.adviceMonitor = new Object();
/* 109 */     this.attributeSource = (MethodSecurityMetadataSource)this.beanFactory.getBean(this.metadataSourceBeanName, MethodSecurityMetadataSource.class);
/*     */   }
/*     */   
/*     */   class MethodSecurityMetadataSourcePointcut
/*     */     extends StaticMethodMatcherPointcut
/*     */     implements Serializable
/*     */   {
/*     */     public boolean matches(Method m, Class targetClass) {
/* 117 */       Collection attributes = MethodSecurityMetadataSourceAdvisor.this.attributeSource.getAttributes(m, targetClass);
/* 118 */       return (attributes != null && !attributes.isEmpty());
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Gcorp\Downloads\spring-security-core-3.2.0.RELEASE.jar!\org\springframework\security\access\intercept\aopalliance\MethodSecurityMetadataSourceAdvisor.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */