/*     */ package org.springframework.security.access.intercept;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.List;
/*     */ import org.springframework.beans.factory.InitializingBean;
/*     */ import org.springframework.security.access.ConfigAttribute;
/*     */ import org.springframework.security.core.Authentication;
/*     */ import org.springframework.security.core.GrantedAuthority;
/*     */ import org.springframework.security.core.authority.SimpleGrantedAuthority;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class RunAsManagerImpl
/*     */   implements RunAsManager, InitializingBean
/*     */ {
/*     */   private String key;
/*  56 */   private String rolePrefix = "ROLE_";
/*     */ 
/*     */ 
/*     */   
/*     */   public void afterPropertiesSet() throws Exception {
/*  61 */     Assert.notNull(this.key, "A Key is required and should match that configured for the RunAsImplAuthenticationProvider");
/*     */   }
/*     */   
/*     */   public Authentication buildRunAs(Authentication authentication, Object object, Collection<ConfigAttribute> attributes) {
/*  65 */     List<GrantedAuthority> newAuthorities = new ArrayList<GrantedAuthority>();
/*     */     
/*  67 */     for (ConfigAttribute attribute : attributes) {
/*  68 */       if (supports(attribute)) {
/*  69 */         SimpleGrantedAuthority simpleGrantedAuthority = new SimpleGrantedAuthority(getRolePrefix() + attribute.getAttribute());
/*  70 */         newAuthorities.add(simpleGrantedAuthority);
/*     */       } 
/*     */     } 
/*     */     
/*  74 */     if (newAuthorities.size() == 0) {
/*  75 */       return null;
/*     */     }
/*     */ 
/*     */     
/*  79 */     newAuthorities.addAll(authentication.getAuthorities());
/*     */     
/*  81 */     return (Authentication)new RunAsUserToken(this.key, authentication.getPrincipal(), authentication.getCredentials(), newAuthorities, (Class)authentication.getClass());
/*     */   }
/*     */ 
/*     */   
/*     */   public String getKey() {
/*  86 */     return this.key;
/*     */   }
/*     */   
/*     */   public String getRolePrefix() {
/*  90 */     return this.rolePrefix;
/*     */   }
/*     */   
/*     */   public void setKey(String key) {
/*  94 */     this.key = key;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setRolePrefix(String rolePrefix) {
/* 104 */     this.rolePrefix = rolePrefix;
/*     */   }
/*     */   
/*     */   public boolean supports(ConfigAttribute attribute) {
/* 108 */     return (attribute.getAttribute() != null && attribute.getAttribute().startsWith("RUN_AS_"));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean supports(Class<?> clazz) {
/* 119 */     return true;
/*     */   }
/*     */ }


/* Location:              C:\Users\Gcorp\Downloads\spring-security-core-3.2.0.RELEASE.jar!\org\springframework\security\access\intercept\RunAsManagerImpl.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */