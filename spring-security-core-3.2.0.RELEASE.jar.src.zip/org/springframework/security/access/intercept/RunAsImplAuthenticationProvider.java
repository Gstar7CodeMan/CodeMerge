/*    */ package org.springframework.security.access.intercept;
/*    */ 
/*    */ import org.springframework.beans.factory.InitializingBean;
/*    */ import org.springframework.context.MessageSource;
/*    */ import org.springframework.context.MessageSourceAware;
/*    */ import org.springframework.context.support.MessageSourceAccessor;
/*    */ import org.springframework.security.authentication.AuthenticationProvider;
/*    */ import org.springframework.security.authentication.BadCredentialsException;
/*    */ import org.springframework.security.core.Authentication;
/*    */ import org.springframework.security.core.AuthenticationException;
/*    */ import org.springframework.security.core.SpringSecurityMessageSource;
/*    */ import org.springframework.util.Assert;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class RunAsImplAuthenticationProvider
/*    */   implements InitializingBean, AuthenticationProvider, MessageSourceAware
/*    */ {
/* 44 */   protected MessageSourceAccessor messages = SpringSecurityMessageSource.getAccessor();
/*    */   
/*    */   private String key;
/*    */ 
/*    */   
/*    */   public void afterPropertiesSet() throws Exception {
/* 50 */     Assert.notNull(this.key, "A Key is required and should match that configured for the RunAsManagerImpl");
/*    */   }
/*    */ 
/*    */   
/*    */   public Authentication authenticate(Authentication authentication) throws AuthenticationException {
/* 55 */     RunAsUserToken token = (RunAsUserToken)authentication;
/*    */     
/* 57 */     if (token.getKeyHash() == this.key.hashCode()) {
/* 58 */       return authentication;
/*    */     }
/* 60 */     throw new BadCredentialsException(this.messages.getMessage("RunAsImplAuthenticationProvider.incorrectKey", "The presented RunAsUserToken does not contain the expected key"));
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public String getKey() {
/* 66 */     return this.key;
/*    */   }
/*    */   
/*    */   public void setKey(String key) {
/* 70 */     this.key = key;
/*    */   }
/*    */   
/*    */   public void setMessageSource(MessageSource messageSource) {
/* 74 */     this.messages = new MessageSourceAccessor(messageSource);
/*    */   }
/*    */   
/*    */   public boolean supports(Class<?> authentication) {
/* 78 */     return RunAsUserToken.class.isAssignableFrom(authentication);
/*    */   }
/*    */ }


/* Location:              C:\Users\Gcorp\Downloads\spring-security-core-3.2.0.RELEASE.jar!\org\springframework\security\access\intercept\RunAsImplAuthenticationProvider.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */