/*    */ package org.springframework.security.access.intercept;
/*    */ 
/*    */ import java.util.Collection;
/*    */ import org.aopalliance.intercept.MethodInvocation;
/*    */ import org.apache.commons.logging.Log;
/*    */ import org.apache.commons.logging.LogFactory;
/*    */ import org.springframework.beans.factory.InitializingBean;
/*    */ import org.springframework.security.access.AccessDeniedException;
/*    */ import org.springframework.security.access.ConfigAttribute;
/*    */ import org.springframework.security.core.Authentication;
/*    */ import org.springframework.util.Assert;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MethodInvocationPrivilegeEvaluator
/*    */   implements InitializingBean
/*    */ {
/* 44 */   protected static final Log logger = LogFactory.getLog(MethodInvocationPrivilegeEvaluator.class);
/*    */ 
/*    */ 
/*    */   
/*    */   private AbstractSecurityInterceptor securityInterceptor;
/*    */ 
/*    */ 
/*    */   
/*    */   public void afterPropertiesSet() throws Exception {
/* 53 */     Assert.notNull(this.securityInterceptor, "SecurityInterceptor required");
/*    */   }
/*    */   
/*    */   public boolean isAllowed(MethodInvocation mi, Authentication authentication) {
/* 57 */     Assert.notNull(mi, "MethodInvocation required");
/* 58 */     Assert.notNull(mi.getMethod(), "MethodInvocation must provide a non-null getMethod()");
/*    */     
/* 60 */     Collection<ConfigAttribute> attrs = this.securityInterceptor.obtainSecurityMetadataSource().getAttributes(mi);
/*    */     
/* 62 */     if (attrs == null) {
/* 63 */       if (this.securityInterceptor.isRejectPublicInvocations()) {
/* 64 */         return false;
/*    */       }
/*    */       
/* 67 */       return true;
/*    */     } 
/*    */     
/* 70 */     if (authentication == null || authentication.getAuthorities().isEmpty()) {
/* 71 */       return false;
/*    */     }
/*    */     
/*    */     try {
/* 75 */       this.securityInterceptor.getAccessDecisionManager().decide(authentication, mi, attrs);
/* 76 */     } catch (AccessDeniedException unauthorized) {
/* 77 */       if (logger.isDebugEnabled()) {
/* 78 */         logger.debug(mi.toString() + " denied for " + authentication.toString(), (Throwable)unauthorized);
/*    */       }
/*    */       
/* 81 */       return false;
/*    */     } 
/*    */     
/* 84 */     return true;
/*    */   }
/*    */   
/*    */   public void setSecurityInterceptor(AbstractSecurityInterceptor securityInterceptor) {
/* 88 */     Assert.notNull(securityInterceptor, "AbstractSecurityInterceptor cannot be null");
/* 89 */     Assert.isTrue(MethodInvocation.class.equals(securityInterceptor.getSecureObjectClass()), "AbstractSecurityInterceptor does not support MethodInvocations");
/*    */     
/* 91 */     Assert.notNull(securityInterceptor.getAccessDecisionManager(), "AbstractSecurityInterceptor must provide a non-null AccessDecisionManager");
/*    */     
/* 93 */     this.securityInterceptor = securityInterceptor;
/*    */   }
/*    */ }


/* Location:              C:\Users\Gcorp\Downloads\spring-security-core-3.2.0.RELEASE.jar!\org\springframework\security\access\intercept\MethodInvocationPrivilegeEvaluator.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */