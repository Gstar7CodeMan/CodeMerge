/*     */ package org.springframework.security.access.intercept;
/*     */ 
/*     */ import java.util.Collection;
/*     */ import java.util.HashSet;
/*     */ import java.util.Set;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.beans.factory.InitializingBean;
/*     */ import org.springframework.context.ApplicationEvent;
/*     */ import org.springframework.context.ApplicationEventPublisher;
/*     */ import org.springframework.context.ApplicationEventPublisherAware;
/*     */ import org.springframework.context.MessageSource;
/*     */ import org.springframework.context.MessageSourceAware;
/*     */ import org.springframework.context.support.MessageSourceAccessor;
/*     */ import org.springframework.security.access.AccessDecisionManager;
/*     */ import org.springframework.security.access.AccessDeniedException;
/*     */ import org.springframework.security.access.ConfigAttribute;
/*     */ import org.springframework.security.access.SecurityMetadataSource;
/*     */ import org.springframework.security.access.event.AuthenticationCredentialsNotFoundEvent;
/*     */ import org.springframework.security.access.event.AuthorizationFailureEvent;
/*     */ import org.springframework.security.access.event.AuthorizedEvent;
/*     */ import org.springframework.security.access.event.PublicInvocationEvent;
/*     */ import org.springframework.security.authentication.AuthenticationCredentialsNotFoundException;
/*     */ import org.springframework.security.authentication.AuthenticationManager;
/*     */ import org.springframework.security.core.Authentication;
/*     */ import org.springframework.security.core.SpringSecurityMessageSource;
/*     */ import org.springframework.security.core.context.SecurityContext;
/*     */ import org.springframework.security.core.context.SecurityContextHolder;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AbstractSecurityInterceptor
/*     */   implements InitializingBean, ApplicationEventPublisherAware, MessageSourceAware
/*     */ {
/* 100 */   protected final Log logger = LogFactory.getLog(getClass());
/*     */ 
/*     */ 
/*     */   
/* 104 */   protected MessageSourceAccessor messages = SpringSecurityMessageSource.getAccessor();
/*     */   private ApplicationEventPublisher eventPublisher;
/*     */   private AccessDecisionManager accessDecisionManager;
/*     */   private AfterInvocationManager afterInvocationManager;
/*     */   private AuthenticationManager authenticationManager;
/* 109 */   private RunAsManager runAsManager = new NullRunAsManager();
/*     */   
/*     */   private boolean alwaysReauthenticate = false;
/*     */   
/*     */   private boolean rejectPublicInvocations = false;
/*     */   
/*     */   private boolean validateConfigAttributes = true;
/*     */   private boolean publishAuthorizationSuccess = false;
/*     */   
/*     */   public void afterPropertiesSet() throws Exception {
/* 119 */     Assert.notNull(getSecureObjectClass(), "Subclass must provide a non-null response to getSecureObjectClass()");
/* 120 */     Assert.notNull(this.messages, "A message source must be set");
/* 121 */     Assert.notNull(this.authenticationManager, "An AuthenticationManager is required");
/* 122 */     Assert.notNull(this.accessDecisionManager, "An AccessDecisionManager is required");
/* 123 */     Assert.notNull(this.runAsManager, "A RunAsManager is required");
/* 124 */     Assert.notNull(obtainSecurityMetadataSource(), "An SecurityMetadataSource is required");
/* 125 */     Assert.isTrue(obtainSecurityMetadataSource().supports(getSecureObjectClass()), "SecurityMetadataSource does not support secure object class: " + getSecureObjectClass());
/*     */     
/* 127 */     Assert.isTrue(this.runAsManager.supports(getSecureObjectClass()), "RunAsManager does not support secure object class: " + getSecureObjectClass());
/*     */     
/* 129 */     Assert.isTrue(this.accessDecisionManager.supports(getSecureObjectClass()), "AccessDecisionManager does not support secure object class: " + getSecureObjectClass());
/*     */ 
/*     */     
/* 132 */     if (this.afterInvocationManager != null) {
/* 133 */       Assert.isTrue(this.afterInvocationManager.supports(getSecureObjectClass()), "AfterInvocationManager does not support secure object class: " + getSecureObjectClass());
/*     */     }
/*     */ 
/*     */     
/* 137 */     if (this.validateConfigAttributes) {
/* 138 */       Collection<ConfigAttribute> attributeDefs = obtainSecurityMetadataSource().getAllConfigAttributes();
/*     */       
/* 140 */       if (attributeDefs == null) {
/* 141 */         this.logger.warn("Could not validate configuration attributes as the SecurityMetadataSource did not return any attributes from getAllConfigAttributes()");
/*     */         
/*     */         return;
/*     */       } 
/*     */       
/* 146 */       Set<ConfigAttribute> unsupportedAttrs = new HashSet<ConfigAttribute>();
/*     */       
/* 148 */       for (ConfigAttribute attr : attributeDefs) {
/* 149 */         if (!this.runAsManager.supports(attr) && !this.accessDecisionManager.supports(attr) && (this.afterInvocationManager == null || !this.afterInvocationManager.supports(attr)))
/*     */         {
/* 151 */           unsupportedAttrs.add(attr);
/*     */         }
/*     */       } 
/*     */       
/* 155 */       if (unsupportedAttrs.size() != 0) {
/* 156 */         throw new IllegalArgumentException("Unsupported configuration attributes: " + unsupportedAttrs);
/*     */       }
/*     */       
/* 159 */       this.logger.debug("Validated configuration attributes");
/*     */     } 
/*     */   }
/*     */   
/*     */   protected InterceptorStatusToken beforeInvocation(Object object) {
/* 164 */     Assert.notNull(object, "Object was null");
/* 165 */     boolean debug = this.logger.isDebugEnabled();
/*     */     
/* 167 */     if (!getSecureObjectClass().isAssignableFrom(object.getClass())) {
/* 168 */       throw new IllegalArgumentException("Security invocation attempted for object " + object.getClass().getName() + " but AbstractSecurityInterceptor only configured to support secure objects of type: " + getSecureObjectClass());
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 174 */     Collection<ConfigAttribute> attributes = obtainSecurityMetadataSource().getAttributes(object);
/*     */     
/* 176 */     if (attributes == null || attributes.isEmpty()) {
/* 177 */       if (this.rejectPublicInvocations) {
/* 178 */         throw new IllegalArgumentException("Secure object invocation " + object + " was denied as public invocations are not allowed via this interceptor. " + "This indicates a configuration error because the " + "rejectPublicInvocations property is set to 'true'");
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 184 */       if (debug) {
/* 185 */         this.logger.debug("Public object - authentication not attempted");
/*     */       }
/*     */       
/* 188 */       publishEvent((ApplicationEvent)new PublicInvocationEvent(object));
/*     */       
/* 190 */       return null;
/*     */     } 
/*     */     
/* 193 */     if (debug) {
/* 194 */       this.logger.debug("Secure object: " + object + "; Attributes: " + attributes);
/*     */     }
/*     */     
/* 197 */     if (SecurityContextHolder.getContext().getAuthentication() == null) {
/* 198 */       credentialsNotFound(this.messages.getMessage("AbstractSecurityInterceptor.authenticationNotFound", "An Authentication object was not found in the SecurityContext"), object, attributes);
/*     */     }
/*     */ 
/*     */     
/* 202 */     Authentication authenticated = authenticateIfRequired();
/*     */ 
/*     */     
/*     */     try {
/* 206 */       this.accessDecisionManager.decide(authenticated, object, attributes);
/*     */     }
/* 208 */     catch (AccessDeniedException accessDeniedException) {
/* 209 */       publishEvent((ApplicationEvent)new AuthorizationFailureEvent(object, attributes, authenticated, accessDeniedException));
/*     */       
/* 211 */       throw accessDeniedException;
/*     */     } 
/*     */     
/* 214 */     if (debug) {
/* 215 */       this.logger.debug("Authorization successful");
/*     */     }
/*     */     
/* 218 */     if (this.publishAuthorizationSuccess) {
/* 219 */       publishEvent((ApplicationEvent)new AuthorizedEvent(object, attributes, authenticated));
/*     */     }
/*     */ 
/*     */     
/* 223 */     Authentication runAs = this.runAsManager.buildRunAs(authenticated, object, attributes);
/*     */     
/* 225 */     if (runAs == null) {
/* 226 */       if (debug) {
/* 227 */         this.logger.debug("RunAsManager did not change Authentication object");
/*     */       }
/*     */ 
/*     */       
/* 231 */       return new InterceptorStatusToken(SecurityContextHolder.getContext(), false, attributes, object);
/*     */     } 
/* 233 */     if (debug) {
/* 234 */       this.logger.debug("Switching to RunAs Authentication: " + runAs);
/*     */     }
/*     */     
/* 237 */     SecurityContext origCtx = SecurityContextHolder.getContext();
/* 238 */     SecurityContextHolder.setContext(SecurityContextHolder.createEmptyContext());
/* 239 */     SecurityContextHolder.getContext().setAuthentication(runAs);
/*     */ 
/*     */     
/* 242 */     return new InterceptorStatusToken(origCtx, true, attributes, object);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void finallyInvocation(InterceptorStatusToken token) {
/* 254 */     if (token != null && token.isContextHolderRefreshRequired()) {
/* 255 */       if (this.logger.isDebugEnabled()) {
/* 256 */         this.logger.debug("Reverting to original Authentication: " + token.getSecurityContext().getAuthentication());
/*     */       }
/*     */       
/* 259 */       SecurityContextHolder.setContext(token.getSecurityContext());
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Object afterInvocation(InterceptorStatusToken token, Object returnedObject) {
/* 272 */     if (token == null)
/*     */     {
/* 274 */       return returnedObject;
/*     */     }
/*     */     
/* 277 */     finallyInvocation(token);
/*     */     
/* 279 */     if (this.afterInvocationManager != null) {
/*     */       
/*     */       try {
/* 282 */         returnedObject = this.afterInvocationManager.decide(token.getSecurityContext().getAuthentication(), token.getSecureObject(), token.getAttributes(), returnedObject);
/*     */ 
/*     */       
/*     */       }
/* 286 */       catch (AccessDeniedException accessDeniedException) {
/* 287 */         AuthorizationFailureEvent event = new AuthorizationFailureEvent(token.getSecureObject(), token.getAttributes(), token.getSecurityContext().getAuthentication(), accessDeniedException);
/*     */         
/* 289 */         publishEvent((ApplicationEvent)event);
/*     */         
/* 291 */         throw accessDeniedException;
/*     */       } 
/*     */     }
/*     */     
/* 295 */     return returnedObject;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Authentication authenticateIfRequired() {
/* 306 */     Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
/*     */     
/* 308 */     if (authentication.isAuthenticated() && !this.alwaysReauthenticate) {
/* 309 */       if (this.logger.isDebugEnabled()) {
/* 310 */         this.logger.debug("Previously Authenticated: " + authentication);
/*     */       }
/*     */       
/* 313 */       return authentication;
/*     */     } 
/*     */     
/* 316 */     authentication = this.authenticationManager.authenticate(authentication);
/*     */ 
/*     */     
/* 319 */     if (this.logger.isDebugEnabled()) {
/* 320 */       this.logger.debug("Successfully Authenticated: " + authentication);
/*     */     }
/*     */     
/* 323 */     SecurityContextHolder.getContext().setAuthentication(authentication);
/*     */     
/* 325 */     return authentication;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void credentialsNotFound(String reason, Object secureObject, Collection<ConfigAttribute> configAttribs) {
/* 339 */     AuthenticationCredentialsNotFoundException exception = new AuthenticationCredentialsNotFoundException(reason);
/*     */     
/* 341 */     AuthenticationCredentialsNotFoundEvent event = new AuthenticationCredentialsNotFoundEvent(secureObject, configAttribs, exception);
/*     */     
/* 343 */     publishEvent((ApplicationEvent)event);
/*     */     
/* 345 */     throw exception;
/*     */   }
/*     */   
/*     */   public AccessDecisionManager getAccessDecisionManager() {
/* 349 */     return this.accessDecisionManager;
/*     */   }
/*     */   
/*     */   public AfterInvocationManager getAfterInvocationManager() {
/* 353 */     return this.afterInvocationManager;
/*     */   }
/*     */   
/*     */   public AuthenticationManager getAuthenticationManager() {
/* 357 */     return this.authenticationManager;
/*     */   }
/*     */   
/*     */   public RunAsManager getRunAsManager() {
/* 361 */     return this.runAsManager;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract Class<?> getSecureObjectClass();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isAlwaysReauthenticate() {
/* 375 */     return this.alwaysReauthenticate;
/*     */   }
/*     */   
/*     */   public boolean isRejectPublicInvocations() {
/* 379 */     return this.rejectPublicInvocations;
/*     */   }
/*     */   
/*     */   public boolean isValidateConfigAttributes() {
/* 383 */     return this.validateConfigAttributes;
/*     */   }
/*     */   
/*     */   public abstract SecurityMetadataSource obtainSecurityMetadataSource();
/*     */   
/*     */   public void setAccessDecisionManager(AccessDecisionManager accessDecisionManager) {
/* 389 */     this.accessDecisionManager = accessDecisionManager;
/*     */   }
/*     */   
/*     */   public void setAfterInvocationManager(AfterInvocationManager afterInvocationManager) {
/* 393 */     this.afterInvocationManager = afterInvocationManager;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setAlwaysReauthenticate(boolean alwaysReauthenticate) {
/* 409 */     this.alwaysReauthenticate = alwaysReauthenticate;
/*     */   }
/*     */   
/*     */   public void setApplicationEventPublisher(ApplicationEventPublisher applicationEventPublisher) {
/* 413 */     this.eventPublisher = applicationEventPublisher;
/*     */   }
/*     */   
/*     */   public void setAuthenticationManager(AuthenticationManager newManager) {
/* 417 */     this.authenticationManager = newManager;
/*     */   }
/*     */   
/*     */   public void setMessageSource(MessageSource messageSource) {
/* 421 */     this.messages = new MessageSourceAccessor(messageSource);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setPublishAuthorizationSuccess(boolean publishAuthorizationSuccess) {
/* 431 */     this.publishAuthorizationSuccess = publishAuthorizationSuccess;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setRejectPublicInvocations(boolean rejectPublicInvocations) {
/* 447 */     this.rejectPublicInvocations = rejectPublicInvocations;
/*     */   }
/*     */   
/*     */   public void setRunAsManager(RunAsManager runAsManager) {
/* 451 */     this.runAsManager = runAsManager;
/*     */   }
/*     */   
/*     */   public void setValidateConfigAttributes(boolean validateConfigAttributes) {
/* 455 */     this.validateConfigAttributes = validateConfigAttributes;
/*     */   }
/*     */   
/*     */   private void publishEvent(ApplicationEvent event) {
/* 459 */     if (this.eventPublisher != null)
/* 460 */       this.eventPublisher.publishEvent(event); 
/*     */   }
/*     */ }


/* Location:              C:\Users\Gcorp\Downloads\spring-security-core-3.2.0.RELEASE.jar!\org\springframework\security\access\intercept\AbstractSecurityInterceptor.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */