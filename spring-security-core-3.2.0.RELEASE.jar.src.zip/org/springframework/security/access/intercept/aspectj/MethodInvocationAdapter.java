/*    */ package org.springframework.security.access.intercept.aspectj;
/*    */ 
/*    */ import java.lang.reflect.AccessibleObject;
/*    */ import java.lang.reflect.Method;
/*    */ import org.aopalliance.intercept.MethodInvocation;
/*    */ import org.aspectj.lang.JoinPoint;
/*    */ import org.aspectj.lang.ProceedingJoinPoint;
/*    */ import org.aspectj.lang.reflect.CodeSignature;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class MethodInvocationAdapter
/*    */   implements MethodInvocation
/*    */ {
/*    */   private final ProceedingJoinPoint jp;
/*    */   private final Method method;
/*    */   private final Object target;
/*    */   
/*    */   MethodInvocationAdapter(JoinPoint jp) {
/* 26 */     this.jp = (ProceedingJoinPoint)jp;
/* 27 */     if (jp.getTarget() != null) {
/* 28 */       this.target = jp.getTarget();
/*    */     } else {
/*    */       
/* 31 */       this.target = jp.getSignature().getDeclaringType();
/*    */     } 
/* 33 */     String targetMethodName = jp.getStaticPart().getSignature().getName();
/* 34 */     Class<?>[] types = ((CodeSignature)jp.getStaticPart().getSignature()).getParameterTypes();
/* 35 */     Class<?> declaringType = jp.getStaticPart().getSignature().getDeclaringType();
/*    */     
/* 37 */     this.method = findMethod(targetMethodName, declaringType, types);
/*    */     
/* 39 */     if (this.method == null) {
/* 40 */       throw new IllegalArgumentException("Could not obtain target method from JoinPoint: '" + jp + "'");
/*    */     }
/*    */   }
/*    */   
/*    */   private Method findMethod(String name, Class<?> declaringType, Class<?>[] params) {
/* 45 */     Method method = null;
/*    */     
/*    */     try {
/* 48 */       method = declaringType.getMethod(name, params);
/* 49 */     } catch (NoSuchMethodException ignored) {}
/*    */ 
/*    */     
/* 52 */     if (method == null) {
/*    */       try {
/* 54 */         method = declaringType.getDeclaredMethod(name, params);
/* 55 */       } catch (NoSuchMethodException ignored) {}
/*    */     }
/*    */ 
/*    */     
/* 59 */     return method;
/*    */   }
/*    */   
/*    */   public Method getMethod() {
/* 63 */     return this.method;
/*    */   }
/*    */   
/*    */   public Object[] getArguments() {
/* 67 */     return this.jp.getArgs();
/*    */   }
/*    */   
/*    */   public AccessibleObject getStaticPart() {
/* 71 */     return this.method;
/*    */   }
/*    */   
/*    */   public Object getThis() {
/* 75 */     return this.target;
/*    */   }
/*    */   
/*    */   public Object proceed() throws Throwable {
/* 79 */     return this.jp.proceed();
/*    */   }
/*    */ }


/* Location:              C:\Users\Gcorp\Downloads\spring-security-core-3.2.0.RELEASE.jar!\org\springframework\security\access\intercept\aspectj\MethodInvocationAdapter.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */