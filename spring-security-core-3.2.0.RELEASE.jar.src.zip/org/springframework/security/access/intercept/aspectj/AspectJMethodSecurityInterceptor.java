/*    */ package org.springframework.security.access.intercept.aspectj;
/*    */ 
/*    */ import org.aspectj.lang.JoinPoint;
/*    */ import org.springframework.security.access.intercept.InterceptorStatusToken;
/*    */ import org.springframework.security.access.intercept.aopalliance.MethodSecurityInterceptor;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class AspectJMethodSecurityInterceptor
/*    */   extends MethodSecurityInterceptor
/*    */ {
/*    */   public Object invoke(JoinPoint jp) throws Throwable {
/* 28 */     return invoke(new MethodInvocationAdapter(jp));
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Object invoke(JoinPoint jp, AspectJCallback advisorProceed) {
/*    */     Object result;
/* 41 */     InterceptorStatusToken token = beforeInvocation(new MethodInvocationAdapter(jp));
/*    */ 
/*    */     
/*    */     try {
/* 45 */       result = advisorProceed.proceedWithObject();
/*    */     } finally {
/* 47 */       finallyInvocation(token);
/*    */     } 
/*    */     
/* 50 */     return afterInvocation(token, result);
/*    */   }
/*    */ }


/* Location:              C:\Users\Gcorp\Downloads\spring-security-core-3.2.0.RELEASE.jar!\org\springframework\security\access\intercept\aspectj\AspectJMethodSecurityInterceptor.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */