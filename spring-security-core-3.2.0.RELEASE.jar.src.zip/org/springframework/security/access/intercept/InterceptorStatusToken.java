/*    */ package org.springframework.security.access.intercept;
/*    */ 
/*    */ import java.util.Collection;
/*    */ import org.springframework.security.access.ConfigAttribute;
/*    */ import org.springframework.security.core.context.SecurityContext;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class InterceptorStatusToken
/*    */ {
/*    */   private SecurityContext securityContext;
/*    */   private Collection<ConfigAttribute> attr;
/*    */   private Object secureObject;
/*    */   private boolean contextHolderRefreshRequired;
/*    */   
/*    */   public InterceptorStatusToken(SecurityContext securityContext, boolean contextHolderRefreshRequired, Collection<ConfigAttribute> attributes, Object secureObject) {
/* 46 */     this.securityContext = securityContext;
/* 47 */     this.contextHolderRefreshRequired = contextHolderRefreshRequired;
/* 48 */     this.attr = attributes;
/* 49 */     this.secureObject = secureObject;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public Collection<ConfigAttribute> getAttributes() {
/* 55 */     return this.attr;
/*    */   }
/*    */   
/*    */   public SecurityContext getSecurityContext() {
/* 59 */     return this.securityContext;
/*    */   }
/*    */   
/*    */   public Object getSecureObject() {
/* 63 */     return this.secureObject;
/*    */   }
/*    */   
/*    */   public boolean isContextHolderRefreshRequired() {
/* 67 */     return this.contextHolderRefreshRequired;
/*    */   }
/*    */ }


/* Location:              C:\Users\Gcorp\Downloads\spring-security-core-3.2.0.RELEASE.jar!\org\springframework\security\access\intercept\InterceptorStatusToken.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */