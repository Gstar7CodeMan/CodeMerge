/*    */ package org.springframework.security.access.intercept;
/*    */ 
/*    */ import java.util.Collection;
/*    */ import org.springframework.security.access.ConfigAttribute;
/*    */ import org.springframework.security.core.Authentication;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class NullRunAsManager
/*    */   implements RunAsManager
/*    */ {
/*    */   public Authentication buildRunAs(Authentication authentication, Object object, Collection<ConfigAttribute> config) {
/* 35 */     return null;
/*    */   }
/*    */   
/*    */   public boolean supports(ConfigAttribute attribute) {
/* 39 */     return false;
/*    */   }
/*    */   
/*    */   public boolean supports(Class<?> clazz) {
/* 43 */     return true;
/*    */   }
/*    */ }


/* Location:              C:\Users\Gcorp\Downloads\spring-security-core-3.2.0.RELEASE.jar!\org\springframework\security\access\intercept\NullRunAsManager.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */