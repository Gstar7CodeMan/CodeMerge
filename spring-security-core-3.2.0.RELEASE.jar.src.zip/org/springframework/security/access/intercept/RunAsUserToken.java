/*    */ package org.springframework.security.access.intercept;
/*    */ 
/*    */ import java.util.Collection;
/*    */ import org.springframework.security.authentication.AbstractAuthenticationToken;
/*    */ import org.springframework.security.core.Authentication;
/*    */ import org.springframework.security.core.GrantedAuthority;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class RunAsUserToken
/*    */   extends AbstractAuthenticationToken
/*    */ {
/*    */   private static final long serialVersionUID = 320L;
/*    */   private final Class<? extends Authentication> originalAuthentication;
/*    */   private final Object credentials;
/*    */   private final Object principal;
/*    */   private final int keyHash;
/*    */   
/*    */   public RunAsUserToken(String key, Object principal, Object credentials, Collection<? extends GrantedAuthority> authorities, Class<? extends Authentication> originalAuthentication) {
/* 46 */     super(authorities);
/* 47 */     this.keyHash = key.hashCode();
/* 48 */     this.principal = principal;
/* 49 */     this.credentials = credentials;
/* 50 */     this.originalAuthentication = originalAuthentication;
/* 51 */     setAuthenticated(true);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public Object getCredentials() {
/* 57 */     return this.credentials;
/*    */   }
/*    */   
/*    */   public int getKeyHash() {
/* 61 */     return this.keyHash;
/*    */   }
/*    */   
/*    */   public Class<? extends Authentication> getOriginalAuthentication() {
/* 65 */     return this.originalAuthentication;
/*    */   }
/*    */   
/*    */   public Object getPrincipal() {
/* 69 */     return this.principal;
/*    */   }
/*    */   
/*    */   public String toString() {
/* 73 */     StringBuilder sb = new StringBuilder(super.toString());
/* 74 */     String className = (this.originalAuthentication == null) ? null : this.originalAuthentication.getName();
/* 75 */     sb.append("; Original Class: ").append(className);
/*    */     
/* 77 */     return sb.toString();
/*    */   }
/*    */ }


/* Location:              C:\Users\Gcorp\Downloads\spring-security-core-3.2.0.RELEASE.jar!\org\springframework\security\access\intercept\RunAsUserToken.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */