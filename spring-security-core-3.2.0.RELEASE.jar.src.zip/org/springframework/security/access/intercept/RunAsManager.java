package org.springframework.security.access.intercept;

import java.util.Collection;
import org.springframework.security.access.ConfigAttribute;
import org.springframework.security.core.Authentication;

public interface RunAsManager {
  Authentication buildRunAs(Authentication paramAuthentication, Object paramObject, Collection<ConfigAttribute> paramCollection);
  
  boolean supports(ConfigAttribute paramConfigAttribute);
  
  boolean supports(Class<?> paramClass);
}


/* Location:              C:\Users\Gcorp\Downloads\spring-security-core-3.2.0.RELEASE.jar!\org\springframework\security\access\intercept\RunAsManager.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */