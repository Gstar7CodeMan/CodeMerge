/*     */ package org.springframework.security.access.intercept;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.List;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.beans.factory.InitializingBean;
/*     */ import org.springframework.security.access.AccessDeniedException;
/*     */ import org.springframework.security.access.AfterInvocationProvider;
/*     */ import org.springframework.security.access.ConfigAttribute;
/*     */ import org.springframework.security.core.Authentication;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class AfterInvocationProviderManager
/*     */   implements AfterInvocationManager, InitializingBean
/*     */ {
/*  49 */   protected static final Log logger = LogFactory.getLog(AfterInvocationProviderManager.class);
/*     */ 
/*     */ 
/*     */   
/*     */   private List<AfterInvocationProvider> providers;
/*     */ 
/*     */ 
/*     */   
/*     */   public void afterPropertiesSet() throws Exception {
/*  58 */     checkIfValidList(this.providers);
/*     */   }
/*     */   
/*     */   private void checkIfValidList(List<?> listToCheck) {
/*  62 */     if (listToCheck == null || listToCheck.size() == 0) {
/*  63 */       throw new IllegalArgumentException("A list of AfterInvocationProviders is required");
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Object decide(Authentication authentication, Object object, Collection<ConfigAttribute> config, Object returnedObject) throws AccessDeniedException {
/*  70 */     Object result = returnedObject;
/*     */     
/*  72 */     for (AfterInvocationProvider provider : this.providers) {
/*  73 */       result = provider.decide(authentication, object, config, result);
/*     */     }
/*     */     
/*  76 */     return result;
/*     */   }
/*     */   
/*     */   public List<AfterInvocationProvider> getProviders() {
/*  80 */     return this.providers;
/*     */   }
/*     */   
/*     */   public void setProviders(List<?> newList) {
/*  84 */     checkIfValidList(newList);
/*  85 */     this.providers = new ArrayList<AfterInvocationProvider>(newList.size());
/*     */     
/*  87 */     for (Object currentObject : newList) {
/*  88 */       Assert.isInstanceOf(AfterInvocationProvider.class, currentObject, "AfterInvocationProvider " + currentObject.getClass().getName() + " must implement AfterInvocationProvider");
/*     */       
/*  90 */       this.providers.add((AfterInvocationProvider)currentObject);
/*     */     } 
/*     */   }
/*     */   
/*     */   public boolean supports(ConfigAttribute attribute) {
/*  95 */     for (AfterInvocationProvider provider : this.providers) {
/*  96 */       if (logger.isDebugEnabled()) {
/*  97 */         logger.debug("Evaluating " + attribute + " against " + provider);
/*     */       }
/*     */       
/* 100 */       if (provider.supports(attribute)) {
/* 101 */         return true;
/*     */       }
/*     */     } 
/*     */     
/* 105 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean supports(Class<?> clazz) {
/* 120 */     for (AfterInvocationProvider provider : this.providers) {
/* 121 */       if (!provider.supports(clazz)) {
/* 122 */         return false;
/*     */       }
/*     */     } 
/*     */     
/* 126 */     return true;
/*     */   }
/*     */ }


/* Location:              C:\Users\Gcorp\Downloads\spring-security-core-3.2.0.RELEASE.jar!\org\springframework\security\access\intercept\AfterInvocationProviderManager.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */