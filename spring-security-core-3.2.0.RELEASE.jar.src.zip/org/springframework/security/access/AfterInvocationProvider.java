package org.springframework.security.access;

import java.util.Collection;
import org.springframework.security.core.Authentication;

public interface AfterInvocationProvider {
  Object decide(Authentication paramAuthentication, Object paramObject1, Collection<ConfigAttribute> paramCollection, Object paramObject2) throws AccessDeniedException;
  
  boolean supports(ConfigAttribute paramConfigAttribute);
  
  boolean supports(Class<?> paramClass);
}


/* Location:              C:\Users\Gcorp\Downloads\spring-security-core-3.2.0.RELEASE.jar!\org\springframework\security\access\AfterInvocationProvider.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */