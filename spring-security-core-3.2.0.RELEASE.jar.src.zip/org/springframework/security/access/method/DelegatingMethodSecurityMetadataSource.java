/*     */ package org.springframework.security.access.method;
/*     */ 
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import org.springframework.security.access.ConfigAttribute;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ObjectUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class DelegatingMethodSecurityMetadataSource
/*     */   extends AbstractMethodSecurityMetadataSource
/*     */ {
/*  24 */   private static final List<ConfigAttribute> NULL_CONFIG_ATTRIBUTE = Collections.emptyList();
/*     */   
/*     */   private final List<MethodSecurityMetadataSource> methodSecurityMetadataSources;
/*  27 */   private final Map<DefaultCacheKey, Collection<ConfigAttribute>> attributeCache = new HashMap<DefaultCacheKey, Collection<ConfigAttribute>>();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DelegatingMethodSecurityMetadataSource(List<MethodSecurityMetadataSource> methodSecurityMetadataSources) {
/*  33 */     Assert.notNull(methodSecurityMetadataSources, "MethodSecurityMetadataSources cannot be null");
/*  34 */     this.methodSecurityMetadataSources = methodSecurityMetadataSources;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Collection<ConfigAttribute> getAttributes(Method method, Class<?> targetClass) {
/*  40 */     DefaultCacheKey cacheKey = new DefaultCacheKey(method, targetClass);
/*  41 */     synchronized (this.attributeCache) {
/*  42 */       Collection<ConfigAttribute> cached = this.attributeCache.get(cacheKey);
/*     */ 
/*     */       
/*  45 */       if (cached != null) {
/*  46 */         return cached;
/*     */       }
/*     */ 
/*     */       
/*  50 */       Collection<ConfigAttribute> attributes = null;
/*  51 */       for (MethodSecurityMetadataSource s : this.methodSecurityMetadataSources) {
/*  52 */         attributes = s.getAttributes(method, targetClass);
/*  53 */         if (attributes != null && !attributes.isEmpty()) {
/*     */           break;
/*     */         }
/*     */       } 
/*     */ 
/*     */       
/*  59 */       if (attributes == null || attributes.isEmpty()) {
/*  60 */         this.attributeCache.put(cacheKey, NULL_CONFIG_ATTRIBUTE);
/*  61 */         return NULL_CONFIG_ATTRIBUTE;
/*     */       } 
/*     */       
/*  64 */       if (this.logger.isDebugEnabled()) {
/*  65 */         this.logger.debug("Caching method [" + cacheKey + "] with attributes " + attributes);
/*     */       }
/*     */       
/*  68 */       this.attributeCache.put(cacheKey, attributes);
/*     */       
/*  70 */       return attributes;
/*     */     } 
/*     */   }
/*     */   
/*     */   public Collection<ConfigAttribute> getAllConfigAttributes() {
/*  75 */     Set<ConfigAttribute> set = new HashSet<ConfigAttribute>();
/*  76 */     for (MethodSecurityMetadataSource s : this.methodSecurityMetadataSources) {
/*  77 */       Collection<ConfigAttribute> attrs = s.getAllConfigAttributes();
/*  78 */       if (attrs != null) {
/*  79 */         set.addAll(attrs);
/*     */       }
/*     */     } 
/*  82 */     return set;
/*     */   }
/*     */   
/*     */   public List<MethodSecurityMetadataSource> getMethodSecurityMetadataSources() {
/*  86 */     return this.methodSecurityMetadataSources;
/*     */   }
/*     */ 
/*     */   
/*     */   private static class DefaultCacheKey
/*     */   {
/*     */     private final Method method;
/*     */     private final Class<?> targetClass;
/*     */     
/*     */     public DefaultCacheKey(Method method, Class<?> targetClass) {
/*  96 */       this.method = method;
/*  97 */       this.targetClass = targetClass;
/*     */     }
/*     */     
/*     */     public boolean equals(Object other) {
/* 101 */       DefaultCacheKey otherKey = (DefaultCacheKey)other;
/* 102 */       return (this.method.equals(otherKey.method) && ObjectUtils.nullSafeEquals(this.targetClass, otherKey.targetClass));
/*     */     }
/*     */ 
/*     */     
/*     */     public int hashCode() {
/* 107 */       return this.method.hashCode() * 21 + ((this.targetClass != null) ? this.targetClass.hashCode() : 0);
/*     */     }
/*     */     
/*     */     public String toString() {
/* 111 */       return "CacheKey[" + ((this.targetClass == null) ? "-" : this.targetClass.getName()) + "; " + this.method + "]";
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Gcorp\Downloads\spring-security-core-3.2.0.RELEASE.jar!\org\springframework\security\access\method\DelegatingMethodSecurityMetadataSource.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */