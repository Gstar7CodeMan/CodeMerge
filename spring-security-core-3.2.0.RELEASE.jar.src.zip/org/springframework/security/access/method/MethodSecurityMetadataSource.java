package org.springframework.security.access.method;

import java.lang.reflect.Method;
import java.util.Collection;
import org.springframework.security.access.ConfigAttribute;
import org.springframework.security.access.SecurityMetadataSource;

public interface MethodSecurityMetadataSource extends SecurityMetadataSource {
  Collection<ConfigAttribute> getAttributes(Method paramMethod, Class<?> paramClass);
}


/* Location:              C:\Users\Gcorp\Downloads\spring-security-core-3.2.0.RELEASE.jar!\org\springframework\security\access\method\MethodSecurityMetadataSource.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */