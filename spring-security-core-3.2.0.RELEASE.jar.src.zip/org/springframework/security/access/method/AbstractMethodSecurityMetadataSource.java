/*    */ package org.springframework.security.access.method;
/*    */ 
/*    */ import java.util.Collection;
/*    */ import org.aopalliance.intercept.MethodInvocation;
/*    */ import org.apache.commons.logging.Log;
/*    */ import org.apache.commons.logging.LogFactory;
/*    */ import org.springframework.aop.framework.AopProxyUtils;
/*    */ import org.springframework.security.access.ConfigAttribute;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class AbstractMethodSecurityMetadataSource
/*    */   implements MethodSecurityMetadataSource
/*    */ {
/* 36 */   protected final Log logger = LogFactory.getLog(getClass());
/*    */ 
/*    */ 
/*    */   
/*    */   public final Collection<ConfigAttribute> getAttributes(Object object) {
/* 41 */     if (object instanceof MethodInvocation) {
/* 42 */       MethodInvocation mi = (MethodInvocation)object;
/* 43 */       Object target = mi.getThis();
/* 44 */       Class<?> targetClass = null;
/*    */       
/* 46 */       if (target != null) {
/* 47 */         targetClass = (target instanceof Class) ? (Class)target : AopProxyUtils.ultimateTargetClass(target);
/*    */       }
/*    */       
/* 50 */       return getAttributes(mi.getMethod(), targetClass);
/*    */     } 
/*    */     
/* 53 */     throw new IllegalArgumentException("Object must be a non-null MethodInvocation");
/*    */   }
/*    */   
/*    */   public final boolean supports(Class<?> clazz) {
/* 57 */     return MethodInvocation.class.isAssignableFrom(clazz);
/*    */   }
/*    */ }


/* Location:              C:\Users\Gcorp\Downloads\spring-security-core-3.2.0.RELEASE.jar!\org\springframework\security\access\method\AbstractMethodSecurityMetadataSource.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */