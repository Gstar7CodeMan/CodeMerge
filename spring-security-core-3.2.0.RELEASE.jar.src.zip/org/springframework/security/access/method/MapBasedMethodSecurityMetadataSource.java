/*     */ package org.springframework.security.access.method;
/*     */ 
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import org.springframework.beans.factory.BeanClassLoaderAware;
/*     */ import org.springframework.security.access.ConfigAttribute;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ClassUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MapBasedMethodSecurityMetadataSource
/*     */   extends AbstractFallbackMethodSecurityMetadataSource
/*     */   implements BeanClassLoaderAware
/*     */ {
/*  50 */   private ClassLoader beanClassLoader = ClassUtils.getDefaultClassLoader();
/*     */ 
/*     */   
/*  53 */   protected final Map<RegisteredMethod, List<ConfigAttribute>> methodMap = new HashMap<RegisteredMethod, List<ConfigAttribute>>();
/*     */ 
/*     */   
/*  56 */   private final Map<RegisteredMethod, String> nameMap = new HashMap<RegisteredMethod, String>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MapBasedMethodSecurityMetadataSource() {}
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MapBasedMethodSecurityMetadataSource(Map<String, List<ConfigAttribute>> methodMap) {
/*  68 */     for (Map.Entry<String, List<ConfigAttribute>> entry : methodMap.entrySet()) {
/*  69 */       addSecureMethod(entry.getKey(), entry.getValue());
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Collection<ConfigAttribute> findAttributes(Class<?> clazz) {
/*  77 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Collection<ConfigAttribute> findAttributes(Method method, Class<?> targetClass) {
/*  84 */     if (targetClass == null) {
/*  85 */       return null;
/*     */     }
/*     */     
/*  88 */     return findAttributesSpecifiedAgainst(method, targetClass);
/*     */   }
/*     */   
/*     */   private List<ConfigAttribute> findAttributesSpecifiedAgainst(Method method, Class<?> clazz) {
/*  92 */     RegisteredMethod registeredMethod = new RegisteredMethod(method, clazz);
/*  93 */     if (this.methodMap.containsKey(registeredMethod)) {
/*  94 */       return this.methodMap.get(registeredMethod);
/*     */     }
/*     */     
/*  97 */     if (clazz.getSuperclass() != null) {
/*  98 */       return findAttributesSpecifiedAgainst(method, clazz.getSuperclass());
/*     */     }
/* 100 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void addSecureMethod(String name, List<ConfigAttribute> attr) {
/* 111 */     int lastDotIndex = name.lastIndexOf(".");
/*     */     
/* 113 */     if (lastDotIndex == -1) {
/* 114 */       throw new IllegalArgumentException("'" + name + "' is not a valid method name: format is FQN.methodName");
/*     */     }
/*     */     
/* 117 */     String methodName = name.substring(lastDotIndex + 1);
/* 118 */     Assert.hasText(methodName, "Method not found for '" + name + "'");
/*     */     
/* 120 */     String typeName = name.substring(0, lastDotIndex);
/* 121 */     Class<?> type = ClassUtils.resolveClassName(typeName, this.beanClassLoader);
/*     */     
/* 123 */     addSecureMethod(type, methodName, attr);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addSecureMethod(Class<?> javaType, String mappedName, List<ConfigAttribute> attr) {
/* 135 */     String name = javaType.getName() + '.' + mappedName;
/*     */     
/* 137 */     if (this.logger.isDebugEnabled()) {
/* 138 */       this.logger.debug("Request to add secure method [" + name + "] with attributes [" + attr + "]");
/*     */     }
/*     */     
/* 141 */     Method[] methods = javaType.getMethods();
/* 142 */     List<Method> matchingMethods = new ArrayList<Method>();
/*     */     
/* 144 */     for (Method m : methods) {
/* 145 */       if (m.getName().equals(mappedName) || isMatch(m.getName(), mappedName)) {
/* 146 */         matchingMethods.add(m);
/*     */       }
/*     */     } 
/*     */     
/* 150 */     if (matchingMethods.isEmpty()) {
/* 151 */       throw new IllegalArgumentException("Couldn't find method '" + mappedName + "' on '" + javaType + "'");
/*     */     }
/*     */ 
/*     */     
/* 155 */     for (Method method : matchingMethods) {
/* 156 */       RegisteredMethod registeredMethod = new RegisteredMethod(method, javaType);
/* 157 */       String regMethodName = this.nameMap.get(registeredMethod);
/*     */       
/* 159 */       if (regMethodName == null || (!regMethodName.equals(name) && regMethodName.length() <= name.length())) {
/*     */ 
/*     */         
/* 162 */         if (regMethodName != null) {
/* 163 */           this.logger.debug("Replacing attributes for secure method [" + method + "]: current name [" + name + "] is more specific than [" + regMethodName + "]");
/*     */         }
/*     */ 
/*     */         
/* 167 */         this.nameMap.put(registeredMethod, name);
/* 168 */         addSecureMethod(registeredMethod, attr); continue;
/*     */       } 
/* 170 */       this.logger.debug("Keeping attributes for secure method [" + method + "]: current name [" + name + "] is not more specific than [" + regMethodName + "]");
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addSecureMethod(Class<?> javaType, Method method, List<ConfigAttribute> attr) {
/* 185 */     RegisteredMethod key = new RegisteredMethod(method, javaType);
/*     */     
/* 187 */     if (this.methodMap.containsKey(key)) {
/* 188 */       this.logger.debug("Method [" + method + "] is already registered with attributes [" + this.methodMap.get(key) + "]");
/*     */       
/*     */       return;
/*     */     } 
/* 192 */     this.methodMap.put(key, attr);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void addSecureMethod(RegisteredMethod method, List<ConfigAttribute> attr) {
/* 202 */     Assert.notNull(method, "RegisteredMethod required");
/* 203 */     Assert.notNull(attr, "Configuration attribute required");
/* 204 */     if (this.logger.isInfoEnabled()) {
/* 205 */       this.logger.info("Adding secure method [" + method + "] with attributes [" + attr + "]");
/*     */     }
/* 207 */     this.methodMap.put(method, attr);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Collection<ConfigAttribute> getAllConfigAttributes() {
/* 216 */     Set<ConfigAttribute> allAttributes = new HashSet<ConfigAttribute>();
/*     */     
/* 218 */     for (List<ConfigAttribute> attributeList : this.methodMap.values()) {
/* 219 */       allAttributes.addAll(attributeList);
/*     */     }
/*     */     
/* 222 */     return allAttributes;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean isMatch(String methodName, String mappedName) {
/* 235 */     return ((mappedName.endsWith("*") && methodName.startsWith(mappedName.substring(0, mappedName.length() - 1))) || (mappedName.startsWith("*") && methodName.endsWith(mappedName.substring(1, mappedName.length()))));
/*     */   }
/*     */ 
/*     */   
/*     */   public void setBeanClassLoader(ClassLoader beanClassLoader) {
/* 240 */     Assert.notNull(beanClassLoader, "Bean class loader required");
/* 241 */     this.beanClassLoader = beanClassLoader;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getMethodMapSize() {
/* 248 */     return this.methodMap.size();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private class RegisteredMethod
/*     */   {
/*     */     private final Method method;
/*     */ 
/*     */     
/*     */     private final Class<?> registeredJavaType;
/*     */ 
/*     */ 
/*     */     
/*     */     public RegisteredMethod(Method method, Class<?> registeredJavaType) {
/* 263 */       Assert.notNull(method, "Method required");
/* 264 */       Assert.notNull(registeredJavaType, "Registered Java Type required");
/* 265 */       this.method = method;
/* 266 */       this.registeredJavaType = registeredJavaType;
/*     */     }
/*     */     
/*     */     public boolean equals(Object obj) {
/* 270 */       if (this == obj) {
/* 271 */         return true;
/*     */       }
/* 273 */       if (obj != null && obj instanceof RegisteredMethod) {
/* 274 */         RegisteredMethod rhs = (RegisteredMethod)obj;
/* 275 */         return (this.method.equals(rhs.method) && this.registeredJavaType.equals(rhs.registeredJavaType));
/*     */       } 
/* 277 */       return false;
/*     */     }
/*     */     
/*     */     public int hashCode() {
/* 281 */       return this.method.hashCode() * this.registeredJavaType.hashCode();
/*     */     }
/*     */     
/*     */     public String toString() {
/* 285 */       return "RegisteredMethod[" + this.registeredJavaType.getName() + "; " + this.method + "]";
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Gcorp\Downloads\spring-security-core-3.2.0.RELEASE.jar!\org\springframework\security\access\method\MapBasedMethodSecurityMetadataSource.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */