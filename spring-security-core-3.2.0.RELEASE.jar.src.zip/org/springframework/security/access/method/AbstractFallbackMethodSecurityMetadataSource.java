/*    */ package org.springframework.security.access.method;
/*    */ 
/*    */ import java.lang.reflect.Method;
/*    */ import java.util.Collection;
/*    */ import java.util.Collections;
/*    */ import org.springframework.aop.support.AopUtils;
/*    */ import org.springframework.security.access.ConfigAttribute;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class AbstractFallbackMethodSecurityMetadataSource
/*    */   extends AbstractMethodSecurityMetadataSource
/*    */ {
/*    */   public Collection<ConfigAttribute> getAttributes(Method method, Class<?> targetClass) {
/* 32 */     Method specificMethod = AopUtils.getMostSpecificMethod(method, targetClass);
/*    */     
/* 34 */     Collection<ConfigAttribute> attr = findAttributes(specificMethod, targetClass);
/* 35 */     if (attr != null) {
/* 36 */       return attr;
/*    */     }
/*    */ 
/*    */     
/* 40 */     attr = findAttributes(specificMethod.getDeclaringClass());
/* 41 */     if (attr != null) {
/* 42 */       return attr;
/*    */     }
/*    */     
/* 45 */     if (specificMethod != method || targetClass == null) {
/*    */       
/* 47 */       attr = findAttributes(method, method.getDeclaringClass());
/* 48 */       if (attr != null) {
/* 49 */         return attr;
/*    */       }
/*    */       
/* 52 */       return findAttributes(method.getDeclaringClass());
/*    */     } 
/* 54 */     return Collections.emptyList();
/*    */   }
/*    */   
/*    */   protected abstract Collection<ConfigAttribute> findAttributes(Method paramMethod, Class<?> paramClass);
/*    */   
/*    */   protected abstract Collection<ConfigAttribute> findAttributes(Class<?> paramClass);
/*    */ }


/* Location:              C:\Users\Gcorp\Downloads\spring-security-core-3.2.0.RELEASE.jar!\org\springframework\security\access\method\AbstractFallbackMethodSecurityMetadataSource.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */