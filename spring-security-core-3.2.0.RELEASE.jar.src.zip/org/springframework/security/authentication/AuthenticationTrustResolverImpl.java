/*    */ package org.springframework.security.authentication;
/*    */ 
/*    */ import org.springframework.security.core.Authentication;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class AuthenticationTrustResolverImpl
/*    */   implements AuthenticationTrustResolver
/*    */ {
/* 34 */   private Class<? extends Authentication> anonymousClass = (Class)AnonymousAuthenticationToken.class;
/* 35 */   private Class<? extends Authentication> rememberMeClass = (Class)RememberMeAuthenticationToken.class;
/*    */ 
/*    */ 
/*    */   
/*    */   Class<? extends Authentication> getAnonymousClass() {
/* 40 */     return this.anonymousClass;
/*    */   }
/*    */   
/*    */   Class<? extends Authentication> getRememberMeClass() {
/* 44 */     return this.rememberMeClass;
/*    */   }
/*    */   
/*    */   public boolean isAnonymous(Authentication authentication) {
/* 48 */     if (this.anonymousClass == null || authentication == null) {
/* 49 */       return false;
/*    */     }
/*    */     
/* 52 */     return this.anonymousClass.isAssignableFrom(authentication.getClass());
/*    */   }
/*    */   
/*    */   public boolean isRememberMe(Authentication authentication) {
/* 56 */     if (this.rememberMeClass == null || authentication == null) {
/* 57 */       return false;
/*    */     }
/*    */     
/* 60 */     return this.rememberMeClass.isAssignableFrom(authentication.getClass());
/*    */   }
/*    */   
/*    */   public void setAnonymousClass(Class<? extends Authentication> anonymousClass) {
/* 64 */     this.anonymousClass = anonymousClass;
/*    */   }
/*    */   
/*    */   public void setRememberMeClass(Class<? extends Authentication> rememberMeClass) {
/* 68 */     this.rememberMeClass = rememberMeClass;
/*    */   }
/*    */ }


/* Location:              C:\Users\Gcorp\Downloads\spring-security-core-3.2.0.RELEASE.jar!\org\springframework\security\authentication\AuthenticationTrustResolverImpl.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */