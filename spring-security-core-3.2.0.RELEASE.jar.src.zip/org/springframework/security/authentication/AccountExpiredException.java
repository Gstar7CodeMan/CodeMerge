/*    */ package org.springframework.security.authentication;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class AccountExpiredException
/*    */   extends AccountStatusException
/*    */ {
/*    */   public AccountExpiredException(String msg) {
/* 34 */     super(msg);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public AccountExpiredException(String msg, Throwable t) {
/* 45 */     super(msg, t);
/*    */   }
/*    */   
/*    */   @Deprecated
/*    */   public AccountExpiredException(String msg, Object extraInformation) {
/* 50 */     super(msg, extraInformation);
/*    */   }
/*    */ }


/* Location:              C:\Users\Gcorp\Downloads\spring-security-core-3.2.0.RELEASE.jar!\org\springframework\security\authentication\AccountExpiredException.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */