/*     */ package org.springframework.security.authentication;
/*     */ 
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.beans.factory.InitializingBean;
/*     */ import org.springframework.context.MessageSource;
/*     */ import org.springframework.context.MessageSourceAware;
/*     */ import org.springframework.context.support.MessageSourceAccessor;
/*     */ import org.springframework.security.core.Authentication;
/*     */ import org.springframework.security.core.AuthenticationException;
/*     */ import org.springframework.security.core.CredentialsContainer;
/*     */ import org.springframework.security.core.SpringSecurityMessageSource;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ProviderManager
/*     */   implements AuthenticationManager, MessageSourceAware, InitializingBean
/*     */ {
/*  80 */   private static final Log logger = LogFactory.getLog(ProviderManager.class);
/*     */ 
/*     */ 
/*     */   
/*  84 */   private AuthenticationEventPublisher eventPublisher = new NullEventPublisher();
/*  85 */   private List<AuthenticationProvider> providers = Collections.emptyList();
/*  86 */   protected MessageSourceAccessor messages = SpringSecurityMessageSource.getAccessor();
/*     */   
/*     */   private AuthenticationManager parent;
/*     */   
/*     */   private boolean eraseCredentialsAfterAuthentication = true;
/*     */   
/*     */   private boolean clearExtraInformation = false;
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public ProviderManager() {}
/*     */   
/*     */   public ProviderManager(List<AuthenticationProvider> providers) {
/*  99 */     this(providers, null);
/*     */   }
/*     */   
/*     */   public ProviderManager(List<AuthenticationProvider> providers, AuthenticationManager parent) {
/* 103 */     Assert.notNull(providers, "providers list cannot be null");
/* 104 */     this.providers = providers;
/* 105 */     this.parent = parent;
/* 106 */     checkState();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void afterPropertiesSet() throws Exception {
/* 112 */     checkState();
/*     */   }
/*     */   
/*     */   private void checkState() {
/* 116 */     if (this.parent == null && this.providers.isEmpty()) {
/* 117 */       throw new IllegalArgumentException("A parent AuthenticationManager or a list of AuthenticationProviders is required");
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Authentication authenticate(Authentication authentication) throws AuthenticationException {
/* 141 */     Class<? extends Authentication> toTest = (Class)authentication.getClass();
/* 142 */     AuthenticationException lastException = null;
/* 143 */     Authentication result = null;
/* 144 */     boolean debug = logger.isDebugEnabled();
/*     */     
/* 146 */     for (AuthenticationProvider provider : getProviders()) {
/* 147 */       if (!provider.supports(toTest)) {
/*     */         continue;
/*     */       }
/*     */       
/* 151 */       if (debug) {
/* 152 */         logger.debug("Authentication attempt using " + provider.getClass().getName());
/*     */       }
/*     */       
/*     */       try {
/* 156 */         result = provider.authenticate(authentication);
/*     */         
/* 158 */         if (result != null) {
/* 159 */           copyDetails(authentication, result);
/*     */           break;
/*     */         } 
/* 162 */       } catch (AccountStatusException e) {
/* 163 */         prepareException(e, authentication);
/*     */         
/* 165 */         throw e;
/* 166 */       } catch (InternalAuthenticationServiceException e) {
/* 167 */         prepareException(e, authentication);
/* 168 */         throw e;
/* 169 */       } catch (AuthenticationException e) {
/* 170 */         lastException = e;
/*     */       } 
/*     */     } 
/*     */     
/* 174 */     if (result == null && this.parent != null) {
/*     */       
/*     */       try {
/* 177 */         result = this.parent.authenticate(authentication);
/* 178 */       } catch (ProviderNotFoundException e) {
/*     */ 
/*     */       
/* 181 */       } catch (AuthenticationException e) {
/* 182 */         lastException = e;
/*     */       } 
/*     */     }
/*     */     
/* 186 */     if (result != null) {
/* 187 */       if (this.eraseCredentialsAfterAuthentication && result instanceof CredentialsContainer)
/*     */       {
/* 189 */         ((CredentialsContainer)result).eraseCredentials();
/*     */       }
/*     */       
/* 192 */       this.eventPublisher.publishAuthenticationSuccess(result);
/* 193 */       return result;
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 198 */     if (lastException == null) {
/* 199 */       lastException = new ProviderNotFoundException(this.messages.getMessage("ProviderManager.providerNotFound", new Object[] { toTest.getName() }, "No AuthenticationProvider found for {0}"));
/*     */     }
/*     */ 
/*     */     
/* 203 */     prepareException(lastException, authentication);
/*     */     
/* 205 */     throw lastException;
/*     */   }
/*     */ 
/*     */   
/*     */   private void prepareException(AuthenticationException ex, Authentication auth) {
/* 210 */     this.eventPublisher.publishAuthenticationFailure(ex, auth);
/* 211 */     ex.setAuthentication(auth);
/*     */     
/* 213 */     if (this.clearExtraInformation) {
/* 214 */       ex.clearExtraInformation();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void copyDetails(Authentication source, Authentication dest) {
/* 226 */     if (dest instanceof AbstractAuthenticationToken && dest.getDetails() == null) {
/* 227 */       AbstractAuthenticationToken token = (AbstractAuthenticationToken)dest;
/*     */       
/* 229 */       token.setDetails(source.getDetails());
/*     */     } 
/*     */   }
/*     */   
/*     */   public List<AuthenticationProvider> getProviders() {
/* 234 */     return this.providers;
/*     */   }
/*     */   
/*     */   public void setMessageSource(MessageSource messageSource) {
/* 238 */     this.messages = new MessageSourceAccessor(messageSource);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public void setParent(AuthenticationManager parent) {
/* 246 */     this.parent = parent;
/*     */   }
/*     */   
/*     */   public void setAuthenticationEventPublisher(AuthenticationEventPublisher eventPublisher) {
/* 250 */     Assert.notNull(eventPublisher, "AuthenticationEventPublisher cannot be null");
/* 251 */     this.eventPublisher = eventPublisher;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setEraseCredentialsAfterAuthentication(boolean eraseSecretData) {
/* 263 */     this.eraseCredentialsAfterAuthentication = eraseSecretData;
/*     */   }
/*     */   
/*     */   public boolean isEraseCredentialsAfterAuthentication() {
/* 267 */     return this.eraseCredentialsAfterAuthentication;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public void setProviders(List<AuthenticationProvider> providers) {
/* 282 */     Assert.notNull(providers, "Providers list cannot be null");
/* 283 */     for (Object currentObject : providers) {
/* 284 */       Assert.isInstanceOf(AuthenticationProvider.class, currentObject, "Can only provide AuthenticationProvider instances");
/*     */     }
/*     */     
/* 287 */     this.providers = providers;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public void setClearExtraInformation(boolean clearExtraInformation) {
/* 300 */     this.clearExtraInformation = clearExtraInformation;
/*     */   }
/*     */   
/*     */   private static final class NullEventPublisher implements AuthenticationEventPublisher {
/*     */     private NullEventPublisher() {}
/*     */     
/*     */     public void publishAuthenticationFailure(AuthenticationException exception, Authentication authentication) {}
/*     */     
/*     */     public void publishAuthenticationSuccess(Authentication authentication) {}
/*     */   }
/*     */ }


/* Location:              C:\Users\Gcorp\Downloads\spring-security-core-3.2.0.RELEASE.jar!\org\springframework\security\authentication\ProviderManager.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */