/*    */ package org.springframework.security.authentication;
/*    */ 
/*    */ import java.lang.reflect.Constructor;
/*    */ import org.springframework.util.Assert;
/*    */ import org.springframework.util.ReflectionUtils;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Deprecated
/*    */ public class AuthenticationDetailsSourceImpl
/*    */   implements AuthenticationDetailsSource<Object, Object>
/*    */ {
/* 24 */   private Class<?> clazz = AuthenticationDetails.class;
/*    */ 
/*    */ 
/*    */   
/*    */   public Object buildDetails(Object context) {
/* 29 */     Object result = null;
/*    */     try {
/* 31 */       Constructor<?> constructor = getFirstMatchingConstructor(context);
/* 32 */       result = constructor.newInstance(new Object[] { context });
/* 33 */     } catch (Exception ex) {
/* 34 */       ReflectionUtils.handleReflectionException(ex);
/*    */     } 
/*    */     
/* 37 */     return result;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   private Constructor<?> getFirstMatchingConstructor(Object object) throws NoSuchMethodException {
/* 52 */     Constructor[] arrayOfConstructor = (Constructor[])this.clazz.getDeclaredConstructors();
/* 53 */     Constructor<?> constructor = null;
/* 54 */     for (Constructor<?> tryMe : arrayOfConstructor) {
/* 55 */       Class<?>[] parameterTypes = tryMe.getParameterTypes();
/* 56 */       if (parameterTypes.length == 1 && (object == null || parameterTypes[0].isInstance(object))) {
/* 57 */         constructor = tryMe;
/*    */         
/*    */         break;
/*    */       } 
/*    */     } 
/* 62 */     if (constructor == null) {
/* 63 */       if (object == null) {
/* 64 */         throw new NoSuchMethodException("No constructor found that can take a single argument");
/*    */       }
/* 66 */       throw new NoSuchMethodException("No constructor found that can take a single argument of type " + object.getClass());
/*    */     } 
/*    */     
/* 69 */     return constructor;
/*    */   }
/*    */   
/*    */   public void setClazz(Class<?> clazz) {
/* 73 */     Assert.notNull(clazz, "Class required");
/* 74 */     this.clazz = clazz;
/*    */   }
/*    */ }


/* Location:              C:\Users\Gcorp\Downloads\spring-security-core-3.2.0.RELEASE.jar!\org\springframework\security\authentication\AuthenticationDetailsSourceImpl.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */