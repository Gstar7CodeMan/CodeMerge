/*    */ package org.springframework.security.authentication;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class InternalAuthenticationServiceException
/*    */   extends AuthenticationServiceException
/*    */ {
/*    */   public InternalAuthenticationServiceException(String message, Throwable cause) {
/* 34 */     super(message, cause);
/*    */   }
/*    */   
/*    */   public InternalAuthenticationServiceException(String message) {
/* 38 */     super(message);
/*    */   }
/*    */ }


/* Location:              C:\Users\Gcorp\Downloads\spring-security-core-3.2.0.RELEASE.jar!\org\springframework\security\authentication\InternalAuthenticationServiceException.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */