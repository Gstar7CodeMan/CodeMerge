package org.springframework.security.authentication.jaas;

import java.security.Principal;
import java.util.Set;

public interface AuthorityGranter {
  Set<String> grant(Principal paramPrincipal);
}


/* Location:              C:\Users\Gcorp\Downloads\spring-security-core-3.2.0.RELEASE.jar!\org\springframework\security\authentication\jaas\AuthorityGranter.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */