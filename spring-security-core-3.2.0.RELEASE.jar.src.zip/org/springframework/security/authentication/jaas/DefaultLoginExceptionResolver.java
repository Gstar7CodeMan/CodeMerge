/*    */ package org.springframework.security.authentication.jaas;
/*    */ 
/*    */ import javax.security.auth.login.LoginException;
/*    */ import org.springframework.security.authentication.AuthenticationServiceException;
/*    */ import org.springframework.security.core.AuthenticationException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DefaultLoginExceptionResolver
/*    */   implements LoginExceptionResolver
/*    */ {
/*    */   public AuthenticationException resolveException(LoginException e) {
/* 33 */     return (AuthenticationException)new AuthenticationServiceException(e.getMessage(), e);
/*    */   }
/*    */ }


/* Location:              C:\Users\Gcorp\Downloads\spring-security-core-3.2.0.RELEASE.jar!\org\springframework\security\authentication\jaas\DefaultLoginExceptionResolver.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */