/*    */ package org.springframework.security.authentication.jaas.memory;
/*    */ 
/*    */ import java.util.Collections;
/*    */ import java.util.Map;
/*    */ import javax.security.auth.login.AppConfigurationEntry;
/*    */ import javax.security.auth.login.Configuration;
/*    */ import org.springframework.util.Assert;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class InMemoryConfiguration
/*    */   extends Configuration
/*    */ {
/*    */   private final AppConfigurationEntry[] defaultConfiguration;
/*    */   private final Map<String, AppConfigurationEntry[]> mappedConfigurations;
/*    */   
/*    */   public InMemoryConfiguration(AppConfigurationEntry[] defaultConfiguration) {
/* 55 */     this((Map)Collections.emptyMap(), defaultConfiguration);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public InMemoryConfiguration(Map<String, AppConfigurationEntry[]> mappedConfigurations) {
/* 67 */     this(mappedConfigurations, null);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public InMemoryConfiguration(Map<String, AppConfigurationEntry[]> mappedConfigurations, AppConfigurationEntry[] defaultConfiguration) {
/* 84 */     Assert.notNull(mappedConfigurations, "mappedConfigurations cannot be null.");
/* 85 */     this.mappedConfigurations = mappedConfigurations;
/* 86 */     this.defaultConfiguration = defaultConfiguration;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public AppConfigurationEntry[] getAppConfigurationEntry(String name) {
/* 93 */     AppConfigurationEntry[] mappedResult = this.mappedConfigurations.get(name);
/* 94 */     return (mappedResult == null) ? this.defaultConfiguration : mappedResult;
/*    */   }
/*    */   
/*    */   public void refresh() {}
/*    */ }


/* Location:              C:\Users\Gcorp\Downloads\spring-security-core-3.2.0.RELEASE.jar!\org\springframework\security\authentication\jaas\memory\InMemoryConfiguration.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */