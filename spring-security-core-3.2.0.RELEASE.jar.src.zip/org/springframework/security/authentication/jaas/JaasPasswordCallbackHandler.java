/*    */ package org.springframework.security.authentication.jaas;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import javax.security.auth.callback.Callback;
/*    */ import javax.security.auth.callback.PasswordCallback;
/*    */ import javax.security.auth.callback.UnsupportedCallbackException;
/*    */ import org.springframework.security.core.Authentication;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class JaasPasswordCallbackHandler
/*    */   implements JaasAuthenticationCallbackHandler
/*    */ {
/*    */   public void handle(Callback callback, Authentication auth) throws IOException, UnsupportedCallbackException {
/* 53 */     if (callback instanceof PasswordCallback) {
/* 54 */       PasswordCallback pc = (PasswordCallback)callback;
/* 55 */       pc.setPassword(auth.getCredentials().toString().toCharArray());
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\Gcorp\Downloads\spring-security-core-3.2.0.RELEASE.jar!\org\springframework\security\authentication\jaas\JaasPasswordCallbackHandler.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */