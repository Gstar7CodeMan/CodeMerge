/*     */ package org.springframework.security.authentication.jaas;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.net.URL;
/*     */ import java.security.Security;
/*     */ import javax.security.auth.callback.CallbackHandler;
/*     */ import javax.security.auth.login.Configuration;
/*     */ import javax.security.auth.login.LoginContext;
/*     */ import javax.security.auth.login.LoginException;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.context.ApplicationEvent;
/*     */ import org.springframework.core.io.Resource;
/*     */ import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
/*     */ import org.springframework.security.authentication.jaas.event.JaasAuthenticationFailedEvent;
/*     */ import org.springframework.security.core.Authentication;
/*     */ import org.springframework.security.core.AuthenticationException;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class JaasAuthenticationProvider
/*     */   extends AbstractJaasAuthenticationProvider
/*     */ {
/* 119 */   protected static final Log log = LogFactory.getLog(JaasAuthenticationProvider.class);
/*     */ 
/*     */   
/*     */   private Resource loginConfig;
/*     */ 
/*     */   
/*     */   private boolean refreshConfigurationOnStartup = true;
/*     */ 
/*     */ 
/*     */   
/*     */   public void afterPropertiesSet() throws Exception {
/* 130 */     Assert.hasLength(getLoginContextName(), "loginContextName must be set on " + getClass());
/* 131 */     Assert.notNull(this.loginConfig, "loginConfig must be set on " + getClass());
/* 132 */     configureJaas(this.loginConfig);
/*     */     
/* 134 */     Assert.notNull(Configuration.getConfiguration(), "As per http://java.sun.com/j2se/1.5.0/docs/api/javax/security/auth/login/Configuration.html \"If a Configuration object was set via the Configuration.setConfiguration method, then that object is returned. Otherwise, a default Configuration object is returned\". Your JRE returned null to Configuration.getConfiguration().");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected LoginContext createLoginContext(CallbackHandler handler) throws LoginException {
/* 144 */     return new LoginContext(getLoginContextName(), handler);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void configureJaas(Resource loginConfig) throws IOException {
/* 155 */     configureJaasUsingLoop();
/*     */     
/* 157 */     if (this.refreshConfigurationOnStartup)
/*     */     {
/* 159 */       Configuration.getConfiguration().refresh();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void configureJaasUsingLoop() throws IOException {
/* 169 */     String loginConfigUrl = convertLoginConfigToUrl();
/* 170 */     boolean alreadySet = false;
/*     */     
/* 172 */     int n = 1;
/* 173 */     String prefix = "login.config.url.";
/*     */     
/*     */     String existing;
/* 176 */     while ((existing = Security.getProperty("login.config.url." + n)) != null) {
/* 177 */       alreadySet = existing.equals(loginConfigUrl);
/*     */       
/* 179 */       if (alreadySet) {
/*     */         break;
/*     */       }
/*     */       
/* 183 */       n++;
/*     */     } 
/*     */     
/* 186 */     if (!alreadySet) {
/* 187 */       String key = "login.config.url." + n;
/* 188 */       log.debug("Setting security property [" + key + "] to: " + loginConfigUrl);
/* 189 */       Security.setProperty(key, loginConfigUrl);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private String convertLoginConfigToUrl() throws IOException {
/*     */     try {
/* 197 */       String loginConfigPath = this.loginConfig.getFile().getAbsolutePath().replace(File.separatorChar, '/');
/*     */       
/* 199 */       if (!loginConfigPath.startsWith("/")) {
/* 200 */         loginConfigPath = "/" + loginConfigPath;
/*     */       }
/*     */       
/* 203 */       return (new URL("file", "", loginConfigPath)).toString();
/* 204 */     } catch (IOException e) {
/*     */       
/* 206 */       return this.loginConfig.getURL().toString();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void publishFailureEvent(UsernamePasswordAuthenticationToken token, AuthenticationException ase) {
/* 219 */     getApplicationEventPublisher().publishEvent((ApplicationEvent)new JaasAuthenticationFailedEvent((Authentication)token, (Exception)ase));
/*     */   }
/*     */   
/*     */   public Resource getLoginConfig() {
/* 223 */     return this.loginConfig;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setLoginConfig(Resource loginConfig) {
/* 234 */     this.loginConfig = loginConfig;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setRefreshConfigurationOnStartup(boolean refresh) {
/* 247 */     this.refreshConfigurationOnStartup = refresh;
/*     */   }
/*     */ }


/* Location:              C:\Users\Gcorp\Downloads\spring-security-core-3.2.0.RELEASE.jar!\org\springframework\security\authentication\jaas\JaasAuthenticationProvider.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */