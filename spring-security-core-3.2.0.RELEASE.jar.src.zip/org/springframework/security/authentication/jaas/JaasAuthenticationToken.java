/*    */ package org.springframework.security.authentication.jaas;
/*    */ 
/*    */ import java.util.List;
/*    */ import javax.security.auth.login.LoginContext;
/*    */ import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
/*    */ import org.springframework.security.core.GrantedAuthority;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class JaasAuthenticationToken
/*    */   extends UsernamePasswordAuthenticationToken
/*    */ {
/*    */   private static final long serialVersionUID = 320L;
/*    */   private final transient LoginContext loginContext;
/*    */   
/*    */   public JaasAuthenticationToken(Object principal, Object credentials, LoginContext loginContext) {
/* 44 */     super(principal, credentials);
/* 45 */     this.loginContext = loginContext;
/*    */   }
/*    */ 
/*    */   
/*    */   public JaasAuthenticationToken(Object principal, Object credentials, List<GrantedAuthority> authorities, LoginContext loginContext) {
/* 50 */     super(principal, credentials, authorities);
/* 51 */     this.loginContext = loginContext;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public LoginContext getLoginContext() {
/* 57 */     return this.loginContext;
/*    */   }
/*    */ }


/* Location:              C:\Users\Gcorp\Downloads\spring-security-core-3.2.0.RELEASE.jar!\org\springframework\security\authentication\jaas\JaasAuthenticationToken.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */