/*    */ package org.springframework.security.authentication.jaas.event;
/*    */ 
/*    */ import org.springframework.context.ApplicationEvent;
/*    */ import org.springframework.security.core.Authentication;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class JaasAuthenticationEvent
/*    */   extends ApplicationEvent
/*    */ {
/*    */   public JaasAuthenticationEvent(Authentication auth) {
/* 38 */     super(auth);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Authentication getAuthentication() {
/* 49 */     return (Authentication)this.source;
/*    */   }
/*    */ }


/* Location:              C:\Users\Gcorp\Downloads\spring-security-core-3.2.0.RELEASE.jar!\org\springframework\security\authentication\jaas\event\JaasAuthenticationEvent.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */