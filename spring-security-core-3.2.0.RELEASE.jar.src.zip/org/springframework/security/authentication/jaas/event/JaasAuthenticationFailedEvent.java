/*    */ package org.springframework.security.authentication.jaas.event;
/*    */ 
/*    */ import org.springframework.security.core.Authentication;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class JaasAuthenticationFailedEvent
/*    */   extends JaasAuthenticationEvent
/*    */ {
/*    */   private final Exception exception;
/*    */   
/*    */   public JaasAuthenticationFailedEvent(Authentication auth, Exception exception) {
/* 34 */     super(auth);
/* 35 */     this.exception = exception;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public Exception getException() {
/* 41 */     return this.exception;
/*    */   }
/*    */ }


/* Location:              C:\Users\Gcorp\Downloads\spring-security-core-3.2.0.RELEASE.jar!\org\springframework\security\authentication\jaas\event\JaasAuthenticationFailedEvent.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */