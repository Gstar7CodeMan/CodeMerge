/*     */ package org.springframework.security.authentication.jaas;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.security.Principal;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashSet;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ import javax.security.auth.callback.Callback;
/*     */ import javax.security.auth.callback.CallbackHandler;
/*     */ import javax.security.auth.callback.UnsupportedCallbackException;
/*     */ import javax.security.auth.login.LoginContext;
/*     */ import javax.security.auth.login.LoginException;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.beans.factory.InitializingBean;
/*     */ import org.springframework.context.ApplicationEvent;
/*     */ import org.springframework.context.ApplicationEventPublisher;
/*     */ import org.springframework.context.ApplicationEventPublisherAware;
/*     */ import org.springframework.context.ApplicationListener;
/*     */ import org.springframework.security.authentication.AuthenticationProvider;
/*     */ import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
/*     */ import org.springframework.security.authentication.jaas.event.JaasAuthenticationFailedEvent;
/*     */ import org.springframework.security.authentication.jaas.event.JaasAuthenticationSuccessEvent;
/*     */ import org.springframework.security.core.Authentication;
/*     */ import org.springframework.security.core.AuthenticationException;
/*     */ import org.springframework.security.core.GrantedAuthority;
/*     */ import org.springframework.security.core.context.SecurityContext;
/*     */ import org.springframework.security.core.session.SessionDestroyedEvent;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ObjectUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AbstractJaasAuthenticationProvider
/*     */   implements AuthenticationProvider, ApplicationEventPublisherAware, InitializingBean, ApplicationListener<SessionDestroyedEvent>
/*     */ {
/*     */   private ApplicationEventPublisher applicationEventPublisher;
/*     */   private AuthorityGranter[] authorityGranters;
/*     */   private JaasAuthenticationCallbackHandler[] callbackHandlers;
/* 103 */   protected final Log log = LogFactory.getLog(getClass());
/* 104 */   private LoginExceptionResolver loginExceptionResolver = new DefaultLoginExceptionResolver();
/* 105 */   private String loginContextName = "SPRINGSECURITY";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void afterPropertiesSet() throws Exception {
/* 116 */     Assert.hasLength(this.loginContextName, "loginContextName cannot be null or empty");
/* 117 */     Assert.notEmpty((Object[])this.authorityGranters, "authorityGranters cannot be null or empty");
/* 118 */     if (ObjectUtils.isEmpty((Object[])this.callbackHandlers)) {
/* 119 */       setCallbackHandlers(new JaasAuthenticationCallbackHandler[] { new JaasNameCallbackHandler(), new JaasPasswordCallbackHandler() });
/*     */     }
/*     */     
/* 122 */     Assert.notNull(this.loginExceptionResolver, "loginExceptionResolver cannot be null");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Authentication authenticate(Authentication auth) throws AuthenticationException {
/* 137 */     if (!(auth instanceof UsernamePasswordAuthenticationToken)) {
/* 138 */       return null;
/*     */     }
/*     */     
/* 141 */     UsernamePasswordAuthenticationToken request = (UsernamePasswordAuthenticationToken)auth;
/*     */ 
/*     */ 
/*     */     
/*     */     try {
/* 146 */       LoginContext loginContext = createLoginContext(new InternalCallbackHandler(auth));
/*     */ 
/*     */       
/* 149 */       loginContext.login();
/*     */ 
/*     */       
/* 152 */       Set<GrantedAuthority> authorities = new HashSet<GrantedAuthority>();
/*     */ 
/*     */       
/* 155 */       Set<Principal> principals = loginContext.getSubject().getPrincipals();
/*     */       
/* 157 */       for (Principal principal : principals) {
/* 158 */         for (AuthorityGranter granter : this.authorityGranters) {
/* 159 */           Set<String> roles = granter.grant(principal);
/*     */ 
/*     */           
/* 162 */           if (roles != null && !roles.isEmpty()) {
/* 163 */             for (String role : roles) {
/* 164 */               authorities.add(new JaasGrantedAuthority(role, principal));
/*     */             }
/*     */           }
/*     */         } 
/*     */       } 
/*     */ 
/*     */       
/* 171 */       JaasAuthenticationToken result = new JaasAuthenticationToken(request.getPrincipal(), request.getCredentials(), new ArrayList<GrantedAuthority>(authorities), loginContext);
/*     */ 
/*     */ 
/*     */       
/* 175 */       publishSuccessEvent(result);
/*     */ 
/*     */       
/* 178 */       return (Authentication)result;
/*     */     }
/* 180 */     catch (LoginException loginException) {
/* 181 */       AuthenticationException ase = this.loginExceptionResolver.resolveException(loginException);
/*     */       
/* 183 */       publishFailureEvent(request, ase);
/* 184 */       throw ase;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void handleLogout(SessionDestroyedEvent event) {
/* 205 */     List<SecurityContext> contexts = event.getSecurityContexts();
/*     */     
/* 207 */     if (contexts.isEmpty()) {
/* 208 */       this.log.debug("The destroyed session has no SecurityContexts");
/*     */       
/*     */       return;
/*     */     } 
/*     */     
/* 213 */     for (SecurityContext context : contexts) {
/* 214 */       Authentication auth = context.getAuthentication();
/*     */       
/* 216 */       if (auth != null && auth instanceof JaasAuthenticationToken) {
/* 217 */         JaasAuthenticationToken token = (JaasAuthenticationToken)auth;
/*     */         
/*     */         try {
/* 220 */           LoginContext loginContext = token.getLoginContext();
/* 221 */           boolean debug = this.log.isDebugEnabled();
/* 222 */           if (loginContext != null) {
/* 223 */             if (debug) {
/* 224 */               this.log.debug("Logging principal: [" + token.getPrincipal() + "] out of LoginContext");
/*     */             }
/* 226 */             loginContext.logout(); continue;
/* 227 */           }  if (debug) {
/* 228 */             this.log.debug("Cannot logout principal: [" + token.getPrincipal() + "] from LoginContext. " + "The LoginContext is unavailable");
/*     */           }
/*     */         }
/* 231 */         catch (LoginException e) {
/* 232 */           this.log.warn("Error error logging out of LoginContext", e);
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   public void onApplicationEvent(SessionDestroyedEvent event) {
/* 239 */     handleLogout(event);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void publishFailureEvent(UsernamePasswordAuthenticationToken token, AuthenticationException ase) {
/* 250 */     if (this.applicationEventPublisher != null) {
/* 251 */       this.applicationEventPublisher.publishEvent((ApplicationEvent)new JaasAuthenticationFailedEvent((Authentication)token, (Exception)ase));
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void publishSuccessEvent(UsernamePasswordAuthenticationToken token) {
/* 262 */     if (this.applicationEventPublisher != null) {
/* 263 */       this.applicationEventPublisher.publishEvent((ApplicationEvent)new JaasAuthenticationSuccessEvent((Authentication)token));
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   AuthorityGranter[] getAuthorityGranters() {
/* 276 */     return this.authorityGranters;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setAuthorityGranters(AuthorityGranter[] authorityGranters) {
/* 287 */     this.authorityGranters = authorityGranters;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   JaasAuthenticationCallbackHandler[] getCallbackHandlers() {
/* 298 */     return this.callbackHandlers;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setCallbackHandlers(JaasAuthenticationCallbackHandler[] callbackHandlers) {
/* 308 */     this.callbackHandlers = callbackHandlers;
/*     */   }
/*     */   
/*     */   String getLoginContextName() {
/* 312 */     return this.loginContextName;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setLoginContextName(String loginContextName) {
/* 322 */     this.loginContextName = loginContextName;
/*     */   }
/*     */   
/*     */   LoginExceptionResolver getLoginExceptionResolver() {
/* 326 */     return this.loginExceptionResolver;
/*     */   }
/*     */   
/*     */   public void setLoginExceptionResolver(LoginExceptionResolver loginExceptionResolver) {
/* 330 */     this.loginExceptionResolver = loginExceptionResolver;
/*     */   }
/*     */   
/*     */   public boolean supports(Class<?> aClass) {
/* 334 */     return UsernamePasswordAuthenticationToken.class.isAssignableFrom(aClass);
/*     */   }
/*     */   
/*     */   public void setApplicationEventPublisher(ApplicationEventPublisher applicationEventPublisher) {
/* 338 */     this.applicationEventPublisher = applicationEventPublisher;
/*     */   }
/*     */   
/*     */   protected ApplicationEventPublisher getApplicationEventPublisher() {
/* 342 */     return this.applicationEventPublisher;
/*     */   }
/*     */ 
/*     */   
/*     */   protected abstract LoginContext createLoginContext(CallbackHandler paramCallbackHandler) throws LoginException;
/*     */   
/*     */   private class InternalCallbackHandler
/*     */     implements CallbackHandler
/*     */   {
/*     */     private final Authentication authentication;
/*     */     
/*     */     public InternalCallbackHandler(Authentication authentication) {
/* 354 */       this.authentication = authentication;
/*     */     }
/*     */     
/*     */     public void handle(Callback[] callbacks) throws IOException, UnsupportedCallbackException {
/* 358 */       for (JaasAuthenticationCallbackHandler handler : AbstractJaasAuthenticationProvider.this.callbackHandlers) {
/* 359 */         for (Callback callback : callbacks)
/* 360 */           handler.handle(callback, this.authentication); 
/*     */       } 
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Gcorp\Downloads\spring-security-core-3.2.0.RELEASE.jar!\org\springframework\security\authentication\jaas\AbstractJaasAuthenticationProvider.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */