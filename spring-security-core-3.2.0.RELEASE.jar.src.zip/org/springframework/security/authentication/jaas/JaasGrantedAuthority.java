/*    */ package org.springframework.security.authentication.jaas;
/*    */ 
/*    */ import java.security.Principal;
/*    */ import org.springframework.security.core.GrantedAuthority;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class JaasGrantedAuthority
/*    */   implements GrantedAuthority
/*    */ {
/*    */   private static final long serialVersionUID = 320L;
/*    */   private final String role;
/*    */   private final Principal principal;
/*    */   
/*    */   public JaasGrantedAuthority(String role, Principal principal) {
/* 40 */     this.role = role;
/* 41 */     this.principal = principal;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public Principal getPrincipal() {
/* 47 */     return this.principal;
/*    */   }
/*    */   
/*    */   public String getAuthority() {
/* 51 */     return this.role;
/*    */   }
/*    */   
/*    */   public int hashCode() {
/* 55 */     return 0x1F ^ this.principal.hashCode() ^ this.role.hashCode();
/*    */   }
/*    */   
/*    */   public boolean equals(Object obj) {
/* 59 */     if (this == obj) {
/* 60 */       return true;
/*    */     }
/*    */     
/* 63 */     if (obj instanceof JaasGrantedAuthority) {
/* 64 */       JaasGrantedAuthority jga = (JaasGrantedAuthority)obj;
/* 65 */       return (this.role.equals(jga.role) && this.principal.equals(jga.principal));
/*    */     } 
/*    */     
/* 68 */     return false;
/*    */   }
/*    */   
/*    */   public String toString() {
/* 72 */     return "Jaas Authority [" + this.role + "," + this.principal + "]";
/*    */   }
/*    */ }


/* Location:              C:\Users\Gcorp\Downloads\spring-security-core-3.2.0.RELEASE.jar!\org\springframework\security\authentication\jaas\JaasGrantedAuthority.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */