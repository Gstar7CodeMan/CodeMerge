package org.springframework.security.authentication.jaas;

import java.io.IOException;
import javax.security.auth.callback.Callback;
import javax.security.auth.callback.UnsupportedCallbackException;
import org.springframework.security.core.Authentication;

public interface JaasAuthenticationCallbackHandler {
  void handle(Callback paramCallback, Authentication paramAuthentication) throws IOException, UnsupportedCallbackException;
}


/* Location:              C:\Users\Gcorp\Downloads\spring-security-core-3.2.0.RELEASE.jar!\org\springframework\security\authentication\jaas\JaasAuthenticationCallbackHandler.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */