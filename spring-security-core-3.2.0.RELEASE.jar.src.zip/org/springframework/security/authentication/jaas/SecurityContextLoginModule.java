/*     */ package org.springframework.security.authentication.jaas;
/*     */ 
/*     */ import java.util.Map;
/*     */ import javax.security.auth.Subject;
/*     */ import javax.security.auth.callback.CallbackHandler;
/*     */ import javax.security.auth.login.LoginException;
/*     */ import javax.security.auth.spi.LoginModule;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.security.core.Authentication;
/*     */ import org.springframework.security.core.context.SecurityContextHolder;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SecurityContextLoginModule
/*     */   implements LoginModule
/*     */ {
/*  54 */   private static final Log log = LogFactory.getLog(SecurityContextLoginModule.class);
/*     */ 
/*     */ 
/*     */   
/*     */   private Authentication authen;
/*     */ 
/*     */ 
/*     */   
/*     */   private Subject subject;
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean ignoreMissingAuthentication = false;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean abort() throws LoginException {
/*  72 */     if (this.authen == null) {
/*  73 */       return false;
/*     */     }
/*     */     
/*  76 */     this.authen = null;
/*     */     
/*  78 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean commit() throws LoginException {
/*  90 */     if (this.authen == null) {
/*  91 */       return false;
/*     */     }
/*     */     
/*  94 */     this.subject.getPrincipals().add(this.authen);
/*     */     
/*  96 */     return true;
/*     */   }
/*     */   
/*     */   Authentication getAuthentication() {
/* 100 */     return this.authen;
/*     */   }
/*     */   
/*     */   Subject getSubject() {
/* 104 */     return this.subject;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void initialize(Subject subject, CallbackHandler callbackHandler, Map sharedState, Map options) {
/* 119 */     this.subject = subject;
/*     */     
/* 121 */     if (options != null) {
/* 122 */       this.ignoreMissingAuthentication = "true".equals(options.get("ignoreMissingAuthentication"));
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean login() throws LoginException {
/* 135 */     this.authen = SecurityContextHolder.getContext().getAuthentication();
/*     */     
/* 137 */     if (this.authen == null) {
/* 138 */       String msg = "Login cannot complete, authentication not found in security context";
/*     */       
/* 140 */       if (this.ignoreMissingAuthentication) {
/* 141 */         log.warn(msg);
/*     */         
/* 143 */         return false;
/*     */       } 
/* 145 */       throw new LoginException(msg);
/*     */     } 
/*     */ 
/*     */     
/* 149 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean logout() throws LoginException {
/* 160 */     if (this.authen == null) {
/* 161 */       return false;
/*     */     }
/*     */     
/* 164 */     this.subject.getPrincipals().remove(this.authen);
/* 165 */     this.authen = null;
/*     */     
/* 167 */     return true;
/*     */   }
/*     */ }


/* Location:              C:\Users\Gcorp\Downloads\spring-security-core-3.2.0.RELEASE.jar!\org\springframework\security\authentication\jaas\SecurityContextLoginModule.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */