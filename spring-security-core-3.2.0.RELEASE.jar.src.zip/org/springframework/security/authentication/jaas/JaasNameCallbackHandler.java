/*    */ package org.springframework.security.authentication.jaas;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import javax.security.auth.callback.Callback;
/*    */ import javax.security.auth.callback.NameCallback;
/*    */ import javax.security.auth.callback.UnsupportedCallbackException;
/*    */ import org.springframework.security.core.Authentication;
/*    */ import org.springframework.security.core.userdetails.UserDetails;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class JaasNameCallbackHandler
/*    */   implements JaasAuthenticationCallbackHandler
/*    */ {
/*    */   public void handle(Callback callback, Authentication authentication) throws IOException, UnsupportedCallbackException {
/* 55 */     if (callback instanceof NameCallback) {
/* 56 */       String username; NameCallback ncb = (NameCallback)callback;
/*    */ 
/*    */       
/* 59 */       Object principal = authentication.getPrincipal();
/*    */       
/* 61 */       if (principal instanceof UserDetails) {
/* 62 */         username = ((UserDetails)principal).getUsername();
/*    */       } else {
/* 64 */         username = principal.toString();
/*    */       } 
/*    */       
/* 67 */       ncb.setName(username);
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\Gcorp\Downloads\spring-security-core-3.2.0.RELEASE.jar!\org\springframework\security\authentication\jaas\JaasNameCallbackHandler.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */