/*     */ package org.springframework.security.authentication;
/*     */ 
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.util.HashMap;
/*     */ import java.util.Properties;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.context.ApplicationEvent;
/*     */ import org.springframework.context.ApplicationEventPublisher;
/*     */ import org.springframework.context.ApplicationEventPublisherAware;
/*     */ import org.springframework.security.authentication.event.AbstractAuthenticationEvent;
/*     */ import org.springframework.security.authentication.event.AbstractAuthenticationFailureEvent;
/*     */ import org.springframework.security.authentication.event.AuthenticationFailureBadCredentialsEvent;
/*     */ import org.springframework.security.authentication.event.AuthenticationFailureCredentialsExpiredEvent;
/*     */ import org.springframework.security.authentication.event.AuthenticationFailureDisabledEvent;
/*     */ import org.springframework.security.authentication.event.AuthenticationFailureExpiredEvent;
/*     */ import org.springframework.security.authentication.event.AuthenticationFailureLockedEvent;
/*     */ import org.springframework.security.authentication.event.AuthenticationFailureProviderNotFoundEvent;
/*     */ import org.springframework.security.authentication.event.AuthenticationFailureProxyUntrustedEvent;
/*     */ import org.springframework.security.authentication.event.AuthenticationFailureServiceExceptionEvent;
/*     */ import org.springframework.security.authentication.event.AuthenticationSuccessEvent;
/*     */ import org.springframework.security.core.Authentication;
/*     */ import org.springframework.security.core.AuthenticationException;
/*     */ import org.springframework.security.core.userdetails.UsernameNotFoundException;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DefaultAuthenticationEventPublisher
/*     */   implements AuthenticationEventPublisher, ApplicationEventPublisherAware
/*     */ {
/*  45 */   private final Log logger = LogFactory.getLog(getClass());
/*     */   
/*     */   private ApplicationEventPublisher applicationEventPublisher;
/*  48 */   private final HashMap<String, Constructor<? extends AbstractAuthenticationEvent>> exceptionMappings = new HashMap<String, Constructor<? extends AbstractAuthenticationEvent>>();
/*     */ 
/*     */   
/*     */   public DefaultAuthenticationEventPublisher() {
/*  52 */     this(null);
/*     */   }
/*     */   
/*     */   public DefaultAuthenticationEventPublisher(ApplicationEventPublisher applicationEventPublisher) {
/*  56 */     this.applicationEventPublisher = applicationEventPublisher;
/*     */     
/*  58 */     addMapping(BadCredentialsException.class.getName(), (Class)AuthenticationFailureBadCredentialsEvent.class);
/*  59 */     addMapping(UsernameNotFoundException.class.getName(), (Class)AuthenticationFailureBadCredentialsEvent.class);
/*  60 */     addMapping(AccountExpiredException.class.getName(), (Class)AuthenticationFailureExpiredEvent.class);
/*  61 */     addMapping(ProviderNotFoundException.class.getName(), (Class)AuthenticationFailureProviderNotFoundEvent.class);
/*  62 */     addMapping(DisabledException.class.getName(), (Class)AuthenticationFailureDisabledEvent.class);
/*  63 */     addMapping(LockedException.class.getName(), (Class)AuthenticationFailureLockedEvent.class);
/*  64 */     addMapping(AuthenticationServiceException.class.getName(), (Class)AuthenticationFailureServiceExceptionEvent.class);
/*  65 */     addMapping(CredentialsExpiredException.class.getName(), (Class)AuthenticationFailureCredentialsExpiredEvent.class);
/*  66 */     addMapping("org.springframework.security.authentication.cas.ProxyUntrustedException", (Class)AuthenticationFailureProxyUntrustedEvent.class);
/*     */   }
/*     */ 
/*     */   
/*     */   public void publishAuthenticationSuccess(Authentication authentication) {
/*  71 */     if (this.applicationEventPublisher != null) {
/*  72 */       this.applicationEventPublisher.publishEvent((ApplicationEvent)new AuthenticationSuccessEvent(authentication));
/*     */     }
/*     */   }
/*     */   
/*     */   public void publishAuthenticationFailure(AuthenticationException exception, Authentication authentication) {
/*  77 */     Constructor<? extends AbstractAuthenticationEvent> constructor = this.exceptionMappings.get(exception.getClass().getName());
/*  78 */     AbstractAuthenticationEvent event = null;
/*     */     
/*  80 */     if (constructor != null) {
/*     */       
/*  82 */       try { event = constructor.newInstance(new Object[] { authentication, exception }); }
/*  83 */       catch (IllegalAccessException ignored) {  }
/*  84 */       catch (InstantiationException ignored) {  }
/*  85 */       catch (InvocationTargetException ignored) {}
/*     */     }
/*     */     
/*  88 */     if (event != null) {
/*  89 */       if (this.applicationEventPublisher != null) {
/*  90 */         this.applicationEventPublisher.publishEvent((ApplicationEvent)event);
/*     */       }
/*     */     }
/*  93 */     else if (this.logger.isDebugEnabled()) {
/*  94 */       this.logger.debug("No event was found for the exception " + exception.getClass().getName());
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void setApplicationEventPublisher(ApplicationEventPublisher applicationEventPublisher) {
/* 100 */     this.applicationEventPublisher = applicationEventPublisher;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setAdditionalExceptionMappings(Properties additionalExceptionMappings) {
/* 112 */     Assert.notNull(additionalExceptionMappings, "The exceptionMappings object must not be null");
/* 113 */     for (Object exceptionClass : additionalExceptionMappings.keySet()) {
/* 114 */       String eventClass = (String)additionalExceptionMappings.get(exceptionClass);
/*     */       try {
/* 116 */         Class<?> clazz = getClass().getClassLoader().loadClass(eventClass);
/* 117 */         Assert.isAssignable(AbstractAuthenticationFailureEvent.class, clazz);
/* 118 */         addMapping((String)exceptionClass, (Class)clazz);
/* 119 */       } catch (ClassNotFoundException e) {
/* 120 */         throw new RuntimeException("Failed to load authentication event class " + eventClass);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private void addMapping(String exceptionClass, Class<? extends AbstractAuthenticationFailureEvent> eventClass) {
/*     */     try {
/* 128 */       Constructor<? extends AbstractAuthenticationEvent> constructor = (Constructor)eventClass.getConstructor(new Class[] { Authentication.class, AuthenticationException.class });
/*     */       
/* 130 */       this.exceptionMappings.put(exceptionClass, constructor);
/* 131 */     } catch (NoSuchMethodException e) {
/* 132 */       throw new RuntimeException("Authentication event class " + eventClass.getName() + " has no suitable constructor");
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\Gcorp\Downloads\spring-security-core-3.2.0.RELEASE.jar!\org\springframework\security\authentication\DefaultAuthenticationEventPublisher.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */