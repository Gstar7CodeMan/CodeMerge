/*    */ package org.springframework.security.authentication;
/*    */ 
/*    */ import org.springframework.context.support.MessageSourceAccessor;
/*    */ import org.springframework.security.core.SpringSecurityMessageSource;
/*    */ import org.springframework.security.core.userdetails.UserDetails;
/*    */ import org.springframework.security.core.userdetails.UserDetailsChecker;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class AccountStatusUserDetailsChecker
/*    */   implements UserDetailsChecker
/*    */ {
/* 13 */   protected final MessageSourceAccessor messages = SpringSecurityMessageSource.getAccessor();
/*    */   
/*    */   public void check(UserDetails user) {
/* 16 */     if (!user.isAccountNonLocked()) {
/* 17 */       throw new LockedException(this.messages.getMessage("AccountStatusUserDetailsChecker.locked", "User account is locked"), user);
/*    */     }
/*    */     
/* 20 */     if (!user.isEnabled()) {
/* 21 */       throw new DisabledException(this.messages.getMessage("AccountStatusUserDetailsChecker.disabled", "User is disabled"), user);
/*    */     }
/*    */     
/* 24 */     if (!user.isAccountNonExpired()) {
/* 25 */       throw new AccountExpiredException(this.messages.getMessage("AccountStatusUserDetailsChecker.expired", "User account has expired"), user);
/*    */     }
/*    */ 
/*    */     
/* 29 */     if (!user.isCredentialsNonExpired())
/* 30 */       throw new CredentialsExpiredException(this.messages.getMessage("AccountStatusUserDetailsChecker.credentialsExpired", "User credentials have expired"), user); 
/*    */   }
/*    */ }


/* Location:              C:\Users\Gcorp\Downloads\spring-security-core-3.2.0.RELEASE.jar!\org\springframework\security\authentication\AccountStatusUserDetailsChecker.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */