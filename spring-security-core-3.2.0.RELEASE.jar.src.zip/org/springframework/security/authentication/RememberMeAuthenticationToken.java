/*    */ package org.springframework.security.authentication;
/*    */ 
/*    */ import java.util.Collection;
/*    */ import org.springframework.security.core.GrantedAuthority;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class RememberMeAuthenticationToken
/*    */   extends AbstractAuthenticationToken
/*    */ {
/*    */   private static final long serialVersionUID = 320L;
/*    */   private final Object principal;
/*    */   private final int keyHash;
/*    */   
/*    */   public RememberMeAuthenticationToken(String key, Object principal, Collection<? extends GrantedAuthority> authorities) {
/* 54 */     super(authorities);
/*    */     
/* 56 */     if (key == null || "".equals(key) || principal == null || "".equals(principal)) {
/* 57 */       throw new IllegalArgumentException("Cannot pass null or empty values to constructor");
/*    */     }
/*    */     
/* 60 */     this.keyHash = key.hashCode();
/* 61 */     this.principal = principal;
/* 62 */     setAuthenticated(true);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Object getCredentials() {
/* 73 */     return "";
/*    */   }
/*    */   
/*    */   public int getKeyHash() {
/* 77 */     return this.keyHash;
/*    */   }
/*    */   
/*    */   public Object getPrincipal() {
/* 81 */     return this.principal;
/*    */   }
/*    */   
/*    */   public boolean equals(Object obj) {
/* 85 */     if (!super.equals(obj)) {
/* 86 */       return false;
/*    */     }
/*    */     
/* 89 */     if (obj instanceof RememberMeAuthenticationToken) {
/* 90 */       RememberMeAuthenticationToken test = (RememberMeAuthenticationToken)obj;
/*    */       
/* 92 */       if (getKeyHash() != test.getKeyHash()) {
/* 93 */         return false;
/*    */       }
/*    */       
/* 96 */       return true;
/*    */     } 
/*    */     
/* 99 */     return false;
/*    */   }
/*    */ }


/* Location:              C:\Users\Gcorp\Downloads\spring-security-core-3.2.0.RELEASE.jar!\org\springframework\security\authentication\RememberMeAuthenticationToken.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */