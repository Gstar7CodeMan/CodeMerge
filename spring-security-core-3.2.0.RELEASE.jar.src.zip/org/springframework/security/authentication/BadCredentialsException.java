/*    */ package org.springframework.security.authentication;
/*    */ 
/*    */ import org.springframework.security.core.AuthenticationException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class BadCredentialsException
/*    */   extends AuthenticationException
/*    */ {
/*    */   public BadCredentialsException(String msg) {
/* 36 */     super(msg);
/*    */   }
/*    */   
/*    */   @Deprecated
/*    */   public BadCredentialsException(String msg, Object extraInformation) {
/* 41 */     super(msg, extraInformation);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public BadCredentialsException(String msg, Throwable t) {
/* 52 */     super(msg, t);
/*    */   }
/*    */ }


/* Location:              C:\Users\Gcorp\Downloads\spring-security-core-3.2.0.RELEASE.jar!\org\springframework\security\authentication\BadCredentialsException.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */