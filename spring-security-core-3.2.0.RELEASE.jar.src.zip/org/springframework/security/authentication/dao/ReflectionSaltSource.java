/*     */ package org.springframework.security.authentication.dao;
/*     */ 
/*     */ import java.beans.PropertyDescriptor;
/*     */ import java.lang.reflect.Method;
/*     */ import org.springframework.beans.BeanUtils;
/*     */ import org.springframework.beans.factory.InitializingBean;
/*     */ import org.springframework.security.authentication.AuthenticationServiceException;
/*     */ import org.springframework.security.core.userdetails.UserDetails;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ReflectionUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ReflectionSaltSource
/*     */   implements SaltSource, InitializingBean
/*     */ {
/*     */   private String userPropertyToUse;
/*     */   
/*     */   public void afterPropertiesSet() throws Exception {
/*  49 */     Assert.hasText(this.userPropertyToUse, "A userPropertyToUse must be set");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object getSalt(UserDetails user) {
/*  66 */     Method saltMethod = findSaltMethod(user);
/*     */     
/*     */     try {
/*  69 */       return saltMethod.invoke(user, new Object[0]);
/*  70 */     } catch (Exception exception) {
/*  71 */       throw new AuthenticationServiceException(exception.getMessage(), exception);
/*     */     } 
/*     */   }
/*     */   
/*     */   private Method findSaltMethod(UserDetails user) {
/*  76 */     Method saltMethod = ReflectionUtils.findMethod(user.getClass(), this.userPropertyToUse, new Class[0]);
/*     */     
/*  78 */     if (saltMethod == null) {
/*  79 */       PropertyDescriptor pd = BeanUtils.getPropertyDescriptor(user.getClass(), this.userPropertyToUse);
/*     */       
/*  81 */       if (pd != null) {
/*  82 */         saltMethod = pd.getReadMethod();
/*     */       }
/*     */       
/*  85 */       if (saltMethod == null) {
/*  86 */         throw new AuthenticationServiceException("Unable to find salt method on user Object. Does the class '" + user.getClass().getName() + "' have a method or getter named '" + this.userPropertyToUse + "' ?");
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/*  91 */     return saltMethod;
/*     */   }
/*     */   
/*     */   protected String getUserPropertyToUse() {
/*  95 */     return this.userPropertyToUse;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setUserPropertyToUse(String userPropertyToUse) {
/* 107 */     this.userPropertyToUse = userPropertyToUse;
/*     */   }
/*     */   
/*     */   public String toString() {
/* 111 */     return "ReflectionSaltSource[ userPropertyToUse='" + this.userPropertyToUse + "'; ]";
/*     */   }
/*     */ }


/* Location:              C:\Users\Gcorp\Downloads\spring-security-core-3.2.0.RELEASE.jar!\org\springframework\security\authentication\dao\ReflectionSaltSource.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */