/*     */ package org.springframework.security.authentication.dao;
/*     */ 
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.beans.factory.InitializingBean;
/*     */ import org.springframework.context.MessageSource;
/*     */ import org.springframework.context.MessageSourceAware;
/*     */ import org.springframework.context.support.MessageSourceAccessor;
/*     */ import org.springframework.security.authentication.AccountExpiredException;
/*     */ import org.springframework.security.authentication.AuthenticationProvider;
/*     */ import org.springframework.security.authentication.BadCredentialsException;
/*     */ import org.springframework.security.authentication.CredentialsExpiredException;
/*     */ import org.springframework.security.authentication.DisabledException;
/*     */ import org.springframework.security.authentication.LockedException;
/*     */ import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
/*     */ import org.springframework.security.core.Authentication;
/*     */ import org.springframework.security.core.AuthenticationException;
/*     */ import org.springframework.security.core.SpringSecurityMessageSource;
/*     */ import org.springframework.security.core.authority.mapping.GrantedAuthoritiesMapper;
/*     */ import org.springframework.security.core.authority.mapping.NullAuthoritiesMapper;
/*     */ import org.springframework.security.core.userdetails.UserCache;
/*     */ import org.springframework.security.core.userdetails.UserDetails;
/*     */ import org.springframework.security.core.userdetails.UserDetailsChecker;
/*     */ import org.springframework.security.core.userdetails.UsernameNotFoundException;
/*     */ import org.springframework.security.core.userdetails.cache.NullUserCache;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AbstractUserDetailsAuthenticationProvider
/*     */   implements AuthenticationProvider, InitializingBean, MessageSourceAware
/*     */ {
/*  79 */   protected final Log logger = LogFactory.getLog(getClass());
/*     */ 
/*     */ 
/*     */   
/*  83 */   protected MessageSourceAccessor messages = SpringSecurityMessageSource.getAccessor();
/*  84 */   private UserCache userCache = (UserCache)new NullUserCache();
/*     */   private boolean forcePrincipalAsString = false;
/*     */   protected boolean hideUserNotFoundExceptions = true;
/*  87 */   private UserDetailsChecker preAuthenticationChecks = new DefaultPreAuthenticationChecks();
/*  88 */   private UserDetailsChecker postAuthenticationChecks = new DefaultPostAuthenticationChecks();
/*  89 */   private GrantedAuthoritiesMapper authoritiesMapper = (GrantedAuthoritiesMapper)new NullAuthoritiesMapper();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected abstract void additionalAuthenticationChecks(UserDetails paramUserDetails, UsernamePasswordAuthenticationToken paramUsernamePasswordAuthenticationToken) throws AuthenticationException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void afterPropertiesSet() throws Exception {
/* 112 */     Assert.notNull(this.userCache, "A user cache must be set");
/* 113 */     Assert.notNull(this.messages, "A message source must be set");
/* 114 */     doAfterPropertiesSet();
/*     */   }
/*     */   
/*     */   public Authentication authenticate(Authentication authentication) throws AuthenticationException {
/* 118 */     Assert.isInstanceOf(UsernamePasswordAuthenticationToken.class, authentication, this.messages.getMessage("AbstractUserDetailsAuthenticationProvider.onlySupports", "Only UsernamePasswordAuthenticationToken is supported"));
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 123 */     String username = (authentication.getPrincipal() == null) ? "NONE_PROVIDED" : authentication.getName();
/*     */     
/* 125 */     boolean cacheWasUsed = true;
/* 126 */     UserDetails user = this.userCache.getUserFromCache(username);
/*     */     
/* 128 */     if (user == null) {
/* 129 */       cacheWasUsed = false;
/*     */       
/*     */       try {
/* 132 */         user = retrieveUser(username, (UsernamePasswordAuthenticationToken)authentication);
/* 133 */       } catch (UsernameNotFoundException notFound) {
/* 134 */         this.logger.debug("User '" + username + "' not found");
/*     */         
/* 136 */         if (this.hideUserNotFoundExceptions) {
/* 137 */           throw new BadCredentialsException(this.messages.getMessage("AbstractUserDetailsAuthenticationProvider.badCredentials", "Bad credentials"));
/*     */         }
/*     */         
/* 140 */         throw notFound;
/*     */       } 
/*     */ 
/*     */       
/* 144 */       Assert.notNull(user, "retrieveUser returned null - a violation of the interface contract");
/*     */     } 
/*     */     
/*     */     try {
/* 148 */       this.preAuthenticationChecks.check(user);
/* 149 */       additionalAuthenticationChecks(user, (UsernamePasswordAuthenticationToken)authentication);
/* 150 */     } catch (AuthenticationException exception) {
/* 151 */       if (cacheWasUsed) {
/*     */ 
/*     */         
/* 154 */         cacheWasUsed = false;
/* 155 */         user = retrieveUser(username, (UsernamePasswordAuthenticationToken)authentication);
/* 156 */         this.preAuthenticationChecks.check(user);
/* 157 */         additionalAuthenticationChecks(user, (UsernamePasswordAuthenticationToken)authentication);
/*     */       } else {
/* 159 */         throw exception;
/*     */       } 
/*     */     } 
/*     */     
/* 163 */     this.postAuthenticationChecks.check(user);
/*     */     
/* 165 */     if (!cacheWasUsed) {
/* 166 */       this.userCache.putUserInCache(user);
/*     */     }
/*     */     
/* 169 */     Object principalToReturn = user;
/*     */     
/* 171 */     if (this.forcePrincipalAsString) {
/* 172 */       principalToReturn = user.getUsername();
/*     */     }
/*     */     
/* 175 */     return createSuccessAuthentication(principalToReturn, authentication, user);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Authentication createSuccessAuthentication(Object principal, Authentication authentication, UserDetails user) {
/* 196 */     UsernamePasswordAuthenticationToken result = new UsernamePasswordAuthenticationToken(principal, authentication.getCredentials(), this.authoritiesMapper.mapAuthorities(user.getAuthorities()));
/*     */     
/* 198 */     result.setDetails(authentication.getDetails());
/*     */     
/* 200 */     return (Authentication)result;
/*     */   }
/*     */   
/*     */   protected void doAfterPropertiesSet() throws Exception {}
/*     */   
/*     */   public UserCache getUserCache() {
/* 206 */     return this.userCache;
/*     */   }
/*     */   
/*     */   public boolean isForcePrincipalAsString() {
/* 210 */     return this.forcePrincipalAsString;
/*     */   }
/*     */   
/*     */   public boolean isHideUserNotFoundExceptions() {
/* 214 */     return this.hideUserNotFoundExceptions;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected abstract UserDetails retrieveUser(String paramString, UsernamePasswordAuthenticationToken paramUsernamePasswordAuthenticationToken) throws AuthenticationException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setForcePrincipalAsString(boolean forcePrincipalAsString) {
/* 249 */     this.forcePrincipalAsString = forcePrincipalAsString;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setHideUserNotFoundExceptions(boolean hideUserNotFoundExceptions) {
/* 264 */     this.hideUserNotFoundExceptions = hideUserNotFoundExceptions;
/*     */   }
/*     */   
/*     */   public void setMessageSource(MessageSource messageSource) {
/* 268 */     this.messages = new MessageSourceAccessor(messageSource);
/*     */   }
/*     */   
/*     */   public void setUserCache(UserCache userCache) {
/* 272 */     this.userCache = userCache;
/*     */   }
/*     */   
/*     */   public boolean supports(Class<?> authentication) {
/* 276 */     return UsernamePasswordAuthenticationToken.class.isAssignableFrom(authentication);
/*     */   }
/*     */   
/*     */   protected UserDetailsChecker getPreAuthenticationChecks() {
/* 280 */     return this.preAuthenticationChecks;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setPreAuthenticationChecks(UserDetailsChecker preAuthenticationChecks) {
/* 290 */     this.preAuthenticationChecks = preAuthenticationChecks;
/*     */   }
/*     */   
/*     */   protected UserDetailsChecker getPostAuthenticationChecks() {
/* 294 */     return this.postAuthenticationChecks;
/*     */   }
/*     */   
/*     */   public void setPostAuthenticationChecks(UserDetailsChecker postAuthenticationChecks) {
/* 298 */     this.postAuthenticationChecks = postAuthenticationChecks;
/*     */   }
/*     */   
/*     */   public void setAuthoritiesMapper(GrantedAuthoritiesMapper authoritiesMapper) {
/* 302 */     this.authoritiesMapper = authoritiesMapper;
/*     */   }
/*     */   
/*     */   private class DefaultPreAuthenticationChecks implements UserDetailsChecker {
/*     */     public void check(UserDetails user) {
/* 307 */       if (!user.isAccountNonLocked()) {
/* 308 */         AbstractUserDetailsAuthenticationProvider.this.logger.debug("User account is locked");
/*     */         
/* 310 */         throw new LockedException(AbstractUserDetailsAuthenticationProvider.this.messages.getMessage("AbstractUserDetailsAuthenticationProvider.locked", "User account is locked"), user);
/*     */       } 
/*     */ 
/*     */       
/* 314 */       if (!user.isEnabled()) {
/* 315 */         AbstractUserDetailsAuthenticationProvider.this.logger.debug("User account is disabled");
/*     */         
/* 317 */         throw new DisabledException(AbstractUserDetailsAuthenticationProvider.this.messages.getMessage("AbstractUserDetailsAuthenticationProvider.disabled", "User is disabled"), user);
/*     */       } 
/*     */ 
/*     */       
/* 321 */       if (!user.isAccountNonExpired()) {
/* 322 */         AbstractUserDetailsAuthenticationProvider.this.logger.debug("User account is expired");
/*     */         
/* 324 */         throw new AccountExpiredException(AbstractUserDetailsAuthenticationProvider.this.messages.getMessage("AbstractUserDetailsAuthenticationProvider.expired", "User account has expired"), user);
/*     */       } 
/*     */     }
/*     */     private DefaultPreAuthenticationChecks() {} }
/*     */   
/*     */   private class DefaultPostAuthenticationChecks implements UserDetailsChecker { private DefaultPostAuthenticationChecks() {}
/*     */     
/*     */     public void check(UserDetails user) {
/* 332 */       if (!user.isCredentialsNonExpired()) {
/* 333 */         AbstractUserDetailsAuthenticationProvider.this.logger.debug("User account credentials have expired");
/*     */         
/* 335 */         throw new CredentialsExpiredException(AbstractUserDetailsAuthenticationProvider.this.messages.getMessage("AbstractUserDetailsAuthenticationProvider.credentialsExpired", "User credentials have expired"), user);
/*     */       } 
/*     */     } }
/*     */ 
/*     */ }


/* Location:              C:\Users\Gcorp\Downloads\spring-security-core-3.2.0.RELEASE.jar!\org\springframework\security\authentication\dao\AbstractUserDetailsAuthenticationProvider.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */