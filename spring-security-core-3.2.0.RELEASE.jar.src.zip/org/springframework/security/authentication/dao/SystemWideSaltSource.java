/*    */ package org.springframework.security.authentication.dao;
/*    */ 
/*    */ import org.springframework.beans.factory.InitializingBean;
/*    */ import org.springframework.security.core.userdetails.UserDetails;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SystemWideSaltSource
/*    */   implements SaltSource, InitializingBean
/*    */ {
/*    */   private String systemWideSalt;
/*    */   
/*    */   public void afterPropertiesSet() throws Exception {
/* 39 */     if (this.systemWideSalt == null || "".equals(this.systemWideSalt)) {
/* 40 */       throw new IllegalArgumentException("A systemWideSalt must be set");
/*    */     }
/*    */   }
/*    */   
/*    */   public Object getSalt(UserDetails user) {
/* 45 */     return this.systemWideSalt;
/*    */   }
/*    */   
/*    */   public String getSystemWideSalt() {
/* 49 */     return this.systemWideSalt;
/*    */   }
/*    */   
/*    */   public void setSystemWideSalt(String systemWideSalt) {
/* 53 */     this.systemWideSalt = systemWideSalt;
/*    */   }
/*    */ }


/* Location:              C:\Users\Gcorp\Downloads\spring-security-core-3.2.0.RELEASE.jar!\org\springframework\security\authentication\dao\SystemWideSaltSource.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */