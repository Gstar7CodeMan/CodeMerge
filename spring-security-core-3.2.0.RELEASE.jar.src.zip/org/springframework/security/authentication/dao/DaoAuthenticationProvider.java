/*     */ package org.springframework.security.authentication.dao;
/*     */ 
/*     */ import org.springframework.security.authentication.AuthenticationServiceException;
/*     */ import org.springframework.security.authentication.BadCredentialsException;
/*     */ import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
/*     */ import org.springframework.security.authentication.encoding.PasswordEncoder;
/*     */ import org.springframework.security.authentication.encoding.PlaintextPasswordEncoder;
/*     */ import org.springframework.security.core.AuthenticationException;
/*     */ import org.springframework.security.core.userdetails.UserDetails;
/*     */ import org.springframework.security.core.userdetails.UserDetailsService;
/*     */ import org.springframework.security.core.userdetails.UsernameNotFoundException;
/*     */ import org.springframework.security.crypto.password.PasswordEncoder;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DaoAuthenticationProvider
/*     */   extends AbstractUserDetailsAuthenticationProvider
/*     */ {
/*     */   private static final String USER_NOT_FOUND_PASSWORD = "userNotFoundPassword";
/*     */   private PasswordEncoder passwordEncoder;
/*     */   private String userNotFoundEncodedPassword;
/*     */   private SaltSource saltSource;
/*     */   private UserDetailsService userDetailsService;
/*     */   
/*     */   public DaoAuthenticationProvider() {
/*  61 */     setPasswordEncoder((PasswordEncoder)new PlaintextPasswordEncoder());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void additionalAuthenticationChecks(UserDetails userDetails, UsernamePasswordAuthenticationToken authentication) throws AuthenticationException {
/*  69 */     Object salt = null;
/*     */     
/*  71 */     if (this.saltSource != null) {
/*  72 */       salt = this.saltSource.getSalt(userDetails);
/*     */     }
/*     */     
/*  75 */     if (authentication.getCredentials() == null) {
/*  76 */       this.logger.debug("Authentication failed: no credentials provided");
/*     */       
/*  78 */       throw new BadCredentialsException(this.messages.getMessage("AbstractUserDetailsAuthenticationProvider.badCredentials", "Bad credentials"), userDetails);
/*     */     } 
/*     */ 
/*     */     
/*  82 */     String presentedPassword = authentication.getCredentials().toString();
/*     */     
/*  84 */     if (!this.passwordEncoder.isPasswordValid(userDetails.getPassword(), presentedPassword, salt)) {
/*  85 */       this.logger.debug("Authentication failed: password does not match stored value");
/*     */       
/*  87 */       throw new BadCredentialsException(this.messages.getMessage("AbstractUserDetailsAuthenticationProvider.badCredentials", "Bad credentials"), userDetails);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   protected void doAfterPropertiesSet() throws Exception {
/*  93 */     Assert.notNull(this.userDetailsService, "A UserDetailsService must be set");
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected final UserDetails retrieveUser(String username, UsernamePasswordAuthenticationToken authentication) throws AuthenticationException {
/*     */     UserDetails loadedUser;
/*     */     try {
/* 101 */       loadedUser = getUserDetailsService().loadUserByUsername(username);
/* 102 */     } catch (UsernameNotFoundException notFound) {
/* 103 */       if (authentication.getCredentials() != null) {
/* 104 */         String presentedPassword = authentication.getCredentials().toString();
/* 105 */         this.passwordEncoder.isPasswordValid(this.userNotFoundEncodedPassword, presentedPassword, null);
/*     */       } 
/* 107 */       throw notFound;
/* 108 */     } catch (Exception repositoryProblem) {
/* 109 */       throw new AuthenticationServiceException(repositoryProblem.getMessage(), repositoryProblem);
/*     */     } 
/*     */     
/* 112 */     if (loadedUser == null) {
/* 113 */       throw new AuthenticationServiceException("UserDetailsService returned null, which is an interface contract violation");
/*     */     }
/*     */     
/* 116 */     return loadedUser;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setPasswordEncoder(Object passwordEncoder) {
/* 130 */     Assert.notNull(passwordEncoder, "passwordEncoder cannot be null");
/*     */     
/* 132 */     if (passwordEncoder instanceof PasswordEncoder) {
/* 133 */       setPasswordEncoder((PasswordEncoder)passwordEncoder);
/*     */       
/*     */       return;
/*     */     } 
/* 137 */     if (passwordEncoder instanceof PasswordEncoder) {
/* 138 */       final PasswordEncoder delegate = (PasswordEncoder)passwordEncoder;
/*     */       
/* 140 */       setPasswordEncoder(new PasswordEncoder() {
/*     */             public String encodePassword(String rawPass, Object salt) {
/* 142 */               checkSalt(salt);
/* 143 */               return delegate.encode(rawPass);
/*     */             }
/*     */             
/*     */             public boolean isPasswordValid(String encPass, String rawPass, Object salt) {
/* 147 */               checkSalt(salt);
/* 148 */               return delegate.matches(rawPass, encPass);
/*     */             }
/*     */             
/*     */             private void checkSalt(Object salt) {
/* 152 */               Assert.isNull(salt, "Salt value must be null when used with crypto module PasswordEncoder");
/*     */             }
/*     */           });
/*     */       
/*     */       return;
/*     */     } 
/*     */     
/* 159 */     throw new IllegalArgumentException("passwordEncoder must be a PasswordEncoder instance");
/*     */   }
/*     */   
/*     */   private void setPasswordEncoder(PasswordEncoder passwordEncoder) {
/* 163 */     Assert.notNull(passwordEncoder, "passwordEncoder cannot be null");
/*     */     
/* 165 */     this.userNotFoundEncodedPassword = passwordEncoder.encodePassword("userNotFoundPassword", null);
/* 166 */     this.passwordEncoder = passwordEncoder;
/*     */   }
/*     */   
/*     */   protected PasswordEncoder getPasswordEncoder() {
/* 170 */     return this.passwordEncoder;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setSaltSource(SaltSource saltSource) {
/* 185 */     this.saltSource = saltSource;
/*     */   }
/*     */   
/*     */   protected SaltSource getSaltSource() {
/* 189 */     return this.saltSource;
/*     */   }
/*     */   
/*     */   public void setUserDetailsService(UserDetailsService userDetailsService) {
/* 193 */     this.userDetailsService = userDetailsService;
/*     */   }
/*     */   
/*     */   protected UserDetailsService getUserDetailsService() {
/* 197 */     return this.userDetailsService;
/*     */   }
/*     */ }


/* Location:              C:\Users\Gcorp\Downloads\spring-security-core-3.2.0.RELEASE.jar!\org\springframework\security\authentication\dao\DaoAuthenticationProvider.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */