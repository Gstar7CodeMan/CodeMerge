/*    */ package org.springframework.security.authentication.event;
/*    */ 
/*    */ import org.springframework.context.ApplicationEvent;
/*    */ import org.springframework.security.core.Authentication;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class AbstractAuthenticationEvent
/*    */   extends ApplicationEvent
/*    */ {
/*    */   public AbstractAuthenticationEvent(Authentication authentication) {
/* 33 */     super(authentication);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Authentication getAuthentication() {
/* 45 */     return (Authentication)getSource();
/*    */   }
/*    */ }


/* Location:              C:\Users\Gcorp\Downloads\spring-security-core-3.2.0.RELEASE.jar!\org\springframework\security\authentication\event\AbstractAuthenticationEvent.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */