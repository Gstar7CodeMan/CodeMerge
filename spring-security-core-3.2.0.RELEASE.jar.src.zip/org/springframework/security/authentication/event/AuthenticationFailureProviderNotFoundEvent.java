/*    */ package org.springframework.security.authentication.event;
/*    */ 
/*    */ import org.springframework.security.core.Authentication;
/*    */ import org.springframework.security.core.AuthenticationException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class AuthenticationFailureProviderNotFoundEvent
/*    */   extends AbstractAuthenticationFailureEvent
/*    */ {
/*    */   public AuthenticationFailureProviderNotFoundEvent(Authentication authentication, AuthenticationException exception) {
/* 32 */     super(authentication, exception);
/*    */   }
/*    */ }


/* Location:              C:\Users\Gcorp\Downloads\spring-security-core-3.2.0.RELEASE.jar!\org\springframework\security\authentication\event\AuthenticationFailureProviderNotFoundEvent.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */