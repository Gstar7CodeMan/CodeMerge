/*    */ package org.springframework.security.authentication.event;
/*    */ 
/*    */ import org.springframework.security.core.Authentication;
/*    */ import org.springframework.util.Assert;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class InteractiveAuthenticationSuccessEvent
/*    */   extends AbstractAuthenticationEvent
/*    */ {
/*    */   private final Class<?> generatedBy;
/*    */   
/*    */   public InteractiveAuthenticationSuccessEvent(Authentication authentication, Class<?> generatedBy) {
/* 37 */     super(authentication);
/* 38 */     Assert.notNull(generatedBy);
/* 39 */     this.generatedBy = generatedBy;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Class<?> getGeneratedBy() {
/* 51 */     return this.generatedBy;
/*    */   }
/*    */ }


/* Location:              C:\Users\Gcorp\Downloads\spring-security-core-3.2.0.RELEASE.jar!\org\springframework\security\authentication\event\InteractiveAuthenticationSuccessEvent.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */