/*    */ package org.springframework.security.authentication.event;
/*    */ 
/*    */ import org.springframework.security.core.Authentication;
/*    */ import org.springframework.security.core.AuthenticationException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class AuthenticationFailureExpiredEvent
/*    */   extends AbstractAuthenticationFailureEvent
/*    */ {
/*    */   public AuthenticationFailureExpiredEvent(Authentication authentication, AuthenticationException exception) {
/* 31 */     super(authentication, exception);
/*    */   }
/*    */ }


/* Location:              C:\Users\Gcorp\Downloads\spring-security-core-3.2.0.RELEASE.jar!\org\springframework\security\authentication\event\AuthenticationFailureExpiredEvent.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */