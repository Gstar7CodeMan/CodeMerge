/*    */ package org.springframework.security.authentication.event;
/*    */ 
/*    */ import org.springframework.security.core.Authentication;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class AuthenticationSuccessEvent
/*    */   extends AbstractAuthenticationEvent
/*    */ {
/*    */   public AuthenticationSuccessEvent(Authentication authentication) {
/* 30 */     super(authentication);
/*    */   }
/*    */ }


/* Location:              C:\Users\Gcorp\Downloads\spring-security-core-3.2.0.RELEASE.jar!\org\springframework\security\authentication\event\AuthenticationSuccessEvent.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */