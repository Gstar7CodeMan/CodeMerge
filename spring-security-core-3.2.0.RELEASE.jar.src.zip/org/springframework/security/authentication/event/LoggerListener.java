/*    */ package org.springframework.security.authentication.event;
/*    */ 
/*    */ import org.apache.commons.logging.Log;
/*    */ import org.apache.commons.logging.LogFactory;
/*    */ import org.springframework.context.ApplicationEvent;
/*    */ import org.springframework.context.ApplicationListener;
/*    */ import org.springframework.util.ClassUtils;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class LoggerListener
/*    */   implements ApplicationListener<AbstractAuthenticationEvent>
/*    */ {
/* 34 */   private static final Log logger = LogFactory.getLog(LoggerListener.class);
/*    */ 
/*    */   
/*    */   private boolean logInteractiveAuthenticationSuccessEvents = true;
/*    */ 
/*    */ 
/*    */   
/*    */   public void onApplicationEvent(AbstractAuthenticationEvent event) {
/* 42 */     if (!this.logInteractiveAuthenticationSuccessEvents && event instanceof InteractiveAuthenticationSuccessEvent) {
/*    */       return;
/*    */     }
/*    */     
/* 46 */     if (logger.isWarnEnabled()) {
/* 47 */       StringBuilder builder = new StringBuilder();
/* 48 */       builder.append("Authentication event ");
/* 49 */       builder.append(ClassUtils.getShortName(event.getClass()));
/* 50 */       builder.append(": ");
/* 51 */       builder.append(event.getAuthentication().getName());
/* 52 */       builder.append("; details: ");
/* 53 */       builder.append(event.getAuthentication().getDetails());
/*    */       
/* 55 */       if (event instanceof AbstractAuthenticationFailureEvent) {
/* 56 */         builder.append("; exception: ");
/* 57 */         builder.append(((AbstractAuthenticationFailureEvent)event).getException().getMessage());
/*    */       } 
/*    */       
/* 60 */       logger.warn(builder.toString());
/*    */     } 
/*    */   }
/*    */   
/*    */   public boolean isLogInteractiveAuthenticationSuccessEvents() {
/* 65 */     return this.logInteractiveAuthenticationSuccessEvents;
/*    */   }
/*    */ 
/*    */   
/*    */   public void setLogInteractiveAuthenticationSuccessEvents(boolean logInteractiveAuthenticationSuccessEvents) {
/* 70 */     this.logInteractiveAuthenticationSuccessEvents = logInteractiveAuthenticationSuccessEvents;
/*    */   }
/*    */ }


/* Location:              C:\Users\Gcorp\Downloads\spring-security-core-3.2.0.RELEASE.jar!\org\springframework\security\authentication\event\LoggerListener.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */