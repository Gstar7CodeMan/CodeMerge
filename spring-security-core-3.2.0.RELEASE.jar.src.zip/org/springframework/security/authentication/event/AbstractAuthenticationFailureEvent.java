/*    */ package org.springframework.security.authentication.event;
/*    */ 
/*    */ import org.springframework.security.core.Authentication;
/*    */ import org.springframework.security.core.AuthenticationException;
/*    */ import org.springframework.util.Assert;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class AbstractAuthenticationFailureEvent
/*    */   extends AbstractAuthenticationEvent
/*    */ {
/*    */   private final AuthenticationException exception;
/*    */   
/*    */   public AbstractAuthenticationFailureEvent(Authentication authentication, AuthenticationException exception) {
/* 37 */     super(authentication);
/* 38 */     Assert.notNull(exception, "AuthenticationException is required");
/* 39 */     this.exception = exception;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public AuthenticationException getException() {
/* 45 */     return this.exception;
/*    */   }
/*    */ }


/* Location:              C:\Users\Gcorp\Downloads\spring-security-core-3.2.0.RELEASE.jar!\org\springframework\security\authentication\event\AbstractAuthenticationFailureEvent.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */