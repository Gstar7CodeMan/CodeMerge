/*    */ package org.springframework.security.authentication;
/*    */ 
/*    */ import java.util.Collection;
/*    */ import org.springframework.security.core.GrantedAuthority;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class UsernamePasswordAuthenticationToken
/*    */   extends AbstractAuthenticationToken
/*    */ {
/*    */   private static final long serialVersionUID = 320L;
/*    */   private final Object principal;
/*    */   private Object credentials;
/*    */   
/*    */   public UsernamePasswordAuthenticationToken(Object principal, Object credentials) {
/* 52 */     super(null);
/* 53 */     this.principal = principal;
/* 54 */     this.credentials = credentials;
/* 55 */     setAuthenticated(false);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public UsernamePasswordAuthenticationToken(Object principal, Object credentials, Collection<? extends GrantedAuthority> authorities) {
/* 68 */     super(authorities);
/* 69 */     this.principal = principal;
/* 70 */     this.credentials = credentials;
/* 71 */     super.setAuthenticated(true);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Object getCredentials() {
/* 78 */     return this.credentials;
/*    */   }
/*    */   
/*    */   public Object getPrincipal() {
/* 82 */     return this.principal;
/*    */   }
/*    */   
/*    */   public void setAuthenticated(boolean isAuthenticated) throws IllegalArgumentException {
/* 86 */     if (isAuthenticated) {
/* 87 */       throw new IllegalArgumentException("Cannot set this token to trusted - use constructor which takes a GrantedAuthority list instead");
/*    */     }
/*    */ 
/*    */     
/* 91 */     super.setAuthenticated(false);
/*    */   }
/*    */ 
/*    */   
/*    */   public void eraseCredentials() {
/* 96 */     super.eraseCredentials();
/* 97 */     this.credentials = null;
/*    */   }
/*    */ }


/* Location:              C:\Users\Gcorp\Downloads\spring-security-core-3.2.0.RELEASE.jar!\org\springframework\security\authentication\UsernamePasswordAuthenticationToken.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */