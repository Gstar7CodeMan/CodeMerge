package org.springframework.security.authentication;

import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;

public interface AuthenticationEventPublisher {
  void publishAuthenticationSuccess(Authentication paramAuthentication);
  
  void publishAuthenticationFailure(AuthenticationException paramAuthenticationException, Authentication paramAuthentication);
}


/* Location:              C:\Users\Gcorp\Downloads\spring-security-core-3.2.0.RELEASE.jar!\org\springframework\security\authentication\AuthenticationEventPublisher.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */