/*    */ package org.springframework.security.authentication;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CredentialsExpiredException
/*    */   extends AccountStatusException
/*    */ {
/*    */   public CredentialsExpiredException(String msg) {
/* 34 */     super(msg);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public CredentialsExpiredException(String msg, Throwable t) {
/* 45 */     super(msg, t);
/*    */   }
/*    */   
/*    */   @Deprecated
/*    */   public CredentialsExpiredException(String msg, Object extraInformation) {
/* 50 */     super(msg, extraInformation);
/*    */   }
/*    */ }


/* Location:              C:\Users\Gcorp\Downloads\spring-security-core-3.2.0.RELEASE.jar!\org\springframework\security\authentication\CredentialsExpiredException.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */