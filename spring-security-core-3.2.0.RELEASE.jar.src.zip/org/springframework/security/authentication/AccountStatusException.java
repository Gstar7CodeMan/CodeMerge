/*    */ package org.springframework.security.authentication;
/*    */ 
/*    */ import org.springframework.security.core.AuthenticationException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class AccountStatusException
/*    */   extends AuthenticationException
/*    */ {
/*    */   public AccountStatusException(String msg) {
/* 13 */     super(msg);
/*    */   }
/*    */   
/*    */   public AccountStatusException(String msg, Throwable t) {
/* 17 */     super(msg, t);
/*    */   }
/*    */   
/*    */   @Deprecated
/*    */   protected AccountStatusException(String msg, Object extraInformation) {
/* 22 */     super(msg, extraInformation);
/*    */   }
/*    */ }


/* Location:              C:\Users\Gcorp\Downloads\spring-security-core-3.2.0.RELEASE.jar!\org\springframework\security\authentication\AccountStatusException.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */