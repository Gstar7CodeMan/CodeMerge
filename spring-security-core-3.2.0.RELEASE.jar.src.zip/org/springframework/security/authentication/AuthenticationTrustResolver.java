package org.springframework.security.authentication;

import org.springframework.security.core.Authentication;

public interface AuthenticationTrustResolver {
  boolean isAnonymous(Authentication paramAuthentication);
  
  boolean isRememberMe(Authentication paramAuthentication);
}


/* Location:              C:\Users\Gcorp\Downloads\spring-security-core-3.2.0.RELEASE.jar!\org\springframework\security\authentication\AuthenticationTrustResolver.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */