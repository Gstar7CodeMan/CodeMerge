/*    */ package org.springframework.security.authentication;
/*    */ 
/*    */ import java.util.List;
/*    */ import org.springframework.security.core.GrantedAuthority;
/*    */ import org.springframework.security.core.authority.AuthorityUtils;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class TestingAuthenticationToken
/*    */   extends AbstractAuthenticationToken
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */   private final Object credentials;
/*    */   private final Object principal;
/*    */   
/*    */   public TestingAuthenticationToken(Object principal, Object credentials) {
/* 42 */     super(null);
/* 43 */     this.principal = principal;
/* 44 */     this.credentials = credentials;
/*    */   }
/*    */   
/*    */   public TestingAuthenticationToken(Object principal, Object credentials, String... authorities) {
/* 48 */     this(principal, credentials, AuthorityUtils.createAuthorityList(authorities));
/* 49 */     setAuthenticated(true);
/*    */   }
/*    */   
/*    */   public TestingAuthenticationToken(Object principal, Object credentials, List<GrantedAuthority> authorities) {
/* 53 */     super(authorities);
/* 54 */     this.principal = principal;
/* 55 */     this.credentials = credentials;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public Object getCredentials() {
/* 61 */     return this.credentials;
/*    */   }
/*    */   
/*    */   public Object getPrincipal() {
/* 65 */     return this.principal;
/*    */   }
/*    */ }


/* Location:              C:\Users\Gcorp\Downloads\spring-security-core-3.2.0.RELEASE.jar!\org\springframework\security\authentication\TestingAuthenticationToken.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */