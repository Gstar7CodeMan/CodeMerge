/*    */ package org.springframework.security.authentication;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ import java.util.Collection;
/*    */ import org.springframework.security.core.GrantedAuthority;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class AnonymousAuthenticationToken
/*    */   extends AbstractAuthenticationToken
/*    */   implements Serializable
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */   private final Object principal;
/*    */   private final int keyHash;
/*    */   
/*    */   public AnonymousAuthenticationToken(String key, Object principal, Collection<? extends GrantedAuthority> authorities) {
/* 49 */     super(authorities);
/*    */     
/* 51 */     if (key == null || "".equals(key) || principal == null || "".equals(principal) || authorities == null || authorities.isEmpty())
/*    */     {
/* 53 */       throw new IllegalArgumentException("Cannot pass null or empty values to constructor");
/*    */     }
/*    */     
/* 56 */     this.keyHash = key.hashCode();
/* 57 */     this.principal = principal;
/* 58 */     setAuthenticated(true);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean equals(Object obj) {
/* 64 */     if (!super.equals(obj)) {
/* 65 */       return false;
/*    */     }
/*    */     
/* 68 */     if (obj instanceof AnonymousAuthenticationToken) {
/* 69 */       AnonymousAuthenticationToken test = (AnonymousAuthenticationToken)obj;
/*    */       
/* 71 */       if (getKeyHash() != test.getKeyHash()) {
/* 72 */         return false;
/*    */       }
/*    */       
/* 75 */       return true;
/*    */     } 
/*    */     
/* 78 */     return false;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Object getCredentials() {
/* 87 */     return "";
/*    */   }
/*    */   
/*    */   public int getKeyHash() {
/* 91 */     return this.keyHash;
/*    */   }
/*    */   
/*    */   public Object getPrincipal() {
/* 95 */     return this.principal;
/*    */   }
/*    */ }


/* Location:              C:\Users\Gcorp\Downloads\spring-security-core-3.2.0.RELEASE.jar!\org\springframework\security\authentication\AnonymousAuthenticationToken.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */