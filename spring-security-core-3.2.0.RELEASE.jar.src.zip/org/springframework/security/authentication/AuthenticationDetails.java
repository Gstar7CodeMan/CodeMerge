/*    */ package org.springframework.security.authentication;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Deprecated
/*    */ public class AuthenticationDetails
/*    */   implements Serializable
/*    */ {
/*    */   private static final long serialVersionUID = 320L;
/*    */   private final String context;
/*    */   
/*    */   public AuthenticationDetails(Object context) {
/* 30 */     this.context = (context == null) ? "" : context.toString();
/* 31 */     doPopulateAdditionalInformation(context);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected void doPopulateAdditionalInformation(Object context) {}
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean equals(Object obj) {
/* 44 */     if (obj instanceof AuthenticationDetails) {
/* 45 */       AuthenticationDetails rhs = (AuthenticationDetails)obj;
/*    */ 
/*    */       
/* 48 */       if (!this.context.equals(rhs.getContext())) {
/* 49 */         return false;
/*    */       }
/*    */       
/* 52 */       return true;
/*    */     } 
/*    */     
/* 55 */     return false;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public String getContext() {
/* 64 */     return this.context;
/*    */   }
/*    */   
/*    */   public String toString() {
/* 68 */     StringBuilder sb = new StringBuilder();
/* 69 */     sb.append(super.toString() + ": ");
/* 70 */     sb.append("Context: " + getContext());
/*    */     
/* 72 */     return sb.toString();
/*    */   }
/*    */ }


/* Location:              C:\Users\Gcorp\Downloads\spring-security-core-3.2.0.RELEASE.jar!\org\springframework\security\authentication\AuthenticationDetails.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */