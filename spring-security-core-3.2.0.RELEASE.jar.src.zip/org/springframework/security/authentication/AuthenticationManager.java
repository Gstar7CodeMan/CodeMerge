package org.springframework.security.authentication;

import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;

public interface AuthenticationManager {
  Authentication authenticate(Authentication paramAuthentication) throws AuthenticationException;
}


/* Location:              C:\Users\Gcorp\Downloads\spring-security-core-3.2.0.RELEASE.jar!\org\springframework\security\authentication\AuthenticationManager.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */