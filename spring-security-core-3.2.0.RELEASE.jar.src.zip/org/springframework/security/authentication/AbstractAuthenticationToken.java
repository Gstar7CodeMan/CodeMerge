/*     */ package org.springframework.security.authentication;
/*     */ 
/*     */ import java.security.Principal;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import org.springframework.security.core.Authentication;
/*     */ import org.springframework.security.core.CredentialsContainer;
/*     */ import org.springframework.security.core.GrantedAuthority;
/*     */ import org.springframework.security.core.authority.AuthorityUtils;
/*     */ import org.springframework.security.core.userdetails.UserDetails;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AbstractAuthenticationToken
/*     */   implements Authentication, CredentialsContainer
/*     */ {
/*     */   private Object details;
/*     */   private final Collection<GrantedAuthority> authorities;
/*     */   private boolean authenticated = false;
/*     */   
/*     */   public AbstractAuthenticationToken(Collection<? extends GrantedAuthority> authorities) {
/*  54 */     if (authorities == null) {
/*  55 */       this.authorities = AuthorityUtils.NO_AUTHORITIES;
/*     */       
/*     */       return;
/*     */     } 
/*  59 */     for (GrantedAuthority a : authorities) {
/*  60 */       if (a == null) {
/*  61 */         throw new IllegalArgumentException("Authorities collection cannot contain any null elements");
/*     */       }
/*     */     } 
/*  64 */     ArrayList<GrantedAuthority> temp = new ArrayList<GrantedAuthority>(authorities.size());
/*  65 */     temp.addAll(authorities);
/*  66 */     this.authorities = Collections.unmodifiableList(temp);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Collection<GrantedAuthority> getAuthorities() {
/*  72 */     return this.authorities;
/*     */   }
/*     */   
/*     */   public String getName() {
/*  76 */     if (getPrincipal() instanceof UserDetails) {
/*  77 */       return ((UserDetails)getPrincipal()).getUsername();
/*     */     }
/*     */     
/*  80 */     if (getPrincipal() instanceof Principal) {
/*  81 */       return ((Principal)getPrincipal()).getName();
/*     */     }
/*     */     
/*  84 */     return (getPrincipal() == null) ? "" : getPrincipal().toString();
/*     */   }
/*     */   
/*     */   public boolean isAuthenticated() {
/*  88 */     return this.authenticated;
/*     */   }
/*     */   
/*     */   public void setAuthenticated(boolean authenticated) {
/*  92 */     this.authenticated = authenticated;
/*     */   }
/*     */   
/*     */   public Object getDetails() {
/*  96 */     return this.details;
/*     */   }
/*     */   
/*     */   public void setDetails(Object details) {
/* 100 */     this.details = details;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void eraseCredentials() {
/* 108 */     eraseSecret(getCredentials());
/* 109 */     eraseSecret(getPrincipal());
/* 110 */     eraseSecret(this.details);
/*     */   }
/*     */   
/*     */   private void eraseSecret(Object secret) {
/* 114 */     if (secret instanceof CredentialsContainer) {
/* 115 */       ((CredentialsContainer)secret).eraseCredentials();
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(Object obj) {
/* 121 */     if (!(obj instanceof AbstractAuthenticationToken)) {
/* 122 */       return false;
/*     */     }
/*     */     
/* 125 */     AbstractAuthenticationToken test = (AbstractAuthenticationToken)obj;
/*     */     
/* 127 */     if (!this.authorities.equals(test.authorities)) {
/* 128 */       return false;
/*     */     }
/*     */     
/* 131 */     if (this.details == null && test.getDetails() != null) {
/* 132 */       return false;
/*     */     }
/*     */     
/* 135 */     if (this.details != null && test.getDetails() == null) {
/* 136 */       return false;
/*     */     }
/*     */     
/* 139 */     if (this.details != null && !this.details.equals(test.getDetails())) {
/* 140 */       return false;
/*     */     }
/*     */     
/* 143 */     if (getCredentials() == null && test.getCredentials() != null) {
/* 144 */       return false;
/*     */     }
/*     */     
/* 147 */     if (getCredentials() != null && !getCredentials().equals(test.getCredentials())) {
/* 148 */       return false;
/*     */     }
/*     */     
/* 151 */     if (getPrincipal() == null && test.getPrincipal() != null) {
/* 152 */       return false;
/*     */     }
/*     */     
/* 155 */     if (getPrincipal() != null && !getPrincipal().equals(test.getPrincipal())) {
/* 156 */       return false;
/*     */     }
/*     */     
/* 159 */     return (isAuthenticated() == test.isAuthenticated());
/*     */   }
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 164 */     int code = 31;
/*     */     
/* 166 */     for (GrantedAuthority authority : this.authorities) {
/* 167 */       code ^= authority.hashCode();
/*     */     }
/*     */     
/* 170 */     if (getPrincipal() != null) {
/* 171 */       code ^= getPrincipal().hashCode();
/*     */     }
/*     */     
/* 174 */     if (getCredentials() != null) {
/* 175 */       code ^= getCredentials().hashCode();
/*     */     }
/*     */     
/* 178 */     if (getDetails() != null) {
/* 179 */       code ^= getDetails().hashCode();
/*     */     }
/*     */     
/* 182 */     if (isAuthenticated()) {
/* 183 */       code ^= 0xFFFFFFDB;
/*     */     }
/*     */     
/* 186 */     return code;
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 191 */     StringBuilder sb = new StringBuilder();
/* 192 */     sb.append(super.toString()).append(": ");
/* 193 */     sb.append("Principal: ").append(getPrincipal()).append("; ");
/* 194 */     sb.append("Credentials: [PROTECTED]; ");
/* 195 */     sb.append("Authenticated: ").append(isAuthenticated()).append("; ");
/* 196 */     sb.append("Details: ").append(getDetails()).append("; ");
/*     */     
/* 198 */     if (!this.authorities.isEmpty()) {
/* 199 */       sb.append("Granted Authorities: ");
/*     */       
/* 201 */       int i = 0;
/* 202 */       for (GrantedAuthority authority : this.authorities) {
/* 203 */         if (i++ > 0) {
/* 204 */           sb.append(", ");
/*     */         }
/*     */         
/* 207 */         sb.append(authority);
/*     */       } 
/*     */     } else {
/* 210 */       sb.append("Not granted any authorities");
/*     */     } 
/*     */     
/* 213 */     return sb.toString();
/*     */   }
/*     */ }


/* Location:              C:\Users\Gcorp\Downloads\spring-security-core-3.2.0.RELEASE.jar!\org\springframework\security\authentication\AbstractAuthenticationToken.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */