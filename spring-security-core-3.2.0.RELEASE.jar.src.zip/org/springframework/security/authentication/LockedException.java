/*    */ package org.springframework.security.authentication;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class LockedException
/*    */   extends AccountStatusException
/*    */ {
/*    */   public LockedException(String msg) {
/* 34 */     super(msg);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public LockedException(String msg, Throwable t) {
/* 45 */     super(msg, t);
/*    */   }
/*    */   
/*    */   @Deprecated
/*    */   public LockedException(String msg, Object extraInformation) {
/* 50 */     super(msg, extraInformation);
/*    */   }
/*    */ }


/* Location:              C:\Users\Gcorp\Downloads\spring-security-core-3.2.0.RELEASE.jar!\org\springframework\security\authentication\LockedException.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */