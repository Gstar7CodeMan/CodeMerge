/*    */ package org.springframework.security.authentication;
/*    */ 
/*    */ import org.springframework.beans.factory.InitializingBean;
/*    */ import org.springframework.context.MessageSource;
/*    */ import org.springframework.context.MessageSourceAware;
/*    */ import org.springframework.context.support.MessageSourceAccessor;
/*    */ import org.springframework.security.core.Authentication;
/*    */ import org.springframework.security.core.AuthenticationException;
/*    */ import org.springframework.security.core.SpringSecurityMessageSource;
/*    */ import org.springframework.util.Assert;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class AnonymousAuthenticationProvider
/*    */   implements AuthenticationProvider, InitializingBean, MessageSourceAware
/*    */ {
/* 40 */   protected MessageSourceAccessor messages = SpringSecurityMessageSource.getAccessor();
/*    */ 
/*    */   
/*    */   private String key;
/*    */ 
/*    */ 
/*    */   
/*    */   @Deprecated
/*    */   public AnonymousAuthenticationProvider() {}
/*    */ 
/*    */   
/*    */   public AnonymousAuthenticationProvider(String key) {
/* 52 */     this.key = key;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void afterPropertiesSet() throws Exception {
/* 58 */     Assert.hasLength(this.key, "A Key is required");
/*    */   }
/*    */ 
/*    */   
/*    */   public Authentication authenticate(Authentication authentication) throws AuthenticationException {
/* 63 */     if (!supports(authentication.getClass())) {
/* 64 */       return null;
/*    */     }
/*    */     
/* 67 */     if (this.key.hashCode() != ((AnonymousAuthenticationToken)authentication).getKeyHash()) {
/* 68 */       throw new BadCredentialsException(this.messages.getMessage("AnonymousAuthenticationProvider.incorrectKey", "The presented AnonymousAuthenticationToken does not contain the expected key"));
/*    */     }
/*    */ 
/*    */     
/* 72 */     return authentication;
/*    */   }
/*    */   
/*    */   public String getKey() {
/* 76 */     return this.key;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   @Deprecated
/*    */   public void setKey(String key) {
/* 85 */     this.key = key;
/*    */   }
/*    */   
/*    */   public void setMessageSource(MessageSource messageSource) {
/* 89 */     Assert.notNull(messageSource, "messageSource cannot be null");
/* 90 */     this.messages = new MessageSourceAccessor(messageSource);
/*    */   }
/*    */   
/*    */   public boolean supports(Class<?> authentication) {
/* 94 */     return AnonymousAuthenticationToken.class.isAssignableFrom(authentication);
/*    */   }
/*    */ }


/* Location:              C:\Users\Gcorp\Downloads\spring-security-core-3.2.0.RELEASE.jar!\org\springframework\security\authentication\AnonymousAuthenticationProvider.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */