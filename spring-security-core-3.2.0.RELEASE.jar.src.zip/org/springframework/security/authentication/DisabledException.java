/*    */ package org.springframework.security.authentication;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DisabledException
/*    */   extends AccountStatusException
/*    */ {
/*    */   public DisabledException(String msg) {
/* 33 */     super(msg);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public DisabledException(String msg, Throwable t) {
/* 44 */     super(msg, t);
/*    */   }
/*    */   
/*    */   @Deprecated
/*    */   public DisabledException(String msg, Object extraInformation) {
/* 49 */     super(msg, extraInformation);
/*    */   }
/*    */ }


/* Location:              C:\Users\Gcorp\Downloads\spring-security-core-3.2.0.RELEASE.jar!\org\springframework\security\authentication\DisabledException.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */