/*    */ package org.springframework.security.authentication.encoding;
/*    */ 
/*    */ import org.springframework.security.crypto.codec.Utf8;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class PasswordEncoderUtils
/*    */ {
/*    */   static boolean equals(String expected, String actual) {
/* 21 */     byte[] expectedBytes = bytesUtf8(expected);
/* 22 */     byte[] actualBytes = bytesUtf8(actual);
/* 23 */     int expectedLength = (expectedBytes == null) ? -1 : expectedBytes.length;
/* 24 */     int actualLength = (actualBytes == null) ? -1 : actualBytes.length;
/* 25 */     if (expectedLength != actualLength) {
/* 26 */       return false;
/*    */     }
/*    */     
/* 29 */     int result = 0;
/* 30 */     for (int i = 0; i < expectedLength; i++) {
/* 31 */       result |= expectedBytes[i] ^ actualBytes[i];
/*    */     }
/* 33 */     return (result == 0);
/*    */   }
/*    */   
/*    */   private static byte[] bytesUtf8(String s) {
/* 37 */     if (s == null) {
/* 38 */       return null;
/*    */     }
/*    */     
/* 41 */     return Utf8.encode(s);
/*    */   }
/*    */ }


/* Location:              C:\Users\Gcorp\Downloads\spring-security-core-3.2.0.RELEASE.jar!\org\springframework\security\authentication\encoding\PasswordEncoderUtils.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */