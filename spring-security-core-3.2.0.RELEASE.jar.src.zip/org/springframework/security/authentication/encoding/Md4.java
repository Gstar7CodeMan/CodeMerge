/*     */ package org.springframework.security.authentication.encoding;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class Md4
/*     */ {
/*     */   private static final int BLOCK_SIZE = 64;
/*     */   private static final int HASH_SIZE = 16;
/*  25 */   private final byte[] buffer = new byte[64];
/*     */   private int bufferOffset;
/*     */   private long byteCount;
/*  28 */   private final int[] state = new int[4];
/*  29 */   private final int[] tmp = new int[16];
/*     */   
/*     */   Md4() {
/*  32 */     reset();
/*     */   }
/*     */   
/*     */   public void reset() {
/*  36 */     this.bufferOffset = 0;
/*  37 */     this.byteCount = 0L;
/*  38 */     this.state[0] = 1732584193;
/*  39 */     this.state[1] = -271733879;
/*  40 */     this.state[2] = -1732584194;
/*  41 */     this.state[3] = 271733878;
/*     */   }
/*     */   
/*     */   public byte[] digest() {
/*  45 */     byte[] resBuf = new byte[16];
/*  46 */     digest(resBuf, 0, 16);
/*  47 */     return resBuf;
/*     */   }
/*     */   
/*     */   private void digest(byte[] buffer, int off) {
/*  51 */     for (int i = 0; i < 4; i++) {
/*  52 */       for (int j = 0; j < 4; j++) {
/*  53 */         buffer[off + i * 4 + j] = (byte)(this.state[i] >>> 8 * j);
/*     */       }
/*     */     } 
/*     */   }
/*     */   
/*     */   private void digest(byte[] buffer, int offset, int len) {
/*  59 */     this.buffer[this.bufferOffset++] = Byte.MIN_VALUE;
/*  60 */     int lenOfBitLen = 8;
/*  61 */     int C = 64 - lenOfBitLen;
/*  62 */     if (this.bufferOffset > C) {
/*  63 */       while (this.bufferOffset < 64) {
/*  64 */         this.buffer[this.bufferOffset++] = 0;
/*     */       }
/*  66 */       update(this.buffer, 0);
/*  67 */       this.bufferOffset = 0;
/*     */     } 
/*     */     
/*  70 */     while (this.bufferOffset < C) {
/*  71 */       this.buffer[this.bufferOffset++] = 0;
/*     */     }
/*     */     
/*  74 */     long bitCount = this.byteCount * 8L;
/*  75 */     for (int i = 0; i < 64; i += 8) {
/*  76 */       this.buffer[this.bufferOffset++] = (byte)(int)(bitCount >>> i);
/*     */     }
/*     */     
/*  79 */     update(this.buffer, 0);
/*  80 */     digest(buffer, offset);
/*     */   }
/*     */   
/*     */   public void update(byte[] input, int offset, int length) {
/*  84 */     this.byteCount += length;
/*     */     int todo;
/*  86 */     while (length >= (todo = 64 - this.bufferOffset)) {
/*  87 */       System.arraycopy(input, offset, this.buffer, this.bufferOffset, todo);
/*  88 */       update(this.buffer, 0);
/*  89 */       length -= todo;
/*  90 */       offset += todo;
/*  91 */       this.bufferOffset = 0;
/*     */     } 
/*     */     
/*  94 */     System.arraycopy(input, offset, this.buffer, this.bufferOffset, length);
/*  95 */     this.bufferOffset += length;
/*     */   }
/*     */   
/*     */   private void update(byte[] block, int offset) {
/*  99 */     for (int i = 0; i < 16; i++) {
/* 100 */       this.tmp[i] = block[offset++] & 0xFF | (block[offset++] & 0xFF) << 8 | (block[offset++] & 0xFF) << 16 | (block[offset++] & 0xFF) << 24;
/*     */     }
/*     */     
/* 103 */     int A = this.state[0];
/* 104 */     int B = this.state[1];
/* 105 */     int C = this.state[2];
/* 106 */     int D = this.state[3];
/*     */     
/* 108 */     A = FF(A, B, C, D, this.tmp[0], 3);
/* 109 */     D = FF(D, A, B, C, this.tmp[1], 7);
/* 110 */     C = FF(C, D, A, B, this.tmp[2], 11);
/* 111 */     B = FF(B, C, D, A, this.tmp[3], 19);
/* 112 */     A = FF(A, B, C, D, this.tmp[4], 3);
/* 113 */     D = FF(D, A, B, C, this.tmp[5], 7);
/* 114 */     C = FF(C, D, A, B, this.tmp[6], 11);
/* 115 */     B = FF(B, C, D, A, this.tmp[7], 19);
/* 116 */     A = FF(A, B, C, D, this.tmp[8], 3);
/* 117 */     D = FF(D, A, B, C, this.tmp[9], 7);
/* 118 */     C = FF(C, D, A, B, this.tmp[10], 11);
/* 119 */     B = FF(B, C, D, A, this.tmp[11], 19);
/* 120 */     A = FF(A, B, C, D, this.tmp[12], 3);
/* 121 */     D = FF(D, A, B, C, this.tmp[13], 7);
/* 122 */     C = FF(C, D, A, B, this.tmp[14], 11);
/* 123 */     B = FF(B, C, D, A, this.tmp[15], 19);
/*     */     
/* 125 */     A = GG(A, B, C, D, this.tmp[0], 3);
/* 126 */     D = GG(D, A, B, C, this.tmp[4], 5);
/* 127 */     C = GG(C, D, A, B, this.tmp[8], 9);
/* 128 */     B = GG(B, C, D, A, this.tmp[12], 13);
/* 129 */     A = GG(A, B, C, D, this.tmp[1], 3);
/* 130 */     D = GG(D, A, B, C, this.tmp[5], 5);
/* 131 */     C = GG(C, D, A, B, this.tmp[9], 9);
/* 132 */     B = GG(B, C, D, A, this.tmp[13], 13);
/* 133 */     A = GG(A, B, C, D, this.tmp[2], 3);
/* 134 */     D = GG(D, A, B, C, this.tmp[6], 5);
/* 135 */     C = GG(C, D, A, B, this.tmp[10], 9);
/* 136 */     B = GG(B, C, D, A, this.tmp[14], 13);
/* 137 */     A = GG(A, B, C, D, this.tmp[3], 3);
/* 138 */     D = GG(D, A, B, C, this.tmp[7], 5);
/* 139 */     C = GG(C, D, A, B, this.tmp[11], 9);
/* 140 */     B = GG(B, C, D, A, this.tmp[15], 13);
/*     */     
/* 142 */     A = HH(A, B, C, D, this.tmp[0], 3);
/* 143 */     D = HH(D, A, B, C, this.tmp[8], 9);
/* 144 */     C = HH(C, D, A, B, this.tmp[4], 11);
/* 145 */     B = HH(B, C, D, A, this.tmp[12], 15);
/* 146 */     A = HH(A, B, C, D, this.tmp[2], 3);
/* 147 */     D = HH(D, A, B, C, this.tmp[10], 9);
/* 148 */     C = HH(C, D, A, B, this.tmp[6], 11);
/* 149 */     B = HH(B, C, D, A, this.tmp[14], 15);
/* 150 */     A = HH(A, B, C, D, this.tmp[1], 3);
/* 151 */     D = HH(D, A, B, C, this.tmp[9], 9);
/* 152 */     C = HH(C, D, A, B, this.tmp[5], 11);
/* 153 */     B = HH(B, C, D, A, this.tmp[13], 15);
/* 154 */     A = HH(A, B, C, D, this.tmp[3], 3);
/* 155 */     D = HH(D, A, B, C, this.tmp[11], 9);
/* 156 */     C = HH(C, D, A, B, this.tmp[7], 11);
/* 157 */     B = HH(B, C, D, A, this.tmp[15], 15);
/*     */     
/* 159 */     this.state[0] = this.state[0] + A;
/* 160 */     this.state[1] = this.state[1] + B;
/* 161 */     this.state[2] = this.state[2] + C;
/* 162 */     this.state[3] = this.state[3] + D;
/*     */   }
/*     */   
/*     */   private int FF(int a, int b, int c, int d, int x, int s) {
/* 166 */     int t = a + (b & c | (b ^ 0xFFFFFFFF) & d) + x;
/* 167 */     return t << s | t >>> 32 - s;
/*     */   }
/*     */   
/*     */   private int GG(int a, int b, int c, int d, int x, int s) {
/* 171 */     int t = a + (b & (c | d) | c & d) + x + 1518500249;
/* 172 */     return t << s | t >>> 32 - s;
/*     */   }
/*     */   
/*     */   private int HH(int a, int b, int c, int d, int x, int s) {
/* 176 */     int t = a + (b ^ c ^ d) + x + 1859775393;
/* 177 */     return t << s | t >>> 32 - s;
/*     */   }
/*     */ }


/* Location:              C:\Users\Gcorp\Downloads\spring-security-core-3.2.0.RELEASE.jar!\org\springframework\security\authentication\encoding\Md4.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */