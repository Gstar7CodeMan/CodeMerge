/*     */ package org.springframework.security.authentication.encoding;
/*     */ 
/*     */ import java.security.MessageDigest;
/*     */ import java.security.NoSuchAlgorithmException;
/*     */ import org.springframework.security.crypto.codec.Base64;
/*     */ import org.springframework.security.crypto.codec.Utf8;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class LdapShaPasswordEncoder
/*     */   implements PasswordEncoder
/*     */ {
/*     */   private static final int SHA_LENGTH = 20;
/*     */   private static final String SSHA_PREFIX = "{SSHA}";
/*  43 */   private static final String SSHA_PREFIX_LC = "{SSHA}".toLowerCase();
/*     */   private static final String SHA_PREFIX = "{SHA}";
/*  45 */   private static final String SHA_PREFIX_LC = "{SHA}".toLowerCase();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean forceLowerCasePrefix;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private byte[] combineHashAndSalt(byte[] hash, byte[] salt) {
/*  57 */     if (salt == null) {
/*  58 */       return hash;
/*     */     }
/*     */     
/*  61 */     byte[] hashAndSalt = new byte[hash.length + salt.length];
/*  62 */     System.arraycopy(hash, 0, hashAndSalt, 0, hash.length);
/*  63 */     System.arraycopy(salt, 0, hashAndSalt, hash.length, salt.length);
/*     */     
/*  65 */     return hashAndSalt;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String encodePassword(String rawPass, Object salt) {
/*     */     MessageDigest sha;
/*     */     String prefix;
/*     */     try {
/*  82 */       sha = MessageDigest.getInstance("SHA");
/*  83 */       sha.update(Utf8.encode(rawPass));
/*  84 */     } catch (NoSuchAlgorithmException e) {
/*  85 */       throw new IllegalStateException("No SHA implementation available!");
/*     */     } 
/*     */     
/*  88 */     if (salt != null) {
/*  89 */       Assert.isInstanceOf(byte[].class, salt, "Salt value must be a byte array");
/*  90 */       sha.update((byte[])salt);
/*     */     } 
/*     */     
/*  93 */     byte[] hash = combineHashAndSalt(sha.digest(), (byte[])salt);
/*     */ 
/*     */ 
/*     */     
/*  97 */     if (salt == null) {
/*  98 */       prefix = this.forceLowerCasePrefix ? SHA_PREFIX_LC : "{SHA}";
/*     */     } else {
/* 100 */       prefix = this.forceLowerCasePrefix ? SSHA_PREFIX_LC : "{SSHA}";
/*     */     } 
/*     */     
/* 103 */     return prefix + Utf8.decode(Base64.encode(hash));
/*     */   }
/*     */   
/*     */   private byte[] extractSalt(String encPass) {
/* 107 */     String encPassNoLabel = encPass.substring(6);
/*     */     
/* 109 */     byte[] hashAndSalt = Base64.decode(encPassNoLabel.getBytes());
/* 110 */     int saltLength = hashAndSalt.length - 20;
/* 111 */     byte[] salt = new byte[saltLength];
/* 112 */     System.arraycopy(hashAndSalt, 20, salt, 0, saltLength);
/*     */     
/* 114 */     return salt;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isPasswordValid(String encPass, String rawPass, Object salt) {
/* 128 */     String prefix = extractPrefix(encPass);
/*     */     
/* 130 */     if (prefix == null) {
/* 131 */       return encPass.equals(rawPass);
/*     */     }
/*     */     
/* 134 */     if (prefix.equals("{SSHA}") || prefix.equals(SSHA_PREFIX_LC))
/* 135 */     { salt = extractSalt(encPass); }
/* 136 */     else { if (!prefix.equals("{SHA}") && !prefix.equals(SHA_PREFIX_LC)) {
/* 137 */         throw new IllegalArgumentException("Unsupported password prefix '" + prefix + "'");
/*     */       }
/*     */       
/* 140 */       salt = null; }
/*     */ 
/*     */     
/* 143 */     int startOfHash = prefix.length();
/*     */     
/* 145 */     String encodedRawPass = encodePassword(rawPass, salt).substring(startOfHash);
/*     */     
/* 147 */     return PasswordEncoderUtils.equals(encodedRawPass, encPass.substring(startOfHash));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String extractPrefix(String encPass) {
/* 154 */     if (!encPass.startsWith("{")) {
/* 155 */       return null;
/*     */     }
/*     */     
/* 158 */     int secondBrace = encPass.lastIndexOf('}');
/*     */     
/* 160 */     if (secondBrace < 0) {
/* 161 */       throw new IllegalArgumentException("Couldn't find closing brace for SHA prefix");
/*     */     }
/*     */     
/* 164 */     return encPass.substring(0, secondBrace + 1);
/*     */   }
/*     */   
/*     */   public void setForceLowerCasePrefix(boolean forceLowerCasePrefix) {
/* 168 */     this.forceLowerCasePrefix = forceLowerCasePrefix;
/*     */   }
/*     */ }


/* Location:              C:\Users\Gcorp\Downloads\spring-security-core-3.2.0.RELEASE.jar!\org\springframework\security\authentication\encoding\LdapShaPasswordEncoder.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */