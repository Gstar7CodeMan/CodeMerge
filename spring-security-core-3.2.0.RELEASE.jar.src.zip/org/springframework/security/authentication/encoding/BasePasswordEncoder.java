/*    */ package org.springframework.security.authentication.encoding;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class BasePasswordEncoder
/*    */   implements PasswordEncoder
/*    */ {
/*    */   protected String[] demergePasswordAndSalt(String mergedPasswordSalt) {
/* 39 */     if (mergedPasswordSalt == null || "".equals(mergedPasswordSalt)) {
/* 40 */       throw new IllegalArgumentException("Cannot pass a null or empty String");
/*    */     }
/*    */     
/* 43 */     String password = mergedPasswordSalt;
/* 44 */     String salt = "";
/*    */     
/* 46 */     int saltBegins = mergedPasswordSalt.lastIndexOf("{");
/*    */     
/* 48 */     if (saltBegins != -1 && saltBegins + 1 < mergedPasswordSalt.length()) {
/* 49 */       salt = mergedPasswordSalt.substring(saltBegins + 1, mergedPasswordSalt.length() - 1);
/* 50 */       password = mergedPasswordSalt.substring(0, saltBegins);
/*    */     } 
/*    */     
/* 53 */     return new String[] { password, salt };
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected String mergePasswordAndSalt(String password, Object salt, boolean strict) {
/* 73 */     if (password == null) {
/* 74 */       password = "";
/*    */     }
/*    */     
/* 77 */     if (strict && salt != null && (
/* 78 */       salt.toString().lastIndexOf("{") != -1 || salt.toString().lastIndexOf("}") != -1)) {
/* 79 */       throw new IllegalArgumentException("Cannot use { or } in salt.toString()");
/*    */     }
/*    */ 
/*    */     
/* 83 */     if (salt == null || "".equals(salt)) {
/* 84 */       return password;
/*    */     }
/* 86 */     return password + "{" + salt.toString() + "}";
/*    */   }
/*    */ }


/* Location:              C:\Users\Gcorp\Downloads\spring-security-core-3.2.0.RELEASE.jar!\org\springframework\security\authentication\encoding\BasePasswordEncoder.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */