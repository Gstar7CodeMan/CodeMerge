package org.springframework.security.authentication.encoding;

@Deprecated
public interface PasswordEncoder {
  String encodePassword(String paramString, Object paramObject);
  
  boolean isPasswordValid(String paramString1, String paramString2, Object paramObject);
}


/* Location:              C:\Users\Gcorp\Downloads\spring-security-core-3.2.0.RELEASE.jar!\org\springframework\security\authentication\encoding\PasswordEncoder.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */