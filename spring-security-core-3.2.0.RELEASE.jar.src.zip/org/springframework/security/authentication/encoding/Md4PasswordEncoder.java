/*    */ package org.springframework.security.authentication.encoding;
/*    */ 
/*    */ import org.springframework.security.crypto.codec.Base64;
/*    */ import org.springframework.security.crypto.codec.Hex;
/*    */ import org.springframework.security.crypto.codec.Utf8;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Md4PasswordEncoder
/*    */   extends BaseDigestPasswordEncoder
/*    */ {
/*    */   public String encodePassword(String rawPass, Object salt) {
/* 48 */     String saltedPass = mergePasswordAndSalt(rawPass, salt, false);
/*    */     
/* 50 */     byte[] passBytes = Utf8.encode(saltedPass);
/*    */     
/* 52 */     Md4 md4 = new Md4();
/* 53 */     md4.update(passBytes, 0, passBytes.length);
/*    */     
/* 55 */     byte[] resBuf = md4.digest();
/*    */     
/* 57 */     if (getEncodeHashAsBase64()) {
/* 58 */       return Utf8.decode(Base64.encode(resBuf));
/*    */     }
/* 60 */     return new String(Hex.encode(resBuf));
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean isPasswordValid(String encPass, String rawPass, Object salt) {
/* 74 */     String pass1 = "" + encPass;
/* 75 */     String pass2 = encodePassword(rawPass, salt);
/* 76 */     return PasswordEncoderUtils.equals(pass1, pass2);
/*    */   }
/*    */   
/*    */   public String getAlgorithm() {
/* 80 */     return "MD4";
/*    */   }
/*    */ }


/* Location:              C:\Users\Gcorp\Downloads\spring-security-core-3.2.0.RELEASE.jar!\org\springframework\security\authentication\encoding\Md4PasswordEncoder.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */