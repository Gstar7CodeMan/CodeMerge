/*     */ package org.springframework.security.authentication.encoding;
/*     */ 
/*     */ import java.security.MessageDigest;
/*     */ import java.security.NoSuchAlgorithmException;
/*     */ import org.springframework.security.crypto.codec.Base64;
/*     */ import org.springframework.security.crypto.codec.Hex;
/*     */ import org.springframework.security.crypto.codec.Utf8;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MessageDigestPasswordEncoder
/*     */   extends BaseDigestPasswordEncoder
/*     */ {
/*     */   private final String algorithm;
/*  42 */   private int iterations = 1;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MessageDigestPasswordEncoder(String algorithm) {
/*  52 */     this(algorithm, false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MessageDigestPasswordEncoder(String algorithm, boolean encodeHashAsBase64) throws IllegalArgumentException {
/*  63 */     this.algorithm = algorithm;
/*  64 */     setEncodeHashAsBase64(encodeHashAsBase64);
/*     */     
/*  66 */     getMessageDigest();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String encodePassword(String rawPass, Object salt) {
/*  78 */     String saltedPass = mergePasswordAndSalt(rawPass, salt, false);
/*     */     
/*  80 */     MessageDigest messageDigest = getMessageDigest();
/*     */     
/*  82 */     byte[] digest = messageDigest.digest(Utf8.encode(saltedPass));
/*     */ 
/*     */     
/*  85 */     for (int i = 1; i < this.iterations; i++) {
/*  86 */       digest = messageDigest.digest(digest);
/*     */     }
/*     */     
/*  89 */     if (getEncodeHashAsBase64()) {
/*  90 */       return Utf8.decode(Base64.encode(digest));
/*     */     }
/*  92 */     return new String(Hex.encode(digest));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final MessageDigest getMessageDigest() throws IllegalArgumentException {
/*     */     try {
/* 105 */       return MessageDigest.getInstance(this.algorithm);
/* 106 */     } catch (NoSuchAlgorithmException e) {
/* 107 */       throw new IllegalArgumentException("No such algorithm [" + this.algorithm + "]");
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isPasswordValid(String encPass, String rawPass, Object salt) {
/* 121 */     String pass1 = "" + encPass;
/* 122 */     String pass2 = encodePassword(rawPass, salt);
/*     */     
/* 124 */     return PasswordEncoderUtils.equals(pass1, pass2);
/*     */   }
/*     */   
/*     */   public String getAlgorithm() {
/* 128 */     return this.algorithm;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setIterations(int iterations) {
/* 140 */     Assert.isTrue((iterations > 0), "Iterations value must be greater than zero");
/* 141 */     this.iterations = iterations;
/*     */   }
/*     */ }


/* Location:              C:\Users\Gcorp\Downloads\spring-security-core-3.2.0.RELEASE.jar!\org\springframework\security\authentication\encoding\MessageDigestPasswordEncoder.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */