/*    */ package org.springframework.security.authentication.encoding;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class BaseDigestPasswordEncoder
/*    */   extends BasePasswordEncoder
/*    */ {
/*    */   private boolean encodeHashAsBase64 = false;
/*    */   
/*    */   public boolean getEncodeHashAsBase64() {
/* 31 */     return this.encodeHashAsBase64;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void setEncodeHashAsBase64(boolean encodeHashAsBase64) {
/* 41 */     this.encodeHashAsBase64 = encodeHashAsBase64;
/*    */   }
/*    */ }


/* Location:              C:\Users\Gcorp\Downloads\spring-security-core-3.2.0.RELEASE.jar!\org\springframework\security\authentication\encoding\BaseDigestPasswordEncoder.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */