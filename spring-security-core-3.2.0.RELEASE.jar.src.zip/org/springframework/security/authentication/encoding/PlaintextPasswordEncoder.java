/*    */ package org.springframework.security.authentication.encoding;
/*    */ 
/*    */ import java.util.Locale;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class PlaintextPasswordEncoder
/*    */   extends BasePasswordEncoder
/*    */ {
/*    */   private boolean ignorePasswordCase = false;
/*    */   
/*    */   public String encodePassword(String rawPass, Object salt) {
/* 36 */     return mergePasswordAndSalt(rawPass, salt, true);
/*    */   }
/*    */   
/*    */   public boolean isIgnorePasswordCase() {
/* 40 */     return this.ignorePasswordCase;
/*    */   }
/*    */   
/*    */   public boolean isPasswordValid(String encPass, String rawPass, Object salt) {
/* 44 */     String pass1 = encPass + "";
/*    */ 
/*    */ 
/*    */ 
/*    */     
/* 49 */     String pass2 = mergePasswordAndSalt(rawPass, salt, false);
/*    */     
/* 51 */     if (this.ignorePasswordCase) {
/*    */       
/* 53 */       pass1 = pass1.toLowerCase(Locale.ENGLISH);
/* 54 */       pass2 = pass2.toLowerCase(Locale.ENGLISH);
/*    */     } 
/* 56 */     return PasswordEncoderUtils.equals(pass1, pass2);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public String[] obtainPasswordAndSalt(String password) {
/* 69 */     return demergePasswordAndSalt(password);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void setIgnorePasswordCase(boolean ignorePasswordCase) {
/* 79 */     this.ignorePasswordCase = ignorePasswordCase;
/*    */   }
/*    */ }


/* Location:              C:\Users\Gcorp\Downloads\spring-security-core-3.2.0.RELEASE.jar!\org\springframework\security\authentication\encoding\PlaintextPasswordEncoder.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */