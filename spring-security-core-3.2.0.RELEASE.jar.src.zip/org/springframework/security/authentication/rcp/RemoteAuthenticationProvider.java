/*    */ package org.springframework.security.authentication.rcp;
/*    */ 
/*    */ import java.util.Collection;
/*    */ import org.springframework.beans.factory.InitializingBean;
/*    */ import org.springframework.security.authentication.AuthenticationProvider;
/*    */ import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
/*    */ import org.springframework.security.core.Authentication;
/*    */ import org.springframework.security.core.AuthenticationException;
/*    */ import org.springframework.security.core.GrantedAuthority;
/*    */ import org.springframework.util.Assert;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class RemoteAuthenticationProvider
/*    */   implements AuthenticationProvider, InitializingBean
/*    */ {
/*    */   private RemoteAuthenticationManager remoteAuthenticationManager;
/*    */   
/*    */   public void afterPropertiesSet() throws Exception {
/* 54 */     Assert.notNull(this.remoteAuthenticationManager, "remoteAuthenticationManager is mandatory");
/*    */   }
/*    */ 
/*    */   
/*    */   public Authentication authenticate(Authentication authentication) throws AuthenticationException {
/* 59 */     String username = authentication.getPrincipal().toString();
/* 60 */     Object credentials = authentication.getCredentials();
/* 61 */     String password = (credentials == null) ? null : credentials.toString();
/* 62 */     Collection<? extends GrantedAuthority> authorities = this.remoteAuthenticationManager.attemptAuthentication(username, password);
/*    */     
/* 64 */     return (Authentication)new UsernamePasswordAuthenticationToken(username, password, authorities);
/*    */   }
/*    */   
/*    */   public RemoteAuthenticationManager getRemoteAuthenticationManager() {
/* 68 */     return this.remoteAuthenticationManager;
/*    */   }
/*    */   
/*    */   public void setRemoteAuthenticationManager(RemoteAuthenticationManager remoteAuthenticationManager) {
/* 72 */     this.remoteAuthenticationManager = remoteAuthenticationManager;
/*    */   }
/*    */   
/*    */   public boolean supports(Class<?> authentication) {
/* 76 */     return UsernamePasswordAuthenticationToken.class.isAssignableFrom(authentication);
/*    */   }
/*    */ }


/* Location:              C:\Users\Gcorp\Downloads\spring-security-core-3.2.0.RELEASE.jar!\org\springframework\security\authentication\rcp\RemoteAuthenticationProvider.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */