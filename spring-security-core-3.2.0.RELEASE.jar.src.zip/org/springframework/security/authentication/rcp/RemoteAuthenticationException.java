/*    */ package org.springframework.security.authentication.rcp;
/*    */ 
/*    */ import org.springframework.core.NestedRuntimeException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class RemoteAuthenticationException
/*    */   extends NestedRuntimeException
/*    */ {
/*    */   private static final long serialVersionUID = 320L;
/*    */   
/*    */   public RemoteAuthenticationException(String msg) {
/* 43 */     super(msg);
/*    */   }
/*    */ }


/* Location:              C:\Users\Gcorp\Downloads\spring-security-core-3.2.0.RELEASE.jar!\org\springframework\security\authentication\rcp\RemoteAuthenticationException.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */