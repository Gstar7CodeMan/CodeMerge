/*    */ package org.springframework.security.authentication.rcp;
/*    */ 
/*    */ import java.util.Collection;
/*    */ import org.springframework.beans.factory.InitializingBean;
/*    */ import org.springframework.security.authentication.AuthenticationManager;
/*    */ import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
/*    */ import org.springframework.security.core.Authentication;
/*    */ import org.springframework.security.core.AuthenticationException;
/*    */ import org.springframework.security.core.GrantedAuthority;
/*    */ import org.springframework.util.Assert;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class RemoteAuthenticationManagerImpl
/*    */   implements RemoteAuthenticationManager, InitializingBean
/*    */ {
/*    */   private AuthenticationManager authenticationManager;
/*    */   
/*    */   public void afterPropertiesSet() throws Exception {
/* 44 */     Assert.notNull(this.authenticationManager, "authenticationManager is required");
/*    */   }
/*    */ 
/*    */   
/*    */   public Collection<? extends GrantedAuthority> attemptAuthentication(String username, String password) throws RemoteAuthenticationException {
/* 49 */     UsernamePasswordAuthenticationToken request = new UsernamePasswordAuthenticationToken(username, password);
/*    */     
/*    */     try {
/* 52 */       return this.authenticationManager.authenticate((Authentication)request).getAuthorities();
/* 53 */     } catch (AuthenticationException authEx) {
/* 54 */       throw new RemoteAuthenticationException(authEx.getMessage());
/*    */     } 
/*    */   }
/*    */   
/*    */   protected AuthenticationManager getAuthenticationManager() {
/* 59 */     return this.authenticationManager;
/*    */   }
/*    */   
/*    */   public void setAuthenticationManager(AuthenticationManager authenticationManager) {
/* 63 */     this.authenticationManager = authenticationManager;
/*    */   }
/*    */ }


/* Location:              C:\Users\Gcorp\Downloads\spring-security-core-3.2.0.RELEASE.jar!\org\springframework\security\authentication\rcp\RemoteAuthenticationManagerImpl.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */