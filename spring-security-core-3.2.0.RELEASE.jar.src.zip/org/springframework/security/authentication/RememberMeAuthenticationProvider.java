/*    */ package org.springframework.security.authentication;
/*    */ 
/*    */ import org.springframework.beans.factory.InitializingBean;
/*    */ import org.springframework.context.MessageSource;
/*    */ import org.springframework.context.MessageSourceAware;
/*    */ import org.springframework.context.support.MessageSourceAccessor;
/*    */ import org.springframework.security.core.Authentication;
/*    */ import org.springframework.security.core.AuthenticationException;
/*    */ import org.springframework.security.core.SpringSecurityMessageSource;
/*    */ import org.springframework.util.Assert;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class RememberMeAuthenticationProvider
/*    */   implements AuthenticationProvider, InitializingBean, MessageSourceAware
/*    */ {
/* 37 */   protected MessageSourceAccessor messages = SpringSecurityMessageSource.getAccessor();
/*    */ 
/*    */   
/*    */   private String key;
/*    */ 
/*    */   
/*    */   @Deprecated
/*    */   public RememberMeAuthenticationProvider() {}
/*    */ 
/*    */   
/*    */   public RememberMeAuthenticationProvider(String key) {
/* 48 */     this.key = key;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void afterPropertiesSet() throws Exception {
/* 54 */     Assert.hasLength(this.key);
/* 55 */     Assert.notNull(this.messages, "A message source must be set");
/*    */   }
/*    */   
/*    */   public Authentication authenticate(Authentication authentication) throws AuthenticationException {
/* 59 */     if (!supports(authentication.getClass())) {
/* 60 */       return null;
/*    */     }
/*    */     
/* 63 */     if (this.key.hashCode() != ((RememberMeAuthenticationToken)authentication).getKeyHash()) {
/* 64 */       throw new BadCredentialsException(this.messages.getMessage("RememberMeAuthenticationProvider.incorrectKey", "The presented RememberMeAuthenticationToken does not contain the expected key"));
/*    */     }
/*    */ 
/*    */     
/* 68 */     return authentication;
/*    */   }
/*    */   
/*    */   public String getKey() {
/* 72 */     return this.key;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   @Deprecated
/*    */   public void setKey(String key) {
/* 81 */     this.key = key;
/*    */   }
/*    */   
/*    */   public void setMessageSource(MessageSource messageSource) {
/* 85 */     this.messages = new MessageSourceAccessor(messageSource);
/*    */   }
/*    */   
/*    */   public boolean supports(Class<?> authentication) {
/* 89 */     return RememberMeAuthenticationToken.class.isAssignableFrom(authentication);
/*    */   }
/*    */ }


/* Location:              C:\Users\Gcorp\Downloads\spring-security-core-3.2.0.RELEASE.jar!\org\springframework\security\authentication\RememberMeAuthenticationProvider.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */