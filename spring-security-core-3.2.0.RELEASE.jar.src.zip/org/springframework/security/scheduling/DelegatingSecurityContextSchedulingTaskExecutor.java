/*    */ package org.springframework.security.scheduling;
/*    */ 
/*    */ import org.springframework.core.task.AsyncTaskExecutor;
/*    */ import org.springframework.scheduling.SchedulingTaskExecutor;
/*    */ import org.springframework.security.core.context.SecurityContext;
/*    */ import org.springframework.security.task.DelegatingSecurityContextAsyncTaskExecutor;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DelegatingSecurityContextSchedulingTaskExecutor
/*    */   extends DelegatingSecurityContextAsyncTaskExecutor
/*    */   implements SchedulingTaskExecutor
/*    */ {
/*    */   public DelegatingSecurityContextSchedulingTaskExecutor(SchedulingTaskExecutor delegateSchedulingTaskExecutor, SecurityContext securityContext) {
/* 43 */     super((AsyncTaskExecutor)delegateSchedulingTaskExecutor, securityContext);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public DelegatingSecurityContextSchedulingTaskExecutor(SchedulingTaskExecutor delegateAsyncTaskExecutor) {
/* 52 */     this(delegateAsyncTaskExecutor, null);
/*    */   }
/*    */   
/*    */   public boolean prefersShortLivedTasks() {
/* 56 */     return getDelegate().prefersShortLivedTasks();
/*    */   }
/*    */   
/*    */   private SchedulingTaskExecutor getDelegate() {
/* 60 */     return (SchedulingTaskExecutor)getDelegateExecutor();
/*    */   }
/*    */ }


/* Location:              C:\Users\Gcorp\Downloads\spring-security-core-3.2.0.RELEASE.jar!\org\springframework\security\scheduling\DelegatingSecurityContextSchedulingTaskExecutor.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */