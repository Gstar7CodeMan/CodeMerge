/*    */ package org.springframework.security.concurrent;
/*    */ 
/*    */ import org.springframework.security.core.context.SecurityContext;
/*    */ import org.springframework.security.core.context.SecurityContextHolder;
/*    */ import org.springframework.util.Assert;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class DelegatingSecurityContextRunnable
/*    */   implements Runnable
/*    */ {
/*    */   private final Runnable delegate;
/*    */   private final SecurityContext securityContext;
/*    */   
/*    */   public DelegatingSecurityContextRunnable(Runnable delegate, SecurityContext securityContext) {
/* 39 */     Assert.notNull(delegate, "delegate cannot be null");
/* 40 */     Assert.notNull(securityContext, "securityContext cannot be null");
/* 41 */     this.delegate = delegate;
/* 42 */     this.securityContext = securityContext;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public DelegatingSecurityContextRunnable(Runnable delegate) {
/* 51 */     this(delegate, SecurityContextHolder.getContext());
/*    */   }
/*    */   
/*    */   public void run() {
/*    */     try {
/* 56 */       SecurityContextHolder.setContext(this.securityContext);
/* 57 */       this.delegate.run();
/*    */     } finally {
/*    */       
/* 60 */       SecurityContextHolder.clearContext();
/*    */     } 
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static Runnable create(Runnable delegate, SecurityContext securityContext) {
/* 74 */     Assert.notNull(delegate, "delegate cannot be  null");
/* 75 */     return (securityContext == null) ? new DelegatingSecurityContextRunnable(delegate) : new DelegatingSecurityContextRunnable(delegate, securityContext);
/*    */   }
/*    */ }


/* Location:              C:\Users\Gcorp\Downloads\spring-security-core-3.2.0.RELEASE.jar!\org\springframework\security\concurrent\DelegatingSecurityContextRunnable.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */