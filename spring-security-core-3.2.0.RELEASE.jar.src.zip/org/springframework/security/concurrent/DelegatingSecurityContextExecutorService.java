/*     */ package org.springframework.security.concurrent;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.List;
/*     */ import java.util.concurrent.Callable;
/*     */ import java.util.concurrent.ExecutionException;
/*     */ import java.util.concurrent.ExecutorService;
/*     */ import java.util.concurrent.Future;
/*     */ import java.util.concurrent.TimeUnit;
/*     */ import java.util.concurrent.TimeoutException;
/*     */ import org.springframework.security.core.context.SecurityContext;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DelegatingSecurityContextExecutorService
/*     */   extends DelegatingSecurityContextExecutor
/*     */   implements ExecutorService
/*     */ {
/*     */   public DelegatingSecurityContextExecutorService(ExecutorService delegateExecutorService, SecurityContext securityContext) {
/*  47 */     super(delegateExecutorService, securityContext);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DelegatingSecurityContextExecutorService(ExecutorService delegate) {
/*  57 */     this(delegate, (SecurityContext)null);
/*     */   }
/*     */   
/*     */   public final void shutdown() {
/*  61 */     getDelegate().shutdown();
/*     */   }
/*     */   
/*     */   public final List<Runnable> shutdownNow() {
/*  65 */     return getDelegate().shutdownNow();
/*     */   }
/*     */   
/*     */   public final boolean isShutdown() {
/*  69 */     return getDelegate().isShutdown();
/*     */   }
/*     */   
/*     */   public final boolean isTerminated() {
/*  73 */     return getDelegate().isTerminated();
/*     */   }
/*     */   
/*     */   public final boolean awaitTermination(long timeout, TimeUnit unit) throws InterruptedException {
/*  77 */     return getDelegate().awaitTermination(timeout, unit);
/*     */   }
/*     */   
/*     */   public final <T> Future<T> submit(Callable<T> task) {
/*  81 */     task = wrap(task);
/*  82 */     return getDelegate().submit(task);
/*     */   }
/*     */   
/*     */   public final <T> Future<T> submit(Runnable task, T result) {
/*  86 */     task = wrap(task);
/*  87 */     return getDelegate().submit(task, result);
/*     */   }
/*     */   
/*     */   public final Future<?> submit(Runnable task) {
/*  91 */     task = wrap(task);
/*  92 */     return getDelegate().submit(task);
/*     */   }
/*     */ 
/*     */   
/*     */   public final List invokeAll(Collection<Callable<?>> tasks) throws InterruptedException {
/*  97 */     tasks = createTasks(tasks);
/*  98 */     return getDelegate().invokeAll(tasks);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public final List invokeAll(Collection<Callable<?>> tasks, long timeout, TimeUnit unit) throws InterruptedException {
/* 104 */     tasks = createTasks(tasks);
/* 105 */     return getDelegate().invokeAll(tasks, timeout, unit);
/*     */   }
/*     */ 
/*     */   
/*     */   public final Object invokeAny(Collection<Callable<?>> tasks) throws InterruptedException, ExecutionException {
/* 110 */     tasks = createTasks(tasks);
/* 111 */     return getDelegate().invokeAny(tasks);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public final Object invokeAny(Collection<Callable<?>> tasks, long timeout, TimeUnit unit) throws InterruptedException, ExecutionException, TimeoutException {
/* 117 */     tasks = createTasks(tasks);
/* 118 */     return getDelegate().invokeAny(tasks, timeout, unit);
/*     */   }
/*     */   
/*     */   private <T> Collection<Callable<T>> createTasks(Collection<Callable<T>> tasks) {
/* 122 */     if (tasks == null) {
/* 123 */       return null;
/*     */     }
/* 125 */     List<Callable<T>> results = new ArrayList<Callable<T>>(tasks.size());
/* 126 */     for (Callable<T> task : tasks) {
/* 127 */       results.add(wrap(task));
/*     */     }
/* 129 */     return results;
/*     */   }
/*     */   
/*     */   private ExecutorService getDelegate() {
/* 133 */     return (ExecutorService)getDelegateExecutor();
/*     */   }
/*     */ }


/* Location:              C:\Users\Gcorp\Downloads\spring-security-core-3.2.0.RELEASE.jar!\org\springframework\security\concurrent\DelegatingSecurityContextExecutorService.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */