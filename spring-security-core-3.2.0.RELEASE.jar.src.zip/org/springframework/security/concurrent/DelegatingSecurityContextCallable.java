/*    */ package org.springframework.security.concurrent;
/*    */ 
/*    */ import java.util.concurrent.Callable;
/*    */ import org.springframework.security.core.context.SecurityContext;
/*    */ import org.springframework.security.core.context.SecurityContextHolder;
/*    */ import org.springframework.util.Assert;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class DelegatingSecurityContextCallable<V>
/*    */   implements Callable<V>
/*    */ {
/*    */   private final Callable<V> delegate;
/*    */   private final SecurityContext securityContext;
/*    */   
/*    */   public DelegatingSecurityContextCallable(Callable<V> delegate, SecurityContext securityContext) {
/* 42 */     Assert.notNull(delegate, "delegate cannot be null");
/* 43 */     Assert.notNull(securityContext, "securityContext cannot be null");
/* 44 */     this.delegate = delegate;
/* 45 */     this.securityContext = securityContext;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public DelegatingSecurityContextCallable(Callable<V> delegate) {
/* 54 */     this(delegate, SecurityContextHolder.getContext());
/*    */   }
/*    */   
/*    */   public V call() throws Exception {
/*    */     try {
/* 59 */       SecurityContextHolder.setContext(this.securityContext);
/* 60 */       return this.delegate.call();
/*    */     } finally {
/*    */       
/* 63 */       SecurityContextHolder.clearContext();
/*    */     } 
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static <V> Callable<V> create(Callable<V> delegate, SecurityContext securityContext) {
/* 79 */     return (securityContext == null) ? new DelegatingSecurityContextCallable<V>(delegate) : new DelegatingSecurityContextCallable<V>(delegate, securityContext);
/*    */   }
/*    */ }


/* Location:              C:\Users\Gcorp\Downloads\spring-security-core-3.2.0.RELEASE.jar!\org\springframework\security\concurrent\DelegatingSecurityContextCallable.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */