/*    */ package org.springframework.security.concurrent;
/*    */ 
/*    */ import java.util.concurrent.Callable;
/*    */ import java.util.concurrent.ScheduledExecutorService;
/*    */ import java.util.concurrent.ScheduledFuture;
/*    */ import java.util.concurrent.TimeUnit;
/*    */ import org.springframework.security.core.context.SecurityContext;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class DelegatingSecurityContextScheduledExecutorService
/*    */   extends DelegatingSecurityContextExecutorService
/*    */   implements ScheduledExecutorService
/*    */ {
/*    */   public DelegatingSecurityContextScheduledExecutorService(ScheduledExecutorService delegateScheduledExecutorService, SecurityContext securityContext) {
/* 43 */     super(delegateScheduledExecutorService, securityContext);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public DelegatingSecurityContextScheduledExecutorService(ScheduledExecutorService delegate) {
/* 53 */     this(delegate, (SecurityContext)null);
/*    */   }
/*    */   
/*    */   public final ScheduledFuture<?> schedule(Runnable command, long delay, TimeUnit unit) {
/* 57 */     command = wrap(command);
/* 58 */     return getDelegate().schedule(command, delay, unit);
/*    */   }
/*    */   
/*    */   public final <V> ScheduledFuture<V> schedule(Callable<V> callable, long delay, TimeUnit unit) {
/* 62 */     callable = wrap(callable);
/* 63 */     return getDelegate().schedule(callable, delay, unit);
/*    */   }
/*    */   
/*    */   public final ScheduledFuture<?> scheduleAtFixedRate(Runnable command, long initialDelay, long period, TimeUnit unit) {
/* 67 */     command = wrap(command);
/* 68 */     return getDelegate().scheduleAtFixedRate(command, initialDelay, period, unit);
/*    */   }
/*    */ 
/*    */   
/*    */   public final ScheduledFuture<?> scheduleWithFixedDelay(Runnable command, long initialDelay, long delay, TimeUnit unit) {
/* 73 */     command = wrap(command);
/* 74 */     return getDelegate().scheduleWithFixedDelay(command, initialDelay, delay, unit);
/*    */   }
/*    */   
/*    */   private ScheduledExecutorService getDelegate() {
/* 78 */     return (ScheduledExecutorService)getDelegateExecutor();
/*    */   }
/*    */ }


/* Location:              C:\Users\Gcorp\Downloads\spring-security-core-3.2.0.RELEASE.jar!\org\springframework\security\concurrent\DelegatingSecurityContextScheduledExecutorService.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */