/*    */ package org.springframework.security.concurrent;
/*    */ 
/*    */ import java.util.concurrent.Executor;
/*    */ import org.springframework.security.core.context.SecurityContext;
/*    */ import org.springframework.util.Assert;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DelegatingSecurityContextExecutor
/*    */   extends AbstractDelegatingSecurityContextSupport
/*    */   implements Executor
/*    */ {
/*    */   private final Executor delegate;
/*    */   
/*    */   public DelegatingSecurityContextExecutor(Executor delegateExecutor, SecurityContext securityContext) {
/* 38 */     super(securityContext);
/* 39 */     Assert.notNull(delegateExecutor, "delegateExecutor cannot be null");
/* 40 */     this.delegate = delegateExecutor;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public DelegatingSecurityContextExecutor(Executor delegate) {
/* 50 */     this(delegate, null);
/*    */   }
/*    */   
/*    */   public final void execute(Runnable task) {
/* 54 */     task = wrap(task);
/* 55 */     this.delegate.execute(task);
/*    */   }
/*    */   
/*    */   protected final Executor getDelegateExecutor() {
/* 59 */     return this.delegate;
/*    */   }
/*    */ }


/* Location:              C:\Users\Gcorp\Downloads\spring-security-core-3.2.0.RELEASE.jar!\org\springframework\security\concurrent\DelegatingSecurityContextExecutor.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */