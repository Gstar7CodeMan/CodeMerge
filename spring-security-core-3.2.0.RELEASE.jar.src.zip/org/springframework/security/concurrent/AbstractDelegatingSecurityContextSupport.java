/*    */ package org.springframework.security.concurrent;
/*    */ 
/*    */ import java.util.concurrent.Callable;
/*    */ import org.springframework.security.core.context.SecurityContext;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ abstract class AbstractDelegatingSecurityContextSupport
/*    */ {
/*    */   private final SecurityContext securityContext;
/*    */   
/*    */   AbstractDelegatingSecurityContextSupport(SecurityContext securityContext) {
/* 37 */     this.securityContext = securityContext;
/*    */   }
/*    */   
/*    */   protected final Runnable wrap(Runnable delegate) {
/* 41 */     return DelegatingSecurityContextRunnable.create(delegate, this.securityContext);
/*    */   }
/*    */   
/*    */   protected final <T> Callable<T> wrap(Callable<T> delegate) {
/* 45 */     return DelegatingSecurityContextCallable.create(delegate, this.securityContext);
/*    */   }
/*    */ }


/* Location:              C:\Users\Gcorp\Downloads\spring-security-core-3.2.0.RELEASE.jar!\org\springframework\security\concurrent\AbstractDelegatingSecurityContextSupport.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */