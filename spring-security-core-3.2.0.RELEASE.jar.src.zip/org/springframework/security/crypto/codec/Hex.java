/*    */ package org.springframework.security.crypto.codec;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class Hex
/*    */ {
/* 14 */   private static final char[] HEX = new char[] { '0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'a', 'b', 'c', 'd', 'e', 'f' };
/*    */ 
/*    */ 
/*    */   
/*    */   public static char[] encode(byte[] bytes) {
/* 19 */     int nBytes = bytes.length;
/* 20 */     char[] result = new char[2 * nBytes];
/*    */     
/* 22 */     int j = 0;
/* 23 */     for (int i = 0; i < nBytes; i++) {
/*    */       
/* 25 */       result[j++] = HEX[(0xF0 & bytes[i]) >>> 4];
/*    */       
/* 27 */       result[j++] = HEX[0xF & bytes[i]];
/*    */     } 
/*    */     
/* 30 */     return result;
/*    */   }
/*    */   
/*    */   public static byte[] decode(CharSequence s) {
/* 34 */     int nChars = s.length();
/*    */     
/* 36 */     if (nChars % 2 != 0) {
/* 37 */       throw new IllegalArgumentException("Hex-encoded string must have an even number of characters");
/*    */     }
/*    */     
/* 40 */     byte[] result = new byte[nChars / 2];
/*    */     
/* 42 */     for (int i = 0; i < nChars; i += 2) {
/* 43 */       int msb = Character.digit(s.charAt(i), 16);
/* 44 */       int lsb = Character.digit(s.charAt(i + 1), 16);
/*    */       
/* 46 */       if (msb < 0 || lsb < 0) {
/* 47 */         throw new IllegalArgumentException("Non-hex character in input: " + s);
/*    */       }
/* 49 */       result[i / 2] = (byte)(msb << 4 | lsb);
/*    */     } 
/* 51 */     return result;
/*    */   }
/*    */ }


/* Location:              C:\Users\Gcorp\Downloads\spring-security-core-3.2.0.RELEASE.jar!\org\springframework\security\crypto\codec\Hex.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */