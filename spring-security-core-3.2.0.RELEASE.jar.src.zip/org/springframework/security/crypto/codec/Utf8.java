/*    */ package org.springframework.security.crypto.codec;
/*    */ 
/*    */ import java.nio.ByteBuffer;
/*    */ import java.nio.CharBuffer;
/*    */ import java.nio.charset.CharacterCodingException;
/*    */ import java.nio.charset.Charset;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class Utf8
/*    */ {
/* 17 */   private static final Charset CHARSET = Charset.forName("UTF-8");
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static byte[] encode(CharSequence string) {
/*    */     try {
/* 24 */       ByteBuffer bytes = CHARSET.newEncoder().encode(CharBuffer.wrap(string));
/* 25 */       byte[] bytesCopy = new byte[bytes.limit()];
/* 26 */       System.arraycopy(bytes.array(), 0, bytesCopy, 0, bytes.limit());
/*    */       
/* 28 */       return bytesCopy;
/* 29 */     } catch (CharacterCodingException e) {
/* 30 */       throw new IllegalArgumentException("Encoding failed", e);
/*    */     } 
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static String decode(byte[] bytes) {
/*    */     try {
/* 39 */       return CHARSET.newDecoder().decode(ByteBuffer.wrap(bytes)).toString();
/* 40 */     } catch (CharacterCodingException e) {
/* 41 */       throw new IllegalArgumentException("Decoding failed", e);
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\Gcorp\Downloads\spring-security-core-3.2.0.RELEASE.jar!\org\springframework\security\crypto\codec\Utf8.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */