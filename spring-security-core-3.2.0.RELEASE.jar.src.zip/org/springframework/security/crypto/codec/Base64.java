/*     */ package org.springframework.security.crypto.codec;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class Base64
/*     */ {
/*     */   public static final int NO_OPTIONS = 0;
/*     */   public static final int ENCODE = 1;
/*     */   public static final int DECODE = 0;
/*     */   public static final int DO_BREAK_LINES = 8;
/*     */   public static final int URL_SAFE = 16;
/*     */   public static final int ORDERED = 32;
/*     */   private static final int MAX_LINE_LENGTH = 76;
/*     */   private static final byte EQUALS_SIGN = 61;
/*     */   private static final byte NEW_LINE = 10;
/*     */   private static final byte WHITE_SPACE_ENC = -5;
/*     */   private static final byte EQUALS_SIGN_ENC = -1;
/*  65 */   private static final byte[] _STANDARD_ALPHABET = new byte[] { 65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78, 79, 80, 81, 82, 83, 84, 85, 86, 87, 88, 89, 90, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 43, 47 };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  83 */   private static final byte[] _STANDARD_DECODABET = new byte[] { -9, -9, -9, -9, -9, -9, -9, -9, -9, -5, -5, -9, -9, -5, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -5, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, 62, -9, -9, -9, 63, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, -9, -9, -9, -1, -9, -9, -9, 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, -9, -9, -9, -9, -9, -9, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9 };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 125 */   private static final byte[] _URL_SAFE_ALPHABET = new byte[] { 65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78, 79, 80, 81, 82, 83, 84, 85, 86, 87, 88, 89, 90, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 45, 95 };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 141 */   private static final byte[] _URL_SAFE_DECODABET = new byte[] { -9, -9, -9, -9, -9, -9, -9, -9, -9, -5, -5, -9, -9, -5, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -5, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, 62, -9, -9, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, -9, -9, -9, -1, -9, -9, -9, 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, -9, -9, -9, -9, 63, -9, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9 };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 188 */   private static final byte[] _ORDERED_ALPHABET = new byte[] { 45, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78, 79, 80, 81, 82, 83, 84, 85, 86, 87, 88, 89, 90, 95, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122 };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 206 */   private static final byte[] _ORDERED_DECODABET = new byte[] { -9, -9, -9, -9, -9, -9, -9, -9, -9, -5, -5, -9, -9, -5, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -5, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, 0, -9, -9, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, -9, -9, -9, -1, -9, -9, -9, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, -9, -9, -9, -9, 37, -9, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, 62, 63, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9 };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static byte[] decode(byte[] bytes) {
/* 246 */     return decode(bytes, 0, bytes.length, 0);
/*     */   }
/*     */   
/*     */   public static byte[] encode(byte[] bytes) {
/* 250 */     return encodeBytesToBytes(bytes, 0, bytes.length, 0);
/*     */   }
/*     */   
/*     */   public static boolean isBase64(byte[] bytes) {
/*     */     try {
/* 255 */       decode(bytes);
/* 256 */     } catch (InvalidBase64CharacterException e) {
/* 257 */       return false;
/*     */     } 
/* 259 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static byte[] getAlphabet(int options) {
/* 270 */     if ((options & 0x10) == 16)
/* 271 */       return _URL_SAFE_ALPHABET; 
/* 272 */     if ((options & 0x20) == 32) {
/* 273 */       return _ORDERED_ALPHABET;
/*     */     }
/* 275 */     return _STANDARD_ALPHABET;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static byte[] getDecodabet(int options) {
/* 287 */     if ((options & 0x10) == 16)
/* 288 */       return _URL_SAFE_DECODABET; 
/* 289 */     if ((options & 0x20) == 32) {
/* 290 */       return _ORDERED_DECODABET;
/*     */     }
/* 292 */     return _STANDARD_DECODABET;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static byte[] encode3to4(byte[] source, int srcOffset, int numSigBytes, byte[] destination, int destOffset, int options) {
/* 326 */     byte[] ALPHABET = getAlphabet(options);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 339 */     int inBuff = ((numSigBytes > 0) ? (source[srcOffset] << 24 >>> 8) : 0) | ((numSigBytes > 1) ? (source[srcOffset + 1] << 24 >>> 16) : 0) | ((numSigBytes > 2) ? (source[srcOffset + 2] << 24 >>> 24) : 0);
/*     */ 
/*     */ 
/*     */     
/* 343 */     switch (numSigBytes) {
/*     */       
/*     */       case 3:
/* 346 */         destination[destOffset] = ALPHABET[inBuff >>> 18];
/* 347 */         destination[destOffset + 1] = ALPHABET[inBuff >>> 12 & 0x3F];
/* 348 */         destination[destOffset + 2] = ALPHABET[inBuff >>> 6 & 0x3F];
/* 349 */         destination[destOffset + 3] = ALPHABET[inBuff & 0x3F];
/* 350 */         return destination;
/*     */       
/*     */       case 2:
/* 353 */         destination[destOffset] = ALPHABET[inBuff >>> 18];
/* 354 */         destination[destOffset + 1] = ALPHABET[inBuff >>> 12 & 0x3F];
/* 355 */         destination[destOffset + 2] = ALPHABET[inBuff >>> 6 & 0x3F];
/* 356 */         destination[destOffset + 3] = 61;
/* 357 */         return destination;
/*     */       
/*     */       case 1:
/* 360 */         destination[destOffset] = ALPHABET[inBuff >>> 18];
/* 361 */         destination[destOffset + 1] = ALPHABET[inBuff >>> 12 & 0x3F];
/* 362 */         destination[destOffset + 2] = 61;
/* 363 */         destination[destOffset + 3] = 61;
/* 364 */         return destination;
/*     */     } 
/*     */     
/* 367 */     return destination;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static byte[] encodeBytesToBytes(byte[] source, int off, int len, int options) {
/* 387 */     if (source == null) {
/* 388 */       throw new NullPointerException("Cannot serialize a null array.");
/*     */     }
/*     */     
/* 391 */     if (off < 0) {
/* 392 */       throw new IllegalArgumentException("Cannot have negative offset: " + off);
/*     */     }
/*     */     
/* 395 */     if (len < 0) {
/* 396 */       throw new IllegalArgumentException("Cannot have length offset: " + len);
/*     */     }
/*     */     
/* 399 */     if (off + len > source.length) {
/* 400 */       throw new IllegalArgumentException(String.format("Cannot have offset of %d and length of %d with array of length %d", new Object[] { Integer.valueOf(off), Integer.valueOf(len), Integer.valueOf(source.length) }));
/*     */     }
/*     */ 
/*     */     
/* 404 */     boolean breakLines = ((options & 0x8) > 0);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 413 */     int encLen = len / 3 * 4 + ((len % 3 > 0) ? 4 : 0);
/* 414 */     if (breakLines) {
/* 415 */       encLen += encLen / 76;
/*     */     }
/* 417 */     byte[] outBuff = new byte[encLen];
/*     */ 
/*     */     
/* 420 */     int d = 0;
/* 421 */     int e = 0;
/* 422 */     int len2 = len - 2;
/* 423 */     int lineLength = 0;
/* 424 */     for (; d < len2; d += 3, e += 4) {
/* 425 */       encode3to4(source, d + off, 3, outBuff, e, options);
/*     */       
/* 427 */       lineLength += 4;
/* 428 */       if (breakLines && lineLength >= 76) {
/*     */         
/* 430 */         outBuff[e + 4] = 10;
/* 431 */         e++;
/* 432 */         lineLength = 0;
/*     */       } 
/*     */     } 
/*     */     
/* 436 */     if (d < len) {
/* 437 */       encode3to4(source, d + off, len - d, outBuff, e, options);
/* 438 */       e += 4;
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 443 */     if (e <= outBuff.length - 1) {
/* 444 */       byte[] finalOut = new byte[e];
/* 445 */       System.arraycopy(outBuff, 0, finalOut, 0, e);
/*     */       
/* 447 */       return finalOut;
/*     */     } 
/*     */     
/* 450 */     return outBuff;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static int decode4to3(byte[] source, int srcOffset, byte[] destination, int destOffset, int options) {
/* 491 */     if (source == null) {
/* 492 */       throw new NullPointerException("Source array was null.");
/*     */     }
/* 494 */     if (destination == null) {
/* 495 */       throw new NullPointerException("Destination array was null.");
/*     */     }
/* 497 */     if (srcOffset < 0 || srcOffset + 3 >= source.length) {
/* 498 */       throw new IllegalArgumentException(String.format("Source array with length %d cannot have offset of %d and still process four bytes.", new Object[] { Integer.valueOf(source.length), Integer.valueOf(srcOffset) }));
/*     */     }
/*     */     
/* 501 */     if (destOffset < 0 || destOffset + 2 >= destination.length) {
/* 502 */       throw new IllegalArgumentException(String.format("Destination array with length %d cannot have offset of %d and still store three bytes.", new Object[] { Integer.valueOf(destination.length), Integer.valueOf(destOffset) }));
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 507 */     byte[] DECODABET = getDecodabet(options);
/*     */ 
/*     */     
/* 510 */     if (source[srcOffset + 2] == 61) {
/*     */ 
/*     */ 
/*     */       
/* 514 */       int i = (DECODABET[source[srcOffset]] & 0xFF) << 18 | (DECODABET[source[srcOffset + 1]] & 0xFF) << 12;
/*     */ 
/*     */       
/* 517 */       destination[destOffset] = (byte)(i >>> 16);
/* 518 */       return 1;
/*     */     } 
/*     */ 
/*     */     
/* 522 */     if (source[srcOffset + 3] == 61) {
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 527 */       int i = (DECODABET[source[srcOffset]] & 0xFF) << 18 | (DECODABET[source[srcOffset + 1]] & 0xFF) << 12 | (DECODABET[source[srcOffset + 2]] & 0xFF) << 6;
/*     */ 
/*     */ 
/*     */       
/* 531 */       destination[destOffset] = (byte)(i >>> 16);
/* 532 */       destination[destOffset + 1] = (byte)(i >>> 8);
/* 533 */       return 2;
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 543 */     int outBuff = (DECODABET[source[srcOffset]] & 0xFF) << 18 | (DECODABET[source[srcOffset + 1]] & 0xFF) << 12 | (DECODABET[source[srcOffset + 2]] & 0xFF) << 6 | DECODABET[source[srcOffset + 3]] & 0xFF;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 549 */     destination[destOffset] = (byte)(outBuff >> 16);
/* 550 */     destination[destOffset + 1] = (byte)(outBuff >> 8);
/* 551 */     destination[destOffset + 2] = (byte)outBuff;
/*     */     
/* 553 */     return 3;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static byte[] decode(byte[] source, int off, int len, int options) {
/* 576 */     if (source == null) {
/* 577 */       throw new NullPointerException("Cannot decode null source array.");
/*     */     }
/* 579 */     if (off < 0 || off + len > source.length) {
/* 580 */       throw new IllegalArgumentException(String.format("Source array with length %d cannot have offset of %d and process %d bytes.", new Object[] { Integer.valueOf(source.length), Integer.valueOf(off), Integer.valueOf(len) }));
/*     */     }
/*     */ 
/*     */     
/* 584 */     if (len == 0)
/* 585 */       return new byte[0]; 
/* 586 */     if (len < 4) {
/* 587 */       throw new IllegalArgumentException("Base64-encoded string must have at least four characters, but length specified was " + len);
/*     */     }
/*     */ 
/*     */     
/* 591 */     byte[] DECODABET = getDecodabet(options);
/*     */     
/* 593 */     int len34 = len * 3 / 4;
/* 594 */     byte[] outBuff = new byte[len34];
/* 595 */     int outBuffPosn = 0;
/*     */     
/* 597 */     byte[] b4 = new byte[4];
/* 598 */     int b4Posn = 0;
/* 599 */     int i = 0;
/* 600 */     byte sbiDecode = 0;
/*     */     
/* 602 */     for (i = off; i < off + len; i++) {
/*     */       
/* 604 */       sbiDecode = DECODABET[source[i] & 0xFF];
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 609 */       if (sbiDecode >= -5) {
/* 610 */         if (sbiDecode >= -1) {
/* 611 */           b4[b4Posn++] = source[i];
/* 612 */           if (b4Posn > 3) {
/* 613 */             outBuffPosn += decode4to3(b4, 0, outBuff, outBuffPosn, options);
/* 614 */             b4Posn = 0;
/*     */ 
/*     */             
/* 617 */             if (source[i] == 61) {
/*     */               break;
/*     */             }
/*     */           }
/*     */         
/*     */         } 
/*     */       } else {
/*     */         
/* 625 */         throw new InvalidBase64CharacterException(String.format("Bad Base64 input character decimal %d in array position %d", new Object[] { Integer.valueOf(source[i] & 0xFF), Integer.valueOf(i) }));
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 630 */     byte[] out = new byte[outBuffPosn];
/* 631 */     System.arraycopy(outBuff, 0, out, 0, outBuffPosn);
/* 632 */     return out;
/*     */   }
/*     */ }


/* Location:              C:\Users\Gcorp\Downloads\spring-security-core-3.2.0.RELEASE.jar!\org\springframework\security\crypto\codec\Base64.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */