/*    */ package org.springframework.security.crypto.util;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class EncodingUtils
/*    */ {
/*    */   public static byte[] concatenate(byte[]... arrays) {
/* 31 */     int length = 0;
/* 32 */     for (byte[] array : arrays) {
/* 33 */       length += array.length;
/*    */     }
/* 35 */     byte[] newArray = new byte[length];
/* 36 */     int destPos = 0;
/* 37 */     for (byte[] array : arrays) {
/* 38 */       System.arraycopy(array, 0, newArray, destPos, array.length);
/* 39 */       destPos += array.length;
/*    */     } 
/* 41 */     return newArray;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static byte[] subArray(byte[] array, int beginIndex, int endIndex) {
/* 51 */     int length = endIndex - beginIndex;
/* 52 */     byte[] subarray = new byte[length];
/* 53 */     System.arraycopy(array, beginIndex, subarray, 0, length);
/* 54 */     return subarray;
/*    */   }
/*    */ }


/* Location:              C:\Users\Gcorp\Downloads\spring-security-core-3.2.0.RELEASE.jar!\org\springframework\security\crypt\\util\EncodingUtils.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */