/*    */ package org.springframework.security.crypto.bcrypt;
/*    */ 
/*    */ import java.security.SecureRandom;
/*    */ import java.util.regex.Pattern;
/*    */ import org.apache.commons.logging.Log;
/*    */ import org.apache.commons.logging.LogFactory;
/*    */ import org.springframework.security.crypto.password.PasswordEncoder;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class BCryptPasswordEncoder
/*    */   implements PasswordEncoder
/*    */ {
/* 34 */   private Pattern BCRYPT_PATTERN = Pattern.compile("\\A\\$2a?\\$\\d\\d\\$[./0-9A-Za-z]{53}");
/* 35 */   private final Log logger = LogFactory.getLog(getClass());
/*    */   
/*    */   private final int strength;
/*    */   
/*    */   private final SecureRandom random;
/*    */   
/*    */   public BCryptPasswordEncoder() {
/* 42 */     this(-1);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public BCryptPasswordEncoder(int strength) {
/* 49 */     this(strength, null);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public BCryptPasswordEncoder(int strength, SecureRandom random) {
/* 58 */     this.strength = strength;
/* 59 */     this.random = random;
/*    */   }
/*    */   
/*    */   public String encode(CharSequence rawPassword) {
/*    */     String salt;
/* 64 */     if (this.strength > 0) {
/* 65 */       if (this.random != null) {
/* 66 */         salt = BCrypt.gensalt(this.strength, this.random);
/*    */       } else {
/*    */         
/* 69 */         salt = BCrypt.gensalt(this.strength);
/*    */       } 
/*    */     } else {
/*    */       
/* 73 */       salt = BCrypt.gensalt();
/*    */     } 
/* 75 */     return BCrypt.hashpw(rawPassword.toString(), salt);
/*    */   }
/*    */   
/*    */   public boolean matches(CharSequence rawPassword, String encodedPassword) {
/* 79 */     if (encodedPassword == null || encodedPassword.length() == 0) {
/* 80 */       this.logger.warn("Empty encoded password");
/* 81 */       return false;
/*    */     } 
/*    */     
/* 84 */     if (!this.BCRYPT_PATTERN.matcher(encodedPassword).matches()) {
/* 85 */       this.logger.warn("Encoded password does not look like BCrypt");
/* 86 */       return false;
/*    */     } 
/*    */     
/* 89 */     return BCrypt.checkpw(rawPassword.toString(), encodedPassword);
/*    */   }
/*    */ }


/* Location:              C:\Users\Gcorp\Downloads\spring-security-core-3.2.0.RELEASE.jar!\org\springframework\security\crypto\bcrypt\BCryptPasswordEncoder.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */