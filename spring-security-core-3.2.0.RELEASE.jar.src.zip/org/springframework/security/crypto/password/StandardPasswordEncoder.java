/*     */ package org.springframework.security.crypto.password;
/*     */ 
/*     */ import org.springframework.security.crypto.codec.Hex;
/*     */ import org.springframework.security.crypto.codec.Utf8;
/*     */ import org.springframework.security.crypto.keygen.BytesKeyGenerator;
/*     */ import org.springframework.security.crypto.keygen.KeyGenerators;
/*     */ import org.springframework.security.crypto.util.EncodingUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class StandardPasswordEncoder
/*     */   implements PasswordEncoder
/*     */ {
/*     */   private final Digester digester;
/*     */   private final byte[] secret;
/*     */   private final BytesKeyGenerator saltGenerator;
/*     */   private static final int DEFAULT_ITERATIONS = 1024;
/*     */   
/*     */   public StandardPasswordEncoder() {
/*  50 */     this("");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public StandardPasswordEncoder(CharSequence secret) {
/*  60 */     this("SHA-256", secret);
/*     */   }
/*     */   
/*     */   public String encode(CharSequence rawPassword) {
/*  64 */     return encode(rawPassword, this.saltGenerator.generateKey());
/*     */   }
/*     */   
/*     */   public boolean matches(CharSequence rawPassword, String encodedPassword) {
/*  68 */     byte[] digested = decode(encodedPassword);
/*  69 */     byte[] salt = EncodingUtils.subArray(digested, 0, this.saltGenerator.getKeyLength());
/*  70 */     return matches(digested, digest(rawPassword, salt));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private StandardPasswordEncoder(String algorithm, CharSequence secret) {
/*  76 */     this.digester = new Digester(algorithm, 1024);
/*  77 */     this.secret = Utf8.encode(secret);
/*  78 */     this.saltGenerator = KeyGenerators.secureRandom();
/*     */   }
/*     */   
/*     */   private String encode(CharSequence rawPassword, byte[] salt) {
/*  82 */     byte[] digest = digest(rawPassword, salt);
/*  83 */     return new String(Hex.encode(digest));
/*     */   }
/*     */   
/*     */   private byte[] digest(CharSequence rawPassword, byte[] salt) {
/*  87 */     byte[] digest = this.digester.digest(EncodingUtils.concatenate(new byte[][] { salt, this.secret, Utf8.encode(rawPassword) }));
/*  88 */     return EncodingUtils.concatenate(new byte[][] { salt, digest });
/*     */   }
/*     */   
/*     */   private byte[] decode(CharSequence encodedPassword) {
/*  92 */     return Hex.decode(encodedPassword);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean matches(byte[] expected, byte[] actual) {
/*  99 */     if (expected.length != actual.length) {
/* 100 */       return false;
/*     */     }
/*     */     
/* 103 */     int result = 0;
/* 104 */     for (int i = 0; i < expected.length; i++) {
/* 105 */       result |= expected[i] ^ actual[i];
/*     */     }
/* 107 */     return (result == 0);
/*     */   }
/*     */ }


/* Location:              C:\Users\Gcorp\Downloads\spring-security-core-3.2.0.RELEASE.jar!\org\springframework\security\crypto\password\StandardPasswordEncoder.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */