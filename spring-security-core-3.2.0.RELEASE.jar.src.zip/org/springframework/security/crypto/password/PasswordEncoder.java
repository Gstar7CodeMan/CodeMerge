package org.springframework.security.crypto.password;

public interface PasswordEncoder {
  String encode(CharSequence paramCharSequence);
  
  boolean matches(CharSequence paramCharSequence, String paramString);
}


/* Location:              C:\Users\Gcorp\Downloads\spring-security-core-3.2.0.RELEASE.jar!\org\springframework\security\crypto\password\PasswordEncoder.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */