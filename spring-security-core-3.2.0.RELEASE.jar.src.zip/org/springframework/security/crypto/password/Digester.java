/*    */ package org.springframework.security.crypto.password;
/*    */ 
/*    */ import java.security.MessageDigest;
/*    */ import java.security.NoSuchAlgorithmException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class Digester
/*    */ {
/*    */   private final MessageDigest messageDigest;
/*    */   private final int iterations;
/*    */   
/*    */   public Digester(String algorithm, int iterations) {
/*    */     try {
/* 43 */       this.messageDigest = MessageDigest.getInstance(algorithm);
/* 44 */     } catch (NoSuchAlgorithmException e) {
/* 45 */       throw new IllegalStateException("No such hashing algorithm", e);
/*    */     } 
/*    */     
/* 48 */     this.iterations = iterations;
/*    */   }
/*    */   
/*    */   public byte[] digest(byte[] value) {
/* 52 */     synchronized (this.messageDigest) {
/* 53 */       for (int i = 0; i < this.iterations; i++) {
/* 54 */         value = this.messageDigest.digest(value);
/*    */       }
/* 56 */       return value;
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\Gcorp\Downloads\spring-security-core-3.2.0.RELEASE.jar!\org\springframework\security\crypto\password\Digester.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */