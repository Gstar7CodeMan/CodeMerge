/*    */ package org.springframework.security.crypto.password;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class NoOpPasswordEncoder
/*    */   implements PasswordEncoder
/*    */ {
/*    */   public String encode(CharSequence rawPassword) {
/* 27 */     return rawPassword.toString();
/*    */   }
/*    */   
/*    */   public boolean matches(CharSequence rawPassword, String encodedPassword) {
/* 31 */     return rawPassword.toString().equals(encodedPassword);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static PasswordEncoder getInstance() {
/* 38 */     return INSTANCE;
/*    */   }
/*    */   
/* 41 */   private static final PasswordEncoder INSTANCE = new NoOpPasswordEncoder();
/*    */ }


/* Location:              C:\Users\Gcorp\Downloads\spring-security-core-3.2.0.RELEASE.jar!\org\springframework\security\crypto\password\NoOpPasswordEncoder.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */