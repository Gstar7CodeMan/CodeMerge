/*     */ package org.springframework.security.crypto.encrypt;
/*     */ 
/*     */ import javax.crypto.Cipher;
/*     */ import javax.crypto.SecretKey;
/*     */ import javax.crypto.spec.IvParameterSpec;
/*     */ import javax.crypto.spec.PBEKeySpec;
/*     */ import javax.crypto.spec.SecretKeySpec;
/*     */ import org.springframework.security.crypto.codec.Hex;
/*     */ import org.springframework.security.crypto.keygen.BytesKeyGenerator;
/*     */ import org.springframework.security.crypto.util.EncodingUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class AesBytesEncryptor
/*     */   implements BytesEncryptor
/*     */ {
/*     */   private final SecretKey secretKey;
/*     */   private final Cipher encryptor;
/*     */   private final Cipher decryptor;
/*     */   private final BytesKeyGenerator ivGenerator;
/*     */   private static final String AES_ALGORITHM = "AES/CBC/PKCS5Padding";
/*     */   
/*     */   public AesBytesEncryptor(String password, CharSequence salt) {
/*  50 */     this(password, salt, null);
/*     */   }
/*     */   
/*     */   public AesBytesEncryptor(String password, CharSequence salt, BytesKeyGenerator ivGenerator) {
/*  54 */     PBEKeySpec keySpec = new PBEKeySpec(password.toCharArray(), Hex.decode(salt), 1024, 256);
/*  55 */     SecretKey secretKey = CipherUtils.newSecretKey("PBKDF2WithHmacSHA1", keySpec);
/*  56 */     this.secretKey = new SecretKeySpec(secretKey.getEncoded(), "AES");
/*  57 */     this.encryptor = CipherUtils.newCipher("AES/CBC/PKCS5Padding");
/*  58 */     this.decryptor = CipherUtils.newCipher("AES/CBC/PKCS5Padding");
/*  59 */     this.ivGenerator = (ivGenerator != null) ? ivGenerator : NULL_IV_GENERATOR;
/*     */   }
/*     */   
/*     */   public byte[] encrypt(byte[] bytes) {
/*  63 */     synchronized (this.encryptor) {
/*  64 */       byte[] iv = this.ivGenerator.generateKey();
/*  65 */       CipherUtils.initCipher(this.encryptor, 1, this.secretKey, new IvParameterSpec(iv));
/*  66 */       byte[] encrypted = CipherUtils.doFinal(this.encryptor, bytes);
/*  67 */       return (this.ivGenerator != NULL_IV_GENERATOR) ? EncodingUtils.concatenate(new byte[][] { iv, encrypted }) : encrypted;
/*     */     } 
/*     */   }
/*     */   
/*     */   public byte[] decrypt(byte[] encryptedBytes) {
/*  72 */     synchronized (this.decryptor) {
/*  73 */       byte[] iv = iv(encryptedBytes);
/*  74 */       CipherUtils.initCipher(this.decryptor, 2, this.secretKey, new IvParameterSpec(iv));
/*  75 */       return CipherUtils.doFinal(this.decryptor, (this.ivGenerator != NULL_IV_GENERATOR) ? encrypted(encryptedBytes, iv.length) : encryptedBytes);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private byte[] iv(byte[] encrypted) {
/*  82 */     return (this.ivGenerator != NULL_IV_GENERATOR) ? EncodingUtils.subArray(encrypted, 0, this.ivGenerator.getKeyLength()) : NULL_IV_GENERATOR.generateKey();
/*     */   }
/*     */   
/*     */   private byte[] encrypted(byte[] encryptedBytes, int ivLength) {
/*  86 */     return EncodingUtils.subArray(encryptedBytes, ivLength, encryptedBytes.length);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*  91 */   private static final BytesKeyGenerator NULL_IV_GENERATOR = new BytesKeyGenerator()
/*     */     {
/*  93 */       private final byte[] VALUE = new byte[16];
/*     */       
/*     */       public int getKeyLength() {
/*  96 */         return this.VALUE.length;
/*     */       }
/*     */       
/*     */       public byte[] generateKey() {
/* 100 */         return this.VALUE;
/*     */       }
/*     */     };
/*     */ }


/* Location:              C:\Users\Gcorp\Downloads\spring-security-core-3.2.0.RELEASE.jar!\org\springframework\security\crypto\encrypt\AesBytesEncryptor.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */