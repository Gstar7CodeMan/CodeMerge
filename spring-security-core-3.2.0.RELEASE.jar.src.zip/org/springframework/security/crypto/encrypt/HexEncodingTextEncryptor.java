/*    */ package org.springframework.security.crypto.encrypt;
/*    */ 
/*    */ import org.springframework.security.crypto.codec.Hex;
/*    */ import org.springframework.security.crypto.codec.Utf8;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class HexEncodingTextEncryptor
/*    */   implements TextEncryptor
/*    */ {
/*    */   private final BytesEncryptor encryptor;
/*    */   
/*    */   public HexEncodingTextEncryptor(BytesEncryptor encryptor) {
/* 32 */     this.encryptor = encryptor;
/*    */   }
/*    */   
/*    */   public String encrypt(String text) {
/* 36 */     return new String(Hex.encode(this.encryptor.encrypt(Utf8.encode(text))));
/*    */   }
/*    */   
/*    */   public String decrypt(String encryptedText) {
/* 40 */     return Utf8.decode(this.encryptor.decrypt(Hex.decode(encryptedText)));
/*    */   }
/*    */ }


/* Location:              C:\Users\Gcorp\Downloads\spring-security-core-3.2.0.RELEASE.jar!\org\springframework\security\crypto\encrypt\HexEncodingTextEncryptor.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */