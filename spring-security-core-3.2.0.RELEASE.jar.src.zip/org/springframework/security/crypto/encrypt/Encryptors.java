/*    */ package org.springframework.security.crypto.encrypt;
/*    */ 
/*    */ import org.springframework.security.crypto.keygen.KeyGenerators;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Encryptors
/*    */ {
/*    */   public static BytesEncryptor standard(CharSequence password, CharSequence salt) {
/* 40 */     return new AesBytesEncryptor(password.toString(), salt, KeyGenerators.secureRandom(16));
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static TextEncryptor text(CharSequence password, CharSequence salt) {
/* 50 */     return new HexEncodingTextEncryptor(standard(password, salt));
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static TextEncryptor queryableText(CharSequence password, CharSequence salt) {
/* 63 */     return new HexEncodingTextEncryptor(new AesBytesEncryptor(password.toString(), salt));
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static TextEncryptor noOpText() {
/* 71 */     return NO_OP_TEXT_INSTANCE;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 77 */   private static final TextEncryptor NO_OP_TEXT_INSTANCE = new NoOpTextEncryptor();
/*    */   
/*    */   private static final class NoOpTextEncryptor
/*    */     implements TextEncryptor {
/*    */     public String encrypt(String text) {
/* 82 */       return text;
/*    */     }
/*    */     private NoOpTextEncryptor() {}
/*    */     public String decrypt(String encryptedText) {
/* 86 */       return encryptedText;
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\Gcorp\Downloads\spring-security-core-3.2.0.RELEASE.jar!\org\springframework\security\crypto\encrypt\Encryptors.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */