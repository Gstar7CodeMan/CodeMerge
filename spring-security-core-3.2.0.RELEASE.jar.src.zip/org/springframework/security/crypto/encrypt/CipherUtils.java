/*     */ package org.springframework.security.crypto.encrypt;
/*     */ 
/*     */ import java.security.InvalidAlgorithmParameterException;
/*     */ import java.security.InvalidKeyException;
/*     */ import java.security.NoSuchAlgorithmException;
/*     */ import java.security.spec.AlgorithmParameterSpec;
/*     */ import java.security.spec.InvalidKeySpecException;
/*     */ import java.security.spec.InvalidParameterSpecException;
/*     */ import javax.crypto.BadPaddingException;
/*     */ import javax.crypto.Cipher;
/*     */ import javax.crypto.IllegalBlockSizeException;
/*     */ import javax.crypto.NoSuchPaddingException;
/*     */ import javax.crypto.SecretKey;
/*     */ import javax.crypto.SecretKeyFactory;
/*     */ import javax.crypto.spec.PBEKeySpec;
/*     */ import javax.crypto.spec.PBEParameterSpec;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class CipherUtils
/*     */ {
/*     */   public static SecretKey newSecretKey(String algorithm, String password) {
/*  44 */     return newSecretKey(algorithm, new PBEKeySpec(password.toCharArray()));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static SecretKey newSecretKey(String algorithm, PBEKeySpec keySpec) {
/*     */     try {
/*  52 */       SecretKeyFactory factory = SecretKeyFactory.getInstance(algorithm);
/*  53 */       return factory.generateSecret(keySpec);
/*  54 */     } catch (NoSuchAlgorithmException e) {
/*  55 */       throw new IllegalArgumentException("Not a valid encryption algorithm", e);
/*  56 */     } catch (InvalidKeySpecException e) {
/*  57 */       throw new IllegalArgumentException("Not a valid secret key", e);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Cipher newCipher(String algorithm) {
/*     */     try {
/*  66 */       return Cipher.getInstance(algorithm);
/*  67 */     } catch (NoSuchAlgorithmException e) {
/*  68 */       throw new IllegalArgumentException("Not a valid encryption algorithm", e);
/*  69 */     } catch (NoSuchPaddingException e) {
/*  70 */       throw new IllegalStateException("Should not happen", e);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T extends AlgorithmParameterSpec> T getParameterSpec(Cipher cipher, Class<T> parameterSpecClass) {
/*     */     try {
/*  79 */       return cipher.getParameters().getParameterSpec(parameterSpecClass);
/*  80 */     } catch (InvalidParameterSpecException e) {
/*  81 */       throw new IllegalArgumentException("Unable to access parameter", e);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void initCipher(Cipher cipher, int mode, SecretKey secretKey) {
/*  89 */     initCipher(cipher, mode, secretKey, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void initCipher(Cipher cipher, int mode, SecretKey secretKey, byte[] salt, int iterationCount) {
/*  96 */     initCipher(cipher, mode, secretKey, new PBEParameterSpec(salt, iterationCount));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void initCipher(Cipher cipher, int mode, SecretKey secretKey, AlgorithmParameterSpec parameterSpec) {
/*     */     try {
/* 104 */       if (parameterSpec != null) {
/* 105 */         cipher.init(mode, secretKey, parameterSpec);
/*     */       } else {
/* 107 */         cipher.init(mode, secretKey);
/*     */       } 
/* 109 */     } catch (InvalidKeyException e) {
/* 110 */       throw new IllegalArgumentException("Unable to initialize due to invalid secret key", e);
/* 111 */     } catch (InvalidAlgorithmParameterException e) {
/* 112 */       throw new IllegalStateException("Unable to initialize due to invalid decryption parameter spec", e);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static byte[] doFinal(Cipher cipher, byte[] input) {
/*     */     try {
/* 121 */       return cipher.doFinal(input);
/* 122 */     } catch (IllegalBlockSizeException e) {
/* 123 */       throw new IllegalStateException("Unable to invoke Cipher due to illegal block size", e);
/* 124 */     } catch (BadPaddingException e) {
/* 125 */       throw new IllegalStateException("Unable to invoke Cipher due to bad padding", e);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\Gcorp\Downloads\spring-security-core-3.2.0.RELEASE.jar!\org\springframework\security\crypto\encrypt\CipherUtils.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */