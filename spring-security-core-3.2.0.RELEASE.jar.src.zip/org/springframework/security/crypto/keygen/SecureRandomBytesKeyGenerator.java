/*    */ package org.springframework.security.crypto.keygen;
/*    */ 
/*    */ import java.security.SecureRandom;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class SecureRandomBytesKeyGenerator
/*    */   implements BytesKeyGenerator
/*    */ {
/*    */   private final SecureRandom random;
/*    */   private final int keyLength;
/*    */   private static final int DEFAULT_KEY_LENGTH = 8;
/*    */   
/*    */   public SecureRandomBytesKeyGenerator() {
/* 40 */     this(8);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public SecureRandomBytesKeyGenerator(int keyLength) {
/* 47 */     this.random = new SecureRandom();
/* 48 */     this.keyLength = keyLength;
/*    */   }
/*    */   
/*    */   public int getKeyLength() {
/* 52 */     return this.keyLength;
/*    */   }
/*    */   
/*    */   public byte[] generateKey() {
/* 56 */     byte[] bytes = new byte[this.keyLength];
/* 57 */     this.random.nextBytes(bytes);
/* 58 */     return bytes;
/*    */   }
/*    */ }


/* Location:              C:\Users\Gcorp\Downloads\spring-security-core-3.2.0.RELEASE.jar!\org\springframework\security\crypto\keygen\SecureRandomBytesKeyGenerator.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */