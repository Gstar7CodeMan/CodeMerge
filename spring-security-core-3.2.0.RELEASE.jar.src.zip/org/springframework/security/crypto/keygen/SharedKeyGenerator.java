/*    */ package org.springframework.security.crypto.keygen;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class SharedKeyGenerator
/*    */   implements BytesKeyGenerator
/*    */ {
/*    */   private byte[] sharedKey;
/*    */   
/*    */   public SharedKeyGenerator(byte[] sharedKey) {
/* 30 */     this.sharedKey = sharedKey;
/*    */   }
/*    */   
/*    */   public int getKeyLength() {
/* 34 */     return this.sharedKey.length;
/*    */   }
/*    */   
/*    */   public byte[] generateKey() {
/* 38 */     return this.sharedKey;
/*    */   }
/*    */ }


/* Location:              C:\Users\Gcorp\Downloads\spring-security-core-3.2.0.RELEASE.jar!\org\springframework\security\crypto\keygen\SharedKeyGenerator.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */