package org.springframework.security.crypto.keygen;

public interface StringKeyGenerator {
  String generateKey();
}


/* Location:              C:\Users\Gcorp\Downloads\spring-security-core-3.2.0.RELEASE.jar!\org\springframework\security\crypto\keygen\StringKeyGenerator.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */