/*    */ package org.springframework.security.crypto.keygen;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class KeyGenerators
/*    */ {
/*    */   public static BytesKeyGenerator secureRandom() {
/* 31 */     return new SecureRandomBytesKeyGenerator();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static BytesKeyGenerator secureRandom(int keyLength) {
/* 39 */     return new SecureRandomBytesKeyGenerator(keyLength);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static BytesKeyGenerator shared(int keyLength) {
/* 47 */     return new SharedKeyGenerator(secureRandom(keyLength).generateKey());
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static StringKeyGenerator string() {
/* 55 */     return new HexEncodingStringKeyGenerator(secureRandom());
/*    */   }
/*    */ }


/* Location:              C:\Users\Gcorp\Downloads\spring-security-core-3.2.0.RELEASE.jar!\org\springframework\security\crypto\keygen\KeyGenerators.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */