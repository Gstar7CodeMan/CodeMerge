/*    */ package org.springframework.security.crypto.keygen;
/*    */ 
/*    */ import org.springframework.security.crypto.codec.Hex;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class HexEncodingStringKeyGenerator
/*    */   implements StringKeyGenerator
/*    */ {
/*    */   private final BytesKeyGenerator keyGenerator;
/*    */   
/*    */   public HexEncodingStringKeyGenerator(BytesKeyGenerator keyGenerator) {
/* 30 */     this.keyGenerator = keyGenerator;
/*    */   }
/*    */   
/*    */   public String generateKey() {
/* 34 */     return new String(Hex.encode(this.keyGenerator.generateKey()));
/*    */   }
/*    */ }


/* Location:              C:\Users\Gcorp\Downloads\spring-security-core-3.2.0.RELEASE.jar!\org\springframework\security\crypto\keygen\HexEncodingStringKeyGenerator.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */